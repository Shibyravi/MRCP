package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.HospitalHO626ClearReviewValidation;
import com.optum.mrcpcosmosatdd.services.rest.PhysicianCL601ClearReviewValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class HospitalHO626ClearReviewSteps extends MRCPTestBase{

	File HOSPJSON_ClrRvw3;
	File HOSPJSON_ClrRvw2;
	File JSON_HOSPCLRRVW;
	

	@When("^I get the request body parameter from payload json file for Hospital$")
	public void get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		HOSPJSON_ClrRvw3 = new File(PropertyReader.getInstance().readProperty("HOSPJSON_ClrRvw3"));
		HOSPJSON_ClrRvw2 = new File(PropertyReader.getInstance().readProperty("HOSPJSON_ClrRvw2"));
		JSON_HOSPCLRRVW = new File(PropertyReader.getInstance().readProperty("JSON_HOSPCLRRVW"));
	}

	@When("^Verify the Review Return code as \"([^\"]*)\" of hospital claim when Review does not exist$")
	public void verify_The_Review_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
	
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewCodeAndMsg(HOSPJSON_ClrRvw3);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Review Return code as \"([^\"]*)\" of hospital claim when Review already cleared$")
	public void verify_The_Review_Return_Code_RvwAlrdyClrd(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
	
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewCodeAndMsg(HOSPJSON_ClrRvw2);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Review Return Message as \"([^\"]*)\" of hospital claim when Review does not exist$")
	public void verify_The_Review_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
	
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewCodeAndMsg(HOSPJSON_ClrRvw3);
		System.out.println("Review Msg from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	

	@When("^Verify the Review Return Message as \"([^\"]*)\" of hospital claim when Review already cleared$")
	public void verify_The_Review_Return_MsgRvwAlrdyClrd(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
	
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewCodeAndMsg(HOSPJSON_ClrRvw2);
		System.out.println("Review Msg from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return Review Number as \"([^\"]*)\" of hospital claim when Review does not exist$")
	public void verify_The_Review_Return_Nbr(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewStatus(HOSPJSON_ClrRvw3);
		System.out.println("Review number from Response:"+" "+ response_ClaimsDetails.get("Review Nbr"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Nbr").equals(expRespDB), "Failed:Review number are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review number are verified from Service response and Database.");
	
	}
	
	@When("^Verify the Return Review Number as \"([^\"]*)\" of hospital claim when Review already cleared$")
	public void verify_The_Review_Return_Nbr_RvwAlrdyClrd(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewStatus(HOSPJSON_ClrRvw2);
		System.out.println("Review number from Response:"+" "+ response_ClaimsDetails.get("Review Nbr"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Nbr").equals(expRespDB), "Failed:Review number are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review number are verified from Service response and Database.");
	
	}
	
	@When("^Verify the Return Review Status as \"([^\"]*)\" of hospital claim when Review does not exist$")
	public void verify_The_Review_Return_Statusr(String rvwstatus)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwstatus.length() >0 && rvwstatus.substring(0, 1).equalsIgnoreCase("*"))
			rvwstatus = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwstatus, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwstatus);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewStatus(HOSPJSON_ClrRvw3);
		System.out.println("Review number from Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	
	}
	
	@When("^Verify the Return Review Status as \"([^\"]*)\" of hospital claim when Review already cleared$")
	public void verify_The_Review_Return_Status_RvwAlrdyClrd(String rvwstatus)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwstatus.length() >0 && rvwstatus.substring(0, 1).equalsIgnoreCase("*"))
			rvwstatus = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwstatus, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwstatus);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewStatus(HOSPJSON_ClrRvw2);
		System.out.println("Review number from Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	
	}
	
	@When("^Verify the Review Return status as \"([^\"]*)\" of hospital claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Status_For_ClearingTheReview(String rvwStatus)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwStatus.length() >0 && rvwStatus.substring(0, 1).equalsIgnoreCase("*"))
			rvwStatus = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwStatus, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwStatus);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(HospitalHO626ClearReviewValidation.class).reviewStatusForClearingReview(JSON_HOSPCLRRVW);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
}
