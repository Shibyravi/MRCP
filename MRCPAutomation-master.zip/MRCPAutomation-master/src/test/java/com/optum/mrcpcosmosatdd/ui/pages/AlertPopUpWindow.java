package com.optum.mrcpcosmosatdd.ui.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

public class AlertPopUpWindow extends BasePage{

	private By windowRootEle = By.xpath(".//div[@id='alertModalPromptAction' or @id='alertModal']");
	private By label_WindowTitle = By.className("lwd-window-title");

	//private By button_Ok = By.id("okAlertbutton");	
	//private By button_Cancel = By.id("cancelAlertbutton");
	private By label_Message = By.xpath(".//div[@id='messageBodyPromptAlert' or @id='messagebody']");
	private By close_WindowButton = By.xpath(".//span[@class='ui-button-icon ui-icon modalClose']");
	
	HomePage homepage = new HomePage();

			public By getWindowRoot() {
		return windowRootEle;
	}

	public boolean validateAlertPopupDisplayed() {
		try{
			boolean check = false;
			for(WebElement webElement: rootEle().findElements(label_Message) ) {
				if(webElement.isDisplayed()) {
					check= true;
					break; 
				}
			}
			if(check=true) {
				Log.info("Alert Popup displayed");
				return true;
			}
			else { 
				Log.info("Alert Popup not displayed");
				return false;
			}

		}
		catch(NoSuchElementException e) {
			Log.info("No Alert Popup displayed");
			return false;
		}
	}

	public boolean validateMessage(String message) throws InterruptedException {
		waitForPageToLoad();

		boolean check = false;
		for(WebElement webElement: rootEle().findElements(label_Message) ) {
			if(webElement.isDisplayed()) {
				if(rootEle().findElement(label_Message).getText().indexOf(message) > 0){
					check = true;
					break;
				}
			}
		}
		if(check=true) {
			Log.info("Message is displayed on alert popup");
			return true;
		}
		else {
			Log.error("Message is not displayed on alert popup");
			return false;
		}
	}

	public boolean clickOnButton(String buttonName) throws InterruptedException {
		waitForPageToLoad();
		List<WebElement> buttonList = rootEle().findElements(By.xpath("//button"));
		for(WebElement webElement:buttonList) {
			if(webElement.getText().trim().equalsIgnoreCase(buttonName)) {
				if(isElementEnabled(webElement)) {
					webElement.click();
					Log.info("Clicked on "+buttonName+" button on alert popup");
					return true;
				}
				else {
					Log.error(buttonName+" button is not enabled on alert popup");
					return false;
				}
			}
		}
		Log.error("Button with "+buttonName+" is not found on alert popup");
		return false;
	}

	public boolean clickOnCloseWindowButton() throws InterruptedException {
		waitForPageToLoad();
		if(isElementEnabled(close_WindowButton)) {
			Log.error("Close window button is not enabled on alert popup");
			rootEle().findElement(close_WindowButton).click();
			return true;
		}
		else {
			Log.error("Close window  button is not enabled on alert popup");
			return false;
		}
	}
	
	public boolean validateUserCanNotToggleBetweenPages(String PopUpName) throws InterruptedException {
		waitForPageToLoad();
		
		List<WebElement> listOpenWindows = driver.findElements(label_WindowTitle);
		if(listOpenWindows.size()>1)
		{
			//get the current open popup title
			WebElement webElement = driver.findElement(By.xpath(".//div[@class='modal-content modalBorderStyle editClaimsModalContent']//span[@class='modal-title']"));
			String Active_PopUP_Title = webElement.getText();
			if(Active_PopUP_Title.equals(PopUpName))
			{
				Log.info(PopUpName + " " + "pop up is active");
				KeyUtils.keyPressCtrlPlusTab();
				if(Active_PopUP_Title.equals(PopUpName))
				{
					Log.info(PopUpName + " " + "pop up is still active");
					Assert.assertFalse(!homepage.validatePageDisplayedOnTop(listOpenWindows.get(1).getText()));
						Log.info("Ctrl + Tab keypress is not working fine for switching between pages");
					}
				Log.info("User is not able to toggle between pages when pop up is active");
				}
				
			}
			else
			{
				Log.error(PopUpName + " " + "pop up is not active");
				return false;
			}
			
		return true;
		}
}