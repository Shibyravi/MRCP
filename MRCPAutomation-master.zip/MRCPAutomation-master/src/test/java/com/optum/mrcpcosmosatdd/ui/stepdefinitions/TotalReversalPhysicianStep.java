package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.TotalReversalPhysicianAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class TotalReversalPhysicianStep extends MRCPTestBase {

	File JSON_TOTALREVRSLFAILURE;
	File JSON_TOTALREVRSLBLNKUSRID;
	File JSON_TOTALREVRSLBLNKSITE;
	File JSON_TOTALREVRSLBLNKCLMRVSLREASON;
	File JSON_TOTALREVRSLBLNKCAUSECODE;
	File JSON_TOTALREVRSLBLNKBYPASSWAIT;
	File JSON_TOTALREVRSLBLNKREFUND;
	File JSON_TOTALREVRSLBLNKCLMCORRREQ;
	File JSON_TOTALREVRSLBLNKOTHRINFO;
	
	@When("^I get the request body parameter from payload json file for Total Reversal Physician$")
	public void I_get_the_body_Params_From_Json_Payload_File()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_TOTALREVRSLFAILURE = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLFAILURE"));
		JSON_TOTALREVRSLBLNKUSRID = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKUSRID"));
		JSON_TOTALREVRSLBLNKSITE = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKSITE"));
		JSON_TOTALREVRSLBLNKCLMRVSLREASON = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCLMRVSLREASON"));
		JSON_TOTALREVRSLBLNKCAUSECODE = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCAUSECODE"));
		JSON_TOTALREVRSLBLNKBYPASSWAIT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKBYPASSWAIT"));
		JSON_TOTALREVRSLBLNKREFUND = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKREFUND"));
		JSON_TOTALREVRSLBLNKCLMCORRREQ = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCLMCORRREQ"));
		JSON_TOTALREVRSLBLNKOTHRINFO = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKOTHRINFO"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when claim already in reversal state$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLFAILURE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when user id is blank$")
	public void verify_The_Return_Code_BlankUsrId(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKUSRID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when site is blank$")
	public void verify_The_Return_Code_BlankSite(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when claim reversal reason is blank$")
	public void verify_The_Return_Code_Blank_claimReversalReason(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCLMRVSLREASON);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}

	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when claim already in reversal state$")
	public void verify_The_Return_Msg_Failure(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLFAILURE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when user id is blank$")
	public void verify_The_Return_Msg_Blank_UsrId(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKUSRID);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when site is blank$")
	public void verify_The_Return_Msg_Blank_Site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when claim reversal reason is blank$")
	public void verify_The_Return_Msg_Blank_claimReversalReason(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCLMRVSLREASON);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when cause code is blank$")
	public void verify_The_Return_Code_Blank_CauseCode(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCAUSECODE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when cause code is blank$")
	public void verify_The_Return_Msg_Blank_CauseCode(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCAUSECODE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when bypass wait is blank$")
	public void verify_The_Return_Code_Blank_ByPassWait(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKBYPASSWAIT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when bypass wait is blank$")
	public void verify_The_Return_Msg_Blank_ByPassWait(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKBYPASSWAIT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when refund is blank$")
	public void verify_The_Return_Code_Blank_Refund(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKREFUND);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when refund is blank$")
	public void verify_The_Return_Msg_Blank_Refund(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKREFUND);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when clm corr req is blank$")
	public void verify_The_Return_Code_Blank_ClmCorrReq(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCLMCORRREQ);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when clm corr req is blank$")
	public void verify_The_Return_Msg_Blank_ClmCorrReq(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKCLMCORRREQ);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician when other info is blank$")
	public void verify_The_Return_Code_Blank_OthInfo(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKOTHRINFO);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician when other info is blank$")
	public void verify_The_Return_Msg_Blank_OthrInfo(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKOTHRINFO);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}

}
