package com.optum.mrcpcosmosatdd.ui.stepdefinitions.search;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.search.COBCarrierDetailsWindow;
import com.optum.mrcpcosmosatdd.ui.pages.search.COBInvestigateIntakeFormWindow;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class COBCarrierDetailsSteps extends MRCPTestBase {

	@When("^I perform \"([^\"]*)\" operation on COB Carrier Details Page$")
	public void I_Perform_Operation_On_The_COB_Carrier_Details_Page(String operation) throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).windowOperation(operation), true);
	}

	@When("^I Wait for the page load$")
	public void I_Wait_For_The_Page_Load() throws InterruptedException {
		getPage(COBCarrierDetailsWindow.class).WaitforElementToBeVisible();
	}
	
	@When("^I Wait for the page load for Hospital Adjustment$")
	public void I_Wait_For_The_Page_Load_For_Hosp_Adjustment() throws InterruptedException {
		getPage(COBCarrierDetailsWindow.class).WaitforElementToBeVisibleAuditNo();
	}


	@Then("^The \"([^\"]*)\" labels naming convention should be as per given on COB Carrier Details Page$")
	public void The_Labels_Naming_Convention_Should_Be_As_Per_Given_On_COB_Carrier_Details_Page(String strLabels) throws InvalidFormatException, IOException, InterruptedException {
		if (strLabels.substring(0, 1).equalsIgnoreCase("*"))		
			strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateLabelsOnPage(strLabels), true);
	}

	@Then("^The \"([^\"]*)\" labels naming convention for underlined lables should be as per given on COB Carrier Details Page$")
	public void The_Labels_Naming_Convention_Should_Be_As_Per_Given_On_COB_Carrier_Details_Page_For_UnderlinedLabels(String strLabels) throws InvalidFormatException, IOException, InterruptedException {
		if (strLabels.substring(0, 1).equalsIgnoreCase("*"))		
			strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateUnderlinedLabelsOnPage(strLabels), true);
	}

	@Then("^The \"([^\"]*)\" labels should be as per UI Standards on COB Carrier Details Page$")
	public void The_Labels_Should_Be_As_Per_UI_Standards_On_COB_Carrier_Details_Page(String strLabels) throws InvalidFormatException, IOException, InterruptedException {	
		if (strLabels.substring(0, 1).equalsIgnoreCase("*"))
			strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateLabelsStandardsOnPageforCOB(strLabels), true);	
	}	
	
	@Then("^The \"([^\"]*)\" bolded labels should be as per UI Standards on COB Carrier Details Page$")
	public void The_Bolded_Labels_Should_Be_As_Per_UI_Standards_On_COB_Carrier_Details_Page(String strLabels) throws InvalidFormatException, IOException, InterruptedException {	
		if (strLabels.substring(0, 1).equalsIgnoreCase("*"))
			strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));
 
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateBoldedLabelsStandardsOnPage(strLabels), true);
	}

	@Then("^The Concave fields should be as per UI Standards on COB Carrier Details Page$")
	public void The_Concave_Fields_Should_Be_As_Per_UI_Standards_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateConcaveFields(), true);
	}

	@Then("^Validate \"([^\"]*)\" Buttons standards on COB Carrier Details Page$")
	public void buttons_Should_Be_As_Per_UI_Standards_On_COB_Carrier_Details_Page(String buttonName) throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateButtonStandards(buttonName), true);
	}

	@Then("^The Cursor should be positioned in the first position of the field based on the data alignment on COB Carrier Details Page$")
	public void The_Cursor_Should_Be_Positioned_In_The_First_Position_Of_The_Field_Based_On_The_Data_Alignment_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateFieldsAlignment(), true);
	}

	@Then("^Backspace key should delete the data when data is highlighted in blue on COB Carrier Details Page$")
	public void Backspace_Key_Should_Delete_The_Data_When_Data_Is_Highlighted_In_Blue_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateBackspaceFunctionalityWhenDataHighlightedInBlue(), true);
	}
	
	@Then("^Backspace key should delete the one character to the left when data is not highlighted in blue on COB Carrier Details Page$")
	public void backspace_key_should_delete_the_one_character_to_the_left_when_data_is_not_highlighted_in_blue_on_Benefit_Period_By_Member_Search_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(), true);
	}

	@Then("^Verify By default \"([^\"]*)\" radio button is selected on COB Carrier Details Page$")
	public void byDefault_Selection_Of_A_RadioButton_On_COB_Carrier_Details_Page(String radioButton) throws InterruptedException, InvalidFormatException, IOException {
		if (radioButton.substring(0, 1).equalsIgnoreCase("*"))		
			radioButton = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, radioButton, PropertyReader.getInstance().readProperty("Environment"));
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateRadioButtonIsSelected(radioButton), true);
	}

	@Then("^The \"([^\"]*)\" column headers should be as expected$")
	public void the_column_headers_should_be_as_expected(String strColHeaders) throws InvalidFormatException, IOException, InterruptedException {
		if (strColHeaders.substring(0, 1).equalsIgnoreCase("*"))                   
			strColHeaders = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strColHeaders, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateColHeaders(strColHeaders), true);
	}

	@Then("^The \"([^\"]*)\" column headers should be underlined and not bolded\\.$")
	public void the_column_headers_should_be_underlined_and_not_bolded(String strColHeaders) throws InvalidFormatException, IOException, InterruptedException {
		if (strColHeaders.substring(0, 1).equalsIgnoreCase("*"))                  
			strColHeaders = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strColHeaders, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateunderlinedColHeaders(strColHeaders), true);
	}


	@Then("^Error message field should be disabled and convex$")
	public void error_message_field_should_be_disabled_and_convex() throws InvalidFormatException, IOException, InterruptedException {

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).ValidateErrorMsgBar(), true);
	}

	@Then("^Error message field color should be the default application color or color selected by the user$")
	public void Error_message_field_color_should_be_the_default_application_color_or_color_selected_by_the_user() throws InvalidFormatException, IOException, InterruptedException {

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).ValidateErrorMsgBarStandard(), true);
	}
	
	@Then("^Spellcheck will not be invoked on editable fields on COB Carrier Details Page$")
	public void Spellcheck_Will_Not_Be_Invoked_On_Editable_Fields_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).verifySpellCheck(),true);
	}
	 
	@Then("^Validate the tabbing through editable fields on COB Carrier Details Page$")
	public void Validate_The_Tabbing_Through_Editable_Fields_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateTabbingOrder(),true);
	}
	
	@Then("^I click on the \"([^\"]*)\" button on COB Carrier Details Page$")
	public void click_On_The_Button_On_COB_Carrier_Details_Page(String buttonName) throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).clickOnButton(buttonName),true);
	}
	
	@Then("^Verify the \"([^\"]*)\" dropdown values on COB Carrier details page$")
	public void Verify_The_dropdown_Values_On_COB_CarrierDetails_Page(String dropdownName) throws InterruptedException, InvalidFormatException, IOException {
		
		if (dropdownName.substring(0, 1).equalsIgnoreCase("*"))		
			dropdownName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, dropdownName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateDropdownValues(dropdownName),true);
	}
	
	@Then("^Validate that when field is filled to max then it will auto tab to next editable field on COB Carrier details page$")
	public void Validate_That_When_Field_Is_Filled_To_Max_Then_It_Will_Auto_Tab_To_Next_Editable_Field_On_COB_Carrier_Details_Page() throws InterruptedException {
		Assert.assertEquals(getPage(COBCarrierDetailsWindow.class).validateAutoTabAfterFieldFilledToMax(),true);
	}

}
