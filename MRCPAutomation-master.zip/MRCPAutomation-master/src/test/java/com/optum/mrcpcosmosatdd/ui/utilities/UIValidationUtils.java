package com.optum.mrcpcosmosatdd.ui.utilities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;

/**
 * @author sgupt228
 *
 */
public class UIValidationUtils extends BasePage{
	
	/**
	 * Return Text Alignment
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getTextAlignment(By webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("text-align");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
		return null;
	}

	/**
	 * Return Font Size
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontSize(By webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("font-size");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
		return null;
	}

	/**
	 * Return Font Weight
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontWeight(By webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("font-weight");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}

		return null;
	}

	/**
	 * Return Font Type
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontType(By webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("font-family");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}

		return null;
	}

	/**
	 * Return Font Color
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontColor(By webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("color");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
		return null;
	}

	/**
	 * Return Background color
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getBackgroundColor(By webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				return rootEle().findElement(webElement).getCssValue("background-color");
			}	
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}

		return null;
	}

	/**
	 * Verify that all the Command buttons has font as bolded on a page
	 * 
	 * @return
	 */
	public boolean verifyCommandButtonsFontWeight() {
		try {
			List<WebElement> buttonsList = rootEle().findElements(By.xpath(".//button[@class='custBtn']"));
			for (int i=0;i<buttonsList.size();i++) {
				if (!(buttonsList.get(i).getCssValue("font-weight").equalsIgnoreCase("bold")))
					return false;
			}
			return true;
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return false;
		}
	}

	/**
	 * Verify that F3F4 is present
	 * @return
	 */
	public boolean verifyF3F4Present() {
		try {
			if(rootEle().findElement(By.xpath(".//textarea[contains(text(),'F3F4')]")).isDisplayed()) {
				if(rootEle().findElement(By.xpath(".//textarea[contains(text(),'F3F4')]")).getCssValue("border-style").equalsIgnoreCase("groove")) {
					Log.info("Border is available around F3 F4");
					return true;
				}
				else {
					Log.error("Border is not available around F3 F4");
					return false;
				}
			}
			else {
				Log.info("Element is available");
				return false;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return false;
		}	
	}

	/**
	 * Verify that Command Button is enabled
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean verifyButtonEnabled(By webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				if(rootEle().findElement(webElement).isEnabled()) {
					Log.info("Button is enabled");
					return true;
				}
				else{
					Log.error("Button is disabled");
					return false;
				}	
			}
			else{
				Log.error("Button is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * 
	 * @param labelName
	 * @param inputFieldIndex
	 * @return
	 */
	public WebElement getLabelInputElement(String labelName, int inputFieldIndex) {
		List<WebElement> labelList = driver.findElements(By.xpath(".//label"));
		for (WebElement listElement : labelList) {
			if (listElement.getText().equalsIgnoreCase(labelName)){

				//------
				//======
				//------
			}
		}
		return null;
	}

	/**
	 * Validate that the Textfield is Convex field
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateConvexTextField(By webElement) {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				if(! rootEle().findElement(webElement).isEnabled()) {
					String backgroundColor = rootEle().findElement(webElement).getCssValue("background-color");
					String border = rootEle().findElement(webElement).getCssValue("border-style");
					String expectedBackgroundColor = driver.findElement(By.xpath(".//body")).getCssValue("background-color");
					if(border.equalsIgnoreCase("inset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("bg color:" + expectedBackgroundColor);
						return true;
					}
					else{
						Log.error("Not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Textfield is Concave field 
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateConcaveTextField(By webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				if(rootEle().findElement(webElement).isEnabled()) {
					String backgroundColor = rootEle().findElement(webElement).getCssValue("background-color");
					String border = rootEle().findElement(webElement).getCssValue("border-style");
					if(border.equalsIgnoreCase("inset") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info("bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error("Not a Concave field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that Text field is Highlighted with Black border
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateHighligtedTextField(By webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				if(rootEle().findElement(webElement).isEnabled()) {
					String backgroundColor = rootEle().findElement(webElement).getCssValue("background-color");
					String bordercolor = rootEle().findElement(webElement).getCssValue("border-color");
					if(bordercolor.equalsIgnoreCase("rgb(0, 0, 0)") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info("Field highlighted with black border and bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error("Not a Editable/Enabled field OR Field not highlihgted with black border");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Command button is highlighted with black border
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateButtonHighlighted(By webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(webElement));
			if(rootEle().findElement(webElement).isDisplayed()) {
				if(rootEle().findElement(webElement).isEnabled()) {
					String borderStyle = rootEle().findElement(webElement).getCssValue("border-style");
					String bordercolor = rootEle().findElement(webElement).getCssValue("border-color");
					if(bordercolor.equalsIgnoreCase("rgb(0, 0, 0)") && borderStyle.equalsIgnoreCase("outset")) {
						Log.info("Convex Button displayed with black border");
						return true;
					}
					else{
						Log.error("Not a convex button OR Button not highlighted with black border");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate the Command button Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateButtonStandard(By webElement) throws InterruptedException {
		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("bold"))
			return false;

		//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
		//	return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		return true;
	}

	/**
	 * Validate Enabled Text field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateEnabledTextFieldStandard(By webElement) throws InterruptedException {
		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("bold"))
			return false;

		//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
		//	return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConcaveTextField(webElement))
			return false;

		return true;
	}

	/**
	 * Validate Disabled Text field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandard(By webElement) throws InterruptedException {
		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("bold"))
			return false;

		//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
		//	return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(webElement))
			return false;

		return true;
	}

	/**
	 * Return Input WebElement based on Label Name
	 * 
	 * @param strLabel
	 * @return
	 */
	public WebElement getInputFieldByLabelName(String strLabel) {		
		return rootEle().findElement(By.xpath(".//textarea[contains(text(), '"+ strLabel +"')]//following-sibling::input"));
	}

	/**
	 * Validate that all the labels have colon at the end
	 * 
	 * @return
	 */
	public boolean validateColonInAllLabels() {		
		List<WebElement> listLabel =  rootEle().findElements(By.xpath(".//label"));
		for(WebElement label:listLabel){
			if(!label.getText().equalsIgnoreCase("")) {
				if(label.getText().charAt(label.getText().length()-1) == ':')
					return true;
			}
		}
		return false;
	}

	/**
	 * Validate the location of one element w.r.t. each other (Left Right relationship)
	 * 
	 * @param leftElement
	 * @param rightElement
	 * @return
	 */
	public boolean validateLocation(By leftElement, By rightElement) {
		WebElement leftWebElement = driver.findElement(leftElement);
		WebElement rightWebElement = driver.findElement(rightElement);

		Point point_leftWebElement = leftWebElement.getLocation();
		int xcord_leftWebElement = point_leftWebElement.getX();
		int ycord_leftWebElement = point_leftWebElement.getY();
		//int height_leftWebElement = leftWebElement.getSize().getHeight();
		int width_leftWebElement = leftWebElement.getSize().getWidth();

		Point point_rightWebElement = rightWebElement.getLocation();
		int xcord_rightWebElement = point_rightWebElement.getX();
		int ycord_rightWebElement = point_rightWebElement.getY();
		//int height_rightWebElement = rightWebElement.getSize().getHeight();
		//int width_rightWebElement = rightWebElement.getSize().getWidth();

		if(ycord_leftWebElement+3>=ycord_rightWebElement && ycord_leftWebElement-3<=ycord_rightWebElement && xcord_leftWebElement+width_leftWebElement <= xcord_rightWebElement ) {
			Log.info(leftElement + " is on the left to " + rightWebElement);
			return true;}

		else {
			Log.error(leftElement + " is not on the left to " + rightWebElement);
			return false;
		}
	}
}
