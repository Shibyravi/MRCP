package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.AlertPopUpWindow;
import com.optum.mrcpcosmosatdd.ui.pages.HomePage;
import com.optum.mrcpcosmosatdd.ui.pages.search.COBInvestigateIntakeFormWindow;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomePageSteps extends MRCPTestBase {
	
	@When("^I wait for (\\d+) seconds$")
	public void I_Wait_For_Seconds(int seconds) throws InterruptedException{
		getPage(HomePage.class).waitTimer(seconds);
	}
 
	@When("^I open the \"([^\"]*)\" window under the \"([^\"]*)\" menu$")
	public void iOpenTheWindowUnderTheMenu(String submenu, String mainMenu) throws Throwable {

		if(submenu.length()>0 && submenu.charAt(0)=='*')
			submenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, submenu, PropertyReader.getInstance().readProperty("Environment"));

		if(mainMenu.length()>0 && mainMenu.charAt(0)=='*')
			mainMenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, mainMenu, PropertyReader.getInstance().readProperty("Environment"));

		// Write code here that turns the phrase above into concrete actions
		getPage(HomePage.class).selectMenu(submenu, mainMenu);
	}
	
	@When("^I open the \"([^\"]*)\" window under the \"([^\"]*)\" submenu of \"([^\"]*)\" menu$")
	public void iOpenTheWindowUnderTheMenu(String secondSubMenu,String submenu, String mainMenu) throws Throwable {

		if(submenu.equalsIgnoreCase("SecondSubMenu"))
			secondSubMenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, submenu, PropertyReader.getInstance().readProperty("Environment"));

		if(submenu.equalsIgnoreCase("SubMenu"))
			submenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, submenu, PropertyReader.getInstance().readProperty("Environment"));

		if(mainMenu.equalsIgnoreCase("Menu"))
			mainMenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, mainMenu, PropertyReader.getInstance().readProperty("Environment"));

		// Write code here that turns the phrase above into concrete actions
		getPage(HomePage.class).selectMenu(secondSubMenu,submenu, mainMenu);
	}

	@When("^I open the \"([^\"]*)\" window under the \"([^\"]*)\" menu and Start the Timer$")
	public void I_Open_The_Window_Under_The_Menu_And_Start_The_Timer(String submenu, String mainMenu) throws Throwable {

		if(submenu.equalsIgnoreCase("SubMenu"))
			submenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, submenu, PropertyReader.getInstance().readProperty("Environment"));

		if(mainMenu.equalsIgnoreCase("Menu"))
			mainMenu = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, mainMenu, PropertyReader.getInstance().readProperty("Environment"));

		// Write code here that turns the phrase above into concrete actions
		getPage(HomePage.class).selectMenuAndStartTheTimer(submenu, mainMenu);

	}

	@When("^I open the SubMenu window under the Menu$")
	public void I_Open_The_SubMenu_Window_Under_The_Menu(DataTable key) throws InterruptedException{
		for(Map<String, String> data: key.asMaps(String.class, String.class))
			getPage(HomePage.class).selectMenu(data.get("SubMenu"),data.get("Menu"));
	}

	/*@When("^I open the \"([^\"]*)\" window from Toolbar$")
	public void iOpenTheWindowFromTheToolbar(String toolbar) throws Throwable {

		if(toolbar.equalsIgnoreCase("Toolbar Title"))
			toolbar = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, toolbar, PropertyReader.getInstance().readProperty("Environment"));

		// Write code here that turns the phrase above into concrete actions
		getPage(HomePage.class).selectToolbar(toolbar);
	}*/

	@Then("^I should be able to access the \"([^\"]*)\" page$")
	public void User_should_Be_Able_To_Access_The_Page(String pageName) throws InterruptedException, InvalidFormatException, IOException {
		if (pageName.equalsIgnoreCase("Window Title"))
			pageName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, pageName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(HomePage.class).ValidateWindowTitle(pageName),true);	
	}
	  
	@Then("^I should not be able to access the \"([^\"]*)\" page$")
	public void User_should_Not_Be_Able_To_Access_The_Page(String pageName) throws InterruptedException, InvalidFormatException, IOException {
		if (pageName.equalsIgnoreCase("Window Title"))
			pageName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, pageName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(HomePage.class).ValidateWindowTitle(pageName),false);	
	}
	
	@Then("^I should be able to access the \"([^\"]*)\" popup$")
	public void User_should_Be_Able_To_Access_The_Popup(String popupName) throws InterruptedException, InvalidFormatException, IOException {
		if (popupName.equalsIgnoreCase("Window Title"))
			popupName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, popupName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(HomePage.class).ValidatePopupTitle(popupName),true);	
	}
	
	@Then("^I should not be able to access the \"([^\"]*)\" popup$")
	public void User_should_Not_Be_Able_To_Access_The_Popup(String popupName) throws InterruptedException, InvalidFormatException, IOException {
		if (popupName.equalsIgnoreCase("Window Title"))
			popupName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, popupName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(HomePage.class).ValidatePopupTitle(popupName),false);	
	}

	@Then("I should be able to access the page$")
	public void User_Should_Be_Able_To_Access_The_Page(DataTable key) throws InterruptedException{
		for(Map<String, String> data: key.asMaps(String.class, String.class))
			Assert.assertEquals(getPage(HomePage.class).ValidateWindowTitle(data.get("Window Title")),true);
	}

	@Then("^I Logout of CPA Application$")
	public void iLogoutOfCPAApplication() throws Throwable {
		Assert.assertEquals(getPage(HomePage.class).logout(),"Logged Out");
	}

	@When("^I click on \"([^\"]*)\" toolbar icon$")
	public void I_Click_On_Toolbar_Icon(String toolbarTitle) throws InvalidFormatException, IOException, InterruptedException {
		if(toolbarTitle.equalsIgnoreCase("Toolbar Title"))
			toolbarTitle = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, toolbarTitle, PropertyReader.getInstance().readProperty("Environment"));

		getPage(HomePage.class).selectToolbar(toolbarTitle);
	}

	@When("^I hold ALT and press MenuShortcutKey and release ALT and press SubmenuShortcutKey$")
	public void I_Hold_ALT_and_Press_Menu_Shortcut_Key_And_Release_ALT_And_Press_Submenu_Shortcut_Key(DataTable key) throws InterruptedException {
		for(Map<String, String> data: key.asMaps(String.class, String.class))
			getPage(HomePage.class).accessMenuUsingALTandShortcutKeysHoldingALTKey(data.get("MenuShortcutKey"), data.get("SubmenuShortcutKey"));

	}

	@When("^I hold ALT and press \"([^\"]*)\" and release ALT and press \"([^\"]*)\"$")
	public void I_Hold_ALT_and_Press_Menu_Shortcut_Key_And_Release_ALT_And_Press_Submenu_Shortcut_Key(String strMenuKey, String strSubMenuKey) throws InvalidFormatException, IOException, InterruptedException {
		if(strMenuKey.equalsIgnoreCase("Menu Shortcut Key"))
			strMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		if(strSubMenuKey.equalsIgnoreCase("Submenu Shortcut Key"))
			strSubMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strSubMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		getPage(HomePage.class).accessMenuUsingALTandShortcutKeysHoldingALTKey(strMenuKey, strSubMenuKey);
	}

	@When("^I hold ALT and press MenuShortcutKey and Submenu Shortcut Key and release ALT key$")
	public void I_Hold_ALT_and_Press_Menu_Shortcut_Key_And_Submenu_Shortcut_Key_And_Release_ALT_Key(DataTable key) throws InterruptedException {
		for (Map<String, String> data: key.asMaps(String.class, String.class))
			getPage(HomePage.class).accessMenuUsingALTandShortcutKeysInCombinationHoldingALTKey(data.get("MenuShortcutKey"), data.get("SubmenuShortcutKey"));
	}

	@When("^I hold ALT and press \"([^\"]*)\" and \"([^\"]*)\" and release ALT key$")
	public void I_Hold_ALT_and_Press_Menu_Shortcut_Key_And_Submenu_Shortcut_Key_And_Release_ALT_Key(String strMenuKey, String strSubMenuKey) throws InvalidFormatException, IOException, InterruptedException {
		if(strMenuKey.equalsIgnoreCase("Menu Shortcut Key"))
			strMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		if(strSubMenuKey.equalsIgnoreCase("Submenu Shortcut Key"))
			strSubMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strSubMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		getPage(HomePage.class).accessMenuUsingALTandShortcutKeysInCombinationHoldingALTKey(strMenuKey, strSubMenuKey);
	}

	@When("^I press ALT and press MenuShortcutKey and SubmenuShortcutKey without holding ALT key$")
	public void I_Press_ALT_and_Menu_Shortcut_Key_And_Submenu_Shortcut_Key(DataTable key) throws InterruptedException {
		for(Map<String, String> data : key.asMaps(String.class, String.class))
			getPage(HomePage.class).accessMenuUsingShortcutKeysReleasingALTKey(data.get("MenuShortcutKey"), data.get("SubmenuShortcutKey"));
	}

	@When("^I press ALT and press \"([^\"]*)\" and \"([^\"]*)\" without holding ALT key$")
	public void I_Press_ALT_and_Menu_Shortcut_Key_And_Submenu_Shortcut_Key(String strMenuKey, String strSubMenuKey) throws InvalidFormatException, IOException, InterruptedException {
		if(strMenuKey.equalsIgnoreCase("Menu Shortcut Key"))
			strMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		if(strSubMenuKey.equalsIgnoreCase("Submenu Shortcut Key"))
			strSubMenuKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strSubMenuKey, PropertyReader.getInstance().readProperty("Environment"));

		getPage(HomePage.class).accessMenuUsingShortcutKeysReleasingALTKey(strMenuKey, strSubMenuKey);
	}

	@When("^I hold ALT and press \"([^\"]*)\"$")
	public void I_Hold_ALT_And_Press_MenuShortcutKey(String mainMenuKey) throws InterruptedException {
		getPage(HomePage.class).accessMenuUsingALTandMainMenuShortcutKey(mainMenuKey);
	}

	@When("^I press ALT$")
	public void I_Press_ALT() throws InterruptedException {
		//KeyUtils.keyPressALTUsingRobotClass();
		KeyUtils.keyPressALT();
	}

	@When("^I press ESC$")
	public void I_Press_ESC() throws InterruptedException {
		//KeyUtils.keyPressEscUsingRobotClass();
		KeyUtils.keyPressEsc();
	}

	@Then("^Validate that \"([^\"]*)\" main menu is highlighted$")
	public void Validate_That_Main_Menu_Is_Highlighted(String menuName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateMainMenuHighlighted(menuName),true);
	}

	@Then("^Validate that \"([^\"]*)\" main menu is only highlighted$")
	public void Validate_That_Main_Menu_Is_Only_Highlighted(String menuName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateOnlyMainMenuHighlighted(menuName),true);
	}

	@Then("^Validate that none of the main menu is highlighted$")
	public void Validate_That_None_Of_The_Main_Menu_Is_Highlighted() throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateNoneOfTheMainMenuHighlighted(),true);
	}

	@Then("^Validate that \"([^\"]*)\" main menu is opened and highlighted$")
	public void Validate_That_Main_Menu_Is_Open_And_Highlighted(String menuName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateOpenedMainMenuHighlighted(menuName),true);
	}

	@When("I click on \"([^\"]*)\" Main Menu$")
	public void I_Click_On_MainMenu(String mainMenu) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).mainMenuClick(mainMenu), true);
	}

	@When("I click on \"([^\"]*)\" Submenu$")
	public void I_Click_On_Submenu(String subMenu) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).subMenuClick(subMenu), true);
	}

	@When("^I hold CTRL and press SubmenuShortcutKey$")
	public void I_Hold_CTRL_And_Press_Window_Shortcut_Key(DataTable key) throws InterruptedException {
		for(Map<String, String> data: key.asMaps(String.class, String.class))
			getPage(HomePage.class).accessWindowUsingWindowShortcutKeyHoldingCTRLKey(data.get("SubmenuShortcutKey"));
	}

	@When("^I hold CTRL and press \"([^\"]*)\"$")
	public void I_Hold_CTRL_And_Press_Window_Shortcut_Key(String shortcutKey) throws InterruptedException, InvalidFormatException, IOException{
		if(shortcutKey.equalsIgnoreCase("Submenu Shortcut Key"))
			shortcutKey = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, shortcutKey, PropertyReader.getInstance().readProperty("Environment"));

		getPage(HomePage.class).accessWindowUsingWindowShortcutKeyHoldingCTRLKey(shortcutKey);
	}

	@When("^I press Ctrl Plus Tab to switch between pages$")
	public void User_Press_Ctrl_Plus_Tab_To_Tab_Between_Pages() throws InterruptedException {
		//KeyUtils.keyPressCtrlPlusTabUsingRobotClass();
		KeyUtils.keyPressCtrlPlusTab();
	}

	@Then("^Validate that the user is able to toggle between pages$")
	public void Validate_That_The_User_Is_Able_To_Toggle_Between_Pages() throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validateUserCanToggleBetweenPages(),true);
	}
	
	@Then("^Validate that the user is not able to toggle between pages$")
	public void Validate_That_The_User_Is_Not_Able_To_Toggle_Between_Pages() throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validateUserCanToggleBetweenPages(),false);
	}
	
	@Then("^Validate that the \"([^\"]*)\" page is closed on ESC key press$")
	public void Validate_That_The_Page_Is_Closed_On_ESC_Key_Press(String pageName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validatePageClosedOnESCKeyPress(pageName),true);
	}

	@When("^I click on \"([^\"]*)\" page available in bottom taskbar$")
	public void User_Click_On_Page_Available_In_Bottom_Taskbar(String pageName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).clickOnPageButtonInBottomTaskbar(pageName),true);
	}

	@Then("^I should be able to see \"([^\"]*)\" page on top$")
	public void User_Should_Be_Able_To_See_Page_On_Top(String pageName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validatePageDisplayedOnTop(pageName),true);
	}

	@Then("^I should be able to see FFFFFF as background color for Main Menu$")
	public void User_Should_Be_Able_To_See_FFFFFF_As_Background_Color_For_Main_Menu() throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateMainMenuBackgroundColor(),true);
	}

	@Then("^I should be able to see EFEFEE as background color for Toolbar Icons$")
	public void User_Should_Be_Able_To_See_EFEFEE_As_Background_Color_For_Toolbar_Icon() throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateToolbarBackgroundColor(),true);
	}

	@Then("^Validate the background color on CPA Home Page$")
	public void Validate_TheBackground_Color_On_CPA_Home_Page() throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateHomeBackgroundColor(),true);
	}

	@Then("^I Press Right Arrow Key until \"([^\"]*)\" main menu is highlighted$")
	public void Press_Right_Arrow_Key_Until_Main_Menu_Is_Highlighted(String mainMenuName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).pressRightArrowKeyUntilMainMenuHighlighted(mainMenuName),true);
	}

	@Then("^I Press Right Arrow Key until \"([^\"]*)\" main menu is opened and highlighted$")
	public void Press_Right_Arrow_Key_Until_Main_Menu_Is_Opened_And_Highlighted(String mainMenuName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).pressRightArrowKeyUntilMainMenuOpenedAndHighlighted(mainMenuName),true);
	}

	@Then("^I Press the Down arrow key$")
	public void I_Press_The_Down_Arrow_Key() throws InterruptedException {
		//KeyUtils.keyPressDownArrowUsingRobotClass();
	
		KeyUtils.keyPressDownArrow();
	}

	@Then("^I Press the Up arrow key$")
	public void I_Press_The_Up_Arrow_Key() throws InterruptedException {
		//KeyUtils.keyPressUpArrowUsingRobotClass();
		KeyUtils.keyPressUpArrow();
	}

	@Then("^I Press the Left arrow key$")
	public void I_Press_The_Left_Arrow_Key() throws InterruptedException {
		//KeyUtils.keyPressLeftArrowUsingRobotClass();
		KeyUtils.keyPressLeftArrow();
	}

	@Then("^I Press the Right arrow key$")
	public void I_Press_The_Right_Arrow_Key() throws InterruptedException {
		//KeyUtils.keyPressRightArrowUsingRobotClass();
		KeyUtils.keyPressRightArrow();
	}

	@Then("^\"([^\"]*)\" submenu under \"([^\"]*)\" menu should be highlighted$")
	public void Submenu_Under_Menu_Should_Be_Highlighted(String subMenuName, String mainMenuName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validateHighligtedSubmenuUnderMenu(subMenuName, mainMenuName),true);
	}

	@Then("^\"([^\"]*)\" submenu under \"([^\"]*)\" menu should be only highlighted$")
	public void Submenu_Under_Menu_Should_Be_Only_Highlighted(String subMenuName, String mainMenuName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validateOnlyHighligtedSubmenuUnderMenu(subMenuName, mainMenuName),true);
	}

	@Then("^I Press \"([^\"]*)\" shortcut key$")
	public void I_Press_Shortcut_Key(String keyName) throws InterruptedException {
		//KeyUtils.keyPressAloneUsingRobotClass(keyName);
		KeyUtils.keyPressAlone(keyName);
	}

	@Then("^I Press ENTER key$")
	public void I_Press_ENTER_Key() throws InterruptedException {
		KeyUtils.keyPressEnter();
	}

	@Then("^I Hover over \"([^\"]*)\" Main Menu$")
	public void I_Hover_Over_Main_Menu(String mainMenuName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).hoverOverMainMenu(mainMenuName),true);
	}

	@Then("^I Hover over \"([^\"]*)\" Sub Menu under \"([^\"]*)\" Main Menu$")
	public void I_Hover_Over_Sub_Menu_Under_Main_Menu(String subMenuName, String mainMenuName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).hoverOverSubMenu(mainMenuName,subMenuName),true);
	}

	@Then("^Validate that \"([^\"]*)\" window/popup is displayed$")
	public void Validate_That_WindowPopup_Is_Displayed(String windowName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateWindowDisplayed(windowName),true);
	}

	@Then("^Validate that \"([^\"]*)\" window/popup is not displayed$")
	public void Validate_That_WindowPopup_Is_Not_Displayed(String windowName) throws InterruptedException{
		Assert.assertEquals(getPage(HomePage.class).validateWindowDisplayed(windowName),false);
	}

	@Then("^I want to scroll by \"([^\"]*)\" x-pixels and \"([^\"]*)\" y-pixels$")
	public void I_Want_To_Scroll_By_Xpixels_And_Ypixels(String xPixels, String yPixels) throws InterruptedException{
		getPage(HomePage.class).scrollBy(xPixels, yPixels);
	}
	
	@When("^I move the mouse cursor to Optum Logo$")
	public void I_Move_The_Mouse_Cursor_To_Optum_Logo() throws InterruptedException{
		getPage(HomePage.class).mouseHoverAway();
	}
	
	@When("^I should see the alert popup with message \"([^\"]*)\"$")
	public void I_Should_See_The_Popup_With_Message(String message) throws InterruptedException{
		Assert.assertEquals(getPage(AlertPopUpWindow.class).validateMessage(message),true);
	}
	
	@When("^I click on \"([^\"]*)\" button on alert popup$")
	public void I_Click_On_Button(String buttonName) throws InterruptedException{
		Assert.assertEquals(getPage(AlertPopUpWindow.class).clickOnButton(buttonName),true);
	}
	
	@When("^I click on Close window button on alert popup$")
	public void I_Click_Close_Window_Button_On_Alert_Popup() throws InterruptedException{
		Assert.assertEquals(getPage(AlertPopUpWindow.class).clickOnCloseWindowButton(),true);
	}
	
	@Then("^Validate that the user is not able to toggle between pages if \"([^\"]*)\" pop up is active$")
	public void Validate_That_The_User_Is_Not_Able_To_Toggle_Between_Pages(String popupName) throws InterruptedException {
		Assert.assertEquals(getPage(AlertPopUpWindow.class).validateUserCanNotToggleBetweenPages(popupName),true);
	}
	
	@Then("^Get the \"([^\"]*)\" and \"([^\"]*)\" Authentication token from Session storage$")
	public void get_The_Session_Storage_Token_For_Authentication(String oidcAuthToken, String oidcIdToken) throws InterruptedException {
		List<String> authKeys =getPage(HomePage.class).getAuthKeysFromCookies(oidcAuthToken, oidcIdToken);
		System.out.println("Auth tokens:"+ " "+authKeys);
	}
	
}