package com.optum.mrcpcosmosatdd.services.rest;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TotalReversalPhysicianAPIValidation {
	
	public static Response getJsonResponseAsJSONObject(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://physician-transactions-unita1.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/physician/total-reversal");
		return response;
	}
	
	public static Response getJsonResponseAsJSONObjectSubAdt(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://physician-transactions-unita1.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/physician/total-reversal-sub");
		return response;
	}
	
	//Return the response
	public Map<String,String> totalReversalPhyResponse(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		Map<String,String> totalReversalPhy_Resp = new HashMap();
		String returnCode = "";
		String returnMsg = "";
		
		Response response = getJsonResponseAsJSONObject(requestParams);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		returnCode = jsonObj.getString("code");
		returnMsg = jsonObj.getString("msg");
		
		totalReversalPhy_Resp.put("Return Code", returnCode);
		totalReversalPhy_Resp.put("Return Msg", returnMsg);
		

		return totalReversalPhy_Resp;
	}
	
	//Return the response
		public Map<String,String> totalReversalPhySubAdtResponse(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
		{

			Map<String,String> totalReversalPhySubAdt_Resp = new HashMap();
			String returnCode = "";
			String returnMsg = "";
			
			Response response = getJsonResponseAsJSONObjectSubAdt(requestParams);
			JSONObject jsonObj = new JSONObject(response.getBody().asString());
			returnCode = jsonObj.getString("code");
			returnMsg = jsonObj.getString("msg");
			
			totalReversalPhySubAdt_Resp.put("Return Code", returnCode);
			totalReversalPhySubAdt_Resp.put("Return Msg", returnMsg);
			

			return totalReversalPhySubAdt_Resp;
		}

}
