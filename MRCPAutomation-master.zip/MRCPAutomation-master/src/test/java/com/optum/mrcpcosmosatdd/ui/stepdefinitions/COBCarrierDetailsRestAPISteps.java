package com.optum.mrcpcosmosatdd.ui.stepdefinitions;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import java.util.Collections;
import java.util.List;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;


public class COBCarrierDetailsRestAPISteps extends MRCPTestBase {

	//JSONObject requestParams = new JSONObject();
	Map<String,String> attributes = new HashMap();

	@When("^I inquire Member number as \"([^\"]*)\" and Site as \"([^\"]*)\" and AsOfDt as \"([^\"]*)\" and Active Edit as \"([^\"]*)\" on COB Carrier Details page API$")
	public void i_inquire_Member_number_and_Site_and_AsOfDate_and_ActiveEdit_on_COB_Carrier_Details_page(String memNbr, String memSite, String asOfDt, String activEdit) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (memNbr.length() >0 && memNbr.substring(0, 1).equalsIgnoreCase("*"))
			memNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memNbr, PropertyReader.getInstance().readProperty("Environment"));
		if (memSite.length() >0 && memSite.substring(0, 1).equalsIgnoreCase("*"))
			memSite = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memSite, PropertyReader.getInstance().readProperty("Environment"));
		if (asOfDt.length() >0 && asOfDt.substring(0, 1).equalsIgnoreCase("*"))
			asOfDt = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, asOfDt, PropertyReader.getInstance().readProperty("Environment"));
		if (activEdit.length() >0 && activEdit.substring(0, 1).equalsIgnoreCase("*"))
			activEdit = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, activEdit, PropertyReader.getInstance().readProperty("Environment"));

		attributes.put("memberNumber", memNbr);
		attributes.put("site", memSite);
		attributes.put("asOfDate", asOfDt);
		attributes.put("isActiveEdit", activEdit);

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).performInquire(memNbr, memSite, asOfDt, activEdit), true);

	} 

	@When("^Verify the Member details from service response , COB details screen and \"([^\"]*)\" from DB$")
	public void verify_The_MemberDetails_from_Response_COB_Screen_And_DataBase(String memDetailsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (memDetailsResponse.length() >0 && memDetailsResponse.substring(0, 1).equalsIgnoreCase("*"))
			memDetailsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memDetailsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(memDetailsResponse);
		System.out.println("Member Details Expected Response from DB through DataSheet"+" "+expRespDB); 

		List<String> memNbr_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getMemberDetails();
		System.out.println("UI Member details"+" "+ memNbr_Details_FromUI);

		//Response from Service
		List<String> response_MemberDetails = getPage(COBCarrierDetailsRestAPIValidations.class).memDetailsResp(attributes);
		System.out.println("Member Details Response:"+" "+ response_MemberDetails);
		Assert.assertTrue(memNbr_Details_FromUI.equals(response_MemberDetails), "Failed:Memebr details are not verified from UI and Response");
		Assert.assertTrue(memNbr_Details_FromUI.equals(expRespDB), "Failed:Memebr details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Memebr details are verified from UI ,Service response and Database.");

	} 

	@When("^Verify the \"([^\"]*)\" primacy values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_PrimacyCarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Primacy Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Primacy Carrier details from UI"+" "+ carrier_Details_FromUI.get("Primacy"));


		//primacy validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Primacy Carrier details from Service response"+" "+ response_CarrierDetails.get("Primacy"));
		Assert.assertTrue(carrier_Details_FromUI.get("Primacy").equals(response_CarrierDetails.get("Primacy")), "Failed:Primacy Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("Primacy").equals(expRespDB), "Failed:Primacy carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Primacy carrier details are verified from UI ,Service response and Database.");

	} 

	@When("^Verify the \"([^\"]*)\" Cov Type values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Cov_TypeCarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Primacy Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Cov Type Carrier details from UI"+" "+ carrier_Details_FromUI.get("CovType"));


		//primacy validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Cov Type Carrier details from Service response"+" "+ response_CarrierDetails.get("CovType"));
		Assert.assertTrue(carrier_Details_FromUI.get("CovType").equals(response_CarrierDetails.get("CovType")), "Failed:Cov Type Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("CovType").equals(expRespDB), "Failed:Cov Type carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Cov Type carrier details are verified from UI ,Service response and Database.");

	} 

	@When("^Verify the \"([^\"]*)\" Carrier Type values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Carrier_Type_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carrier Type Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Type Carrier details from UI"+" "+ carrier_Details_FromUI.get("CarrierType"));


		//Carrier Type validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carrier Type Carrier details from Service response"+" "+ response_CarrierDetails.get("CarrierType"));
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierType").equals(response_CarrierDetails.get("CarrierType")), "Failed:Carrier Type Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierType").equals(expRespDB), "Failed:Carrier Type carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Carrier Type carrier details are verified from UI ,Service response and Database.");

	} 

	@When("^Verify the \"([^\"]*)\" Carrier Number values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_CarrierNumber_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carier Number Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Number Carrier details from UI"+" "+ carrier_Details_FromUI.get("CarrierNumber"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carier Number Carrier details from Service response"+" "+ response_CarrierDetails.get("CarrierNumber"));
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierNumber").equals(response_CarrierDetails.get("CarrierNumber")), "Failed:Primacy Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierNumber").equals(expRespDB), "Failed:Carrier Number carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Carrier Number carrier details are verified from UI ,Service response and Database.");

	} 

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_CarrierName_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carier Name Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Name Carrier details from UI"+" "+ carrier_Details_FromUI.get("CarrierName"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carier Name Carrier details from Service response"+" "+ response_CarrierDetails.get("CarrierName"));
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(response_CarrierDetails.get("CarrierName")), "Failed:Primacy Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(expRespDB), "Failed:Carrier Name carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Carrier Name carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Effective Date values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Effective_Date_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Effective Date Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Effective Date Carrier details from UI"+" "+ carrier_Details_FromUI.get("Eff Date"));


		//Effective date validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Effective Date Carrier details from Service response"+" "+ response_CarrierDetails.get("EffDate"));
		Assert.assertTrue(carrier_Details_FromUI.get("Eff Date").equals(response_CarrierDetails.get("EffDate")), "Failed:Effective Date Carrier details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("Eff Date").equals(expRespDB), "Failed:Effective Date carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Verified:Effective Date carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Exp Date values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Exp_Date_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Exp Date Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Exp Date Carrier details from UI"+" "+ carrier_Details_FromUI.get("Exp Date"));


		//Exp date validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Exp Date Carrier details from Service response"+" "+ response_CarrierDetails.get("ExpDate"));
		Assert.assertTrue(carrier_Details_FromUI.get("Exp Date").equals(response_CarrierDetails.get("ExpDate")), "Failed:Exp date details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("Exp Date").equals(expRespDB), "Failed:Exp Date carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Exp Date carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Policy Number values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Policy_Number_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Policy Number Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Policy Number Carrier details from UI"+" "+ carrier_Details_FromUI.get("Policy Number"));


		//Policy Number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Policy Number Carrier details from Service response"+" "+ response_CarrierDetails.get("PolicyNumber"));
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(response_CarrierDetails.get("PolicyNumber")), "Failed:Policy Number details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(expRespDB), "Failed:Policy Number carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Policy Number carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Communication Reason values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Communication_Reason_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Communication Reason Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Communication Reason Carrier details from UI"+" "+ carrier_Details_FromUI.get("Communication Rsn"));


		//Communication Reason validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Communication Reason Carrier details from Service response"+" "+ response_CarrierDetails.get("CommReason"));
		Assert.assertTrue(carrier_Details_FromUI.get("Communication Rsn").equals(response_CarrierDetails.get("CommReason")), "Failed:Communication Reason details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("Communication Rsn").equals(expRespDB), "Failed:Communication Reason carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Communication Reason carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Other UHC Plan values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_Other_UHC_Plan_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Other UHC Plan Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Other UHC Plan Carrier details from UI"+" "+ carrier_Details_FromUI.get("OtherUHCInfo"));


		//Other UHC Plan validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Other UHC Plan Carrier details from Service response"+" "+ response_CarrierDetails.get("OthrUHCPlan"));
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(response_CarrierDetails.get("OthrUHCPlan")), "Failed:Other UHC Plan details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(expRespDB), "Failed:Other UHC Plan carrier details are not verified from UI and Data base through data sheet.");
		Log.info("Other UHC Plan carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" FM User values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_FM_User_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("FM User Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("FM User Carrier details from UI"+" "+ carrier_Details_FromUI.get("FM User"));


		//FM User validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("FM User Carrier details from Service response"+" "+ response_CarrierDetails.get("FMUser"));
		Assert.assertTrue(carrier_Details_FromUI.get("FM User").equals(response_CarrierDetails.get("FMUser")), "Failed:FM User details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("FM User").equals(expRespDB), "Failed:FM User carrier details are not verified from UI and Data base through data sheet.");
		Log.info("FM User carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" FM Date values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_FM_Date_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("FM Date Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("FM Date Carrier details from UI"+" "+ carrier_Details_FromUI.get("FM Date"));


		//FM Date validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("FM Date Carrier details from Service response"+" "+ response_CarrierDetails.get("FMDate"));
		Assert.assertTrue(carrier_Details_FromUI.get("FM Date").equals(response_CarrierDetails.get("FMDate")), "Failed:FM Date details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("FM Date").equals(expRespDB), "Failed:FM Date carrier details are not verified from UI and Data base through data sheet.");
		Log.info("FM Date carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" FM Time values of Other insurance Carrier details from service response , COB details screen and from DB$")
	public void verify_The_FM_Time_CarrierDetails_from_Response_COB_Screen_And_DataBase(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("FM Time Carrier Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("FM Time Carrier details from UI"+" "+ carrier_Details_FromUI.get("FM Time"));


		//FM Time validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("FM Time Carrier details from Service response"+" "+ response_CarrierDetails.get("FMTime"));
		Assert.assertTrue(carrier_Details_FromUI.get("FM Time").equals(response_CarrierDetails.get("FMTime")), "Failed:FM Time details are not verified from UI and Response");
		Assert.assertTrue(carrier_Details_FromUI.get("FM Time").equals(expRespDB), "Failed:FM Time carrier details are not verified from UI and Data base through data sheet.");
		Log.info("FM Time carrier details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Incident DT values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Incident_Date_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Incident DT Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Incident DT Recovery details from UI"+" "+ recovery_Details_FromUI.get("IncidentDT"));


		//Incident DT Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Incident DT Recovery details from Service response"+" "+ response_RecoveryDetails.get("IncidentDT"));
		Assert.assertTrue(recovery_Details_FromUI.get("IncidentDT").equals(response_RecoveryDetails.get("IncidentDT")), "Failed:Incident DT recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("IncidentDT").equals(expRespDB), "Failed:Incident DT recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Incident DT recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Carrier Type values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Carrier_Type_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Type Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Type Recovery details from UI"+" "+ recovery_Details_FromUI.get("CarrierTypeRec"));


		//Carrier Type Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Type Recovery details from Service response"+" "+ response_RecoveryDetails.get("CarrierTypeRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierTypeRec").equals(response_RecoveryDetails.get("CarrierTypeRec")), "Failed:Carrier Type recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierTypeRec").equals(expRespDB), "Failed:Carrier Type recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Carrier Type recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Carrier Number values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Carrier_Number_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Number Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Number Recovery details from UI"+" "+ recovery_Details_FromUI.get("CarrierNumberRec"));


		//Carrier Number Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Number Recovery details from Service response"+" "+ response_RecoveryDetails.get("CarrierNumberRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNumberRec").equals(response_RecoveryDetails.get("CarrierNumberRec")), "Failed:Carrier Number recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNumberRec").equals(expRespDB), "Failed:Carrier Number recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Carrier Number recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Carrier_Name_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Name Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Name Recovery details from UI"+" "+ recovery_Details_FromUI.get("CarrierNameRec"));


		//Carrier Name Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Name Recovery details from Service response"+" "+ response_RecoveryDetails.get("CarrierNameRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(response_RecoveryDetails.get("CarrierNameRec")), "Failed:Carrier Name recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(expRespDB), "Failed:Carrier Name recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Carrier Name recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Effective Date values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Effective_Date_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Effective Date Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Effective Date Recovery details from UI"+" "+ recovery_Details_FromUI.get("Eff Date Rec"));


		//Effective Date Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Effective Date Recovery details from Service response"+" "+ response_RecoveryDetails.get("Eff Date Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Eff Date Rec").equals(response_RecoveryDetails.get("Eff Date Rec")), "Failed:Effective Date recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Eff Date Rec").equals(expRespDB), "Failed:Effective Date recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Effective Date recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Expiration Date values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Expiration_Date_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Expiration Date Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Expiration Date Recovery details from UI"+" "+ recovery_Details_FromUI.get("Exp Date Rec"));


		//Effective Date Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Expiration Date Recovery details from Service response"+" "+ response_RecoveryDetails.get("Exp Date Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Exp Date Rec").equals(response_RecoveryDetails.get("Exp Date Rec")), "Failed:Expiration Date recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Exp Date Rec").equals(expRespDB), "Failed:Expiration Date recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Expiration Date recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" Policy number values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Policy_number_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Policy number Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Policy number Recovery details from UI"+" "+ recovery_Details_FromUI.get("Policy Number Rec"));


		//Policy number Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Policy number Recovery details from Service response"+" "+ response_RecoveryDetails.get("Policy Number Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(response_RecoveryDetails.get("Policy Number Rec")), "Failed:Policy number recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(expRespDB), "Failed:Policy number recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Policy number recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" Communication Reason values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Communication_Reason_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Communication Reason Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Communication Reason Recovery details from UI"+" "+ recovery_Details_FromUI.get("Communication Rsn Rec"));


		//Communication Reason Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Communication Reason Recovery details from Service response"+" "+ response_RecoveryDetails.get("Communication Rsn Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Communication Rsn Rec").equals(response_RecoveryDetails.get("Communication Rsn Rec")), "Failed:Communication Reason recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Communication Rsn Rec").equals(expRespDB), "Failed:Communication Reason recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Communication Reason recovery details are verified from UI ,Service response and Database.");

	}

	@When("^Verify the \"([^\"]*)\" apport pect values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Apport_pect_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Apport pect Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Apport pect Recovery details from UI"+" "+ recovery_Details_FromUI.get("Apport Pect Rec"));


		//Apport pect Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Apport pect Recovery details from Service response"+" "+ response_RecoveryDetails.get("Apport Pect Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Apport Pect Rec").equals(response_RecoveryDetails.get("Apport Pect Rec")), "Failed:Apport pect recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Apport Pect Rec").equals(expRespDB), "Failed:Apport pect recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Apport pect recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" Diagnosis Description values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_Diagnosis_Description_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Diagnosis Description Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Diagnosis Description Recovery details from UI"+" "+ recovery_Details_FromUI.get("Diag Desc Rec"));


		//Diagnosis Description Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Diagnosis Description Recovery details from Service response"+" "+ response_RecoveryDetails.get("Diag Desc Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(response_RecoveryDetails.get("Diag Desc Rec")), "Failed:Diagnosis Description recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(expRespDB), "Failed:Diagnosis Description recovery details are not verified from UI and Data base through data sheet.");
		Log.info("Diagnosis Description recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA Num values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA_Num_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA Num Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA Num Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA Num Rec"));


		//ICDA Num Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA Num Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA Num Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA Num Rec").equals(response_RecoveryDetails.get("ICDA Num Rec")), "Failed:ICDA Num recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA Num Rec").equals(expRespDB), "Failed:ICDA Num recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA Num recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA1 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA1_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA1 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA1 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA1 Rec"));


		//ICDA1 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA1 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA1 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA1 Rec").equals(response_RecoveryDetails.get("ICDA1 Rec")), "Failed:ICDA1 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA1 Rec").equals(expRespDB), "Failed:ICDA1 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA1 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA2 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA2_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA2 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA2 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA2 Rec"));


		//ICDA2 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA2 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA2 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(response_RecoveryDetails.get("ICDA2 Rec")), "Failed:ICDA2 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(expRespDB), "Failed:ICDA2 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA2 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA3 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA3_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA3 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA3 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA3 Rec"));


		//ICDA3 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA3 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA3 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA3 Rec").equals(response_RecoveryDetails.get("ICDA3 Rec")), "Failed:ICDA2 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA3 Rec").equals(expRespDB), "Failed:ICDA3 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA3 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA4 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA4_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA4 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA4 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA4 Rec"));


		//ICDA4 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA4 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA4 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(response_RecoveryDetails.get("ICDA4 Rec")), "Failed:ICDA4 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(expRespDB), "Failed:ICDA4 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA4 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA5 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA5_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA5 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA5 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA5 Rec"));


		//ICDA5 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA5 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA5 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(response_RecoveryDetails.get("ICDA5 Rec")), "Failed:ICDA5 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(expRespDB), "Failed:ICDA5 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA5 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA6 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA6_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA6 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA6 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA6 Rec"));


		//ICDA6 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA6 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA6 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA6 Rec").equals(response_RecoveryDetails.get("ICDA6 Rec")), "Failed:ICDA6 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA6 Rec").equals(expRespDB), "Failed:ICDA6 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA6 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA7 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA7_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA6 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA7 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA7 Rec"));


		//ICDA7 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA7 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA7 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA7 Rec").equals(response_RecoveryDetails.get("ICDA7 Rec")), "Failed:ICDA7 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA7 Rec").equals(expRespDB), "Failed:ICDA7 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA7 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA8 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA8_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA8 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA8 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA6 Rec"));


		//ICDA8 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA8 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA8 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(response_RecoveryDetails.get("ICDA8 Rec")), "Failed:ICDA8 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(expRespDB), "Failed:ICDA8 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA8 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA9 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA9_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA9 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA9 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA9 Rec"));


		//ICDA9 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA9 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA9 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA9 Rec").equals(response_RecoveryDetails.get("ICDA9 Rec")), "Failed:ICDA8 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA9 Rec").equals(expRespDB), "Failed:ICDA9 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA9 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA10 values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_ICDA10_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA10 Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA10 Recovery details from UI"+" "+ recovery_Details_FromUI.get("ICDA10 Rec"));


		//ICDA10 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA10 Recovery details from Service response"+" "+ response_RecoveryDetails.get("ICDA10 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(response_RecoveryDetails.get("ICDA10 Rec")), "Failed:ICDA10 recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(expRespDB), "Failed:ICDA10 recovery details are not verified from UI and Data base through data sheet.");
		Log.info("ICDA10 recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM User values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_FM_User_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("FM User Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("FM User Recovery details from UI"+" "+ recovery_Details_FromUI.get("FM User Rec"));


		//FM User Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("FM User Recovery details from Service response"+" "+ response_RecoveryDetails.get("FM User Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("FM User Rec").equals(response_RecoveryDetails.get("FM User Rec")), "Failed:FM User recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("FM User Rec").equals(expRespDB), "Failed:FM User recovery details are not verified from UI and Data base through data sheet.");
		Log.info("FM User recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM Date values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_FM_Date_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("FM Date Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("FM Date Recovery details from UI"+" "+ recovery_Details_FromUI.get("FM Date Rec"));


		//FM Date Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("FM Date Recovery details from Service response"+" "+ response_RecoveryDetails.get("FM Date Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("FM Date Rec").equals(response_RecoveryDetails.get("FM Date Rec")), "Failed:FM Date recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("FM Date Rec").equals(expRespDB), "Failed:FM Date recovery details are not verified from UI and Data base through data sheet.");
		Log.info("FM Date recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM Time values of Recovery details from service response , COB details screen and from DB$")
	public void verify_The_FM_Time_RecoveryDetails_from_Response_COB_Screen_And_DataBase(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("FM Time Recovery Details Expected Response from DB through DataSheet"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("FM Time Recovery details from UI"+" "+ recovery_Details_FromUI.get("FM Time Rec"));


		//FM Time Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("FM Time Recovery details from Service response"+" "+ response_RecoveryDetails.get("FM Time Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("FM Time Rec").equals(response_RecoveryDetails.get("FM Time Rec")), "Failed:FM Time recovery details are not verified from UI and Response");
		Assert.assertTrue(recovery_Details_FromUI.get("FM Time Rec").equals(expRespDB), "Failed:FM Time recovery details are not verified from UI and Data base through data sheet.");
		Log.info("FM Time recovery details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" audit number of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_AuditNbr_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String auditInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (auditInvestigateExpResponse.length() >0 && auditInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			auditInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, auditInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  auditInvestigateExpResponse;
		System.out.println("Audit Number investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String audiNbr_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getAuditNbrInvestigateUI();
		System.out.println("Audit Number investigate status from UI"+" "+ audiNbr_Investigate_FromUI);


		//Audit number investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("Audit number investigation details from Service response"+" "+ response_InvestigationDetails.get("audit Number"));
		Assert.assertTrue(audiNbr_Investigate_FromUI.equals(response_InvestigationDetails.get("audit Number")), "Failed:Audit number investigation details are not verified from UI and Response");
		Assert.assertTrue(audiNbr_Investigate_FromUI.equals(expRespDB), "Failed:Audit number investigation details are not verified from UI and Data base through data sheet.");
		Log.info("Audit number investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" Claim Type of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_Claim_Type_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("Claim Type investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String claimType_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getClaimTypeInvestigateUI();
		System.out.println("Claim Type investigate status from UI"+" "+ claimType_Investigate_FromUI);


		//Claim Type investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("Claim Type investigation details from Service response"+" "+ response_InvestigationDetails.get("Claim Type"));
		Assert.assertTrue(claimType_Investigate_FromUI.equals(response_InvestigationDetails.get("Claim Type")), "Failed:Claim Type investigation details are not verified from UI and Response");
		Assert.assertTrue(claimType_Investigate_FromUI.equals(expRespDB), "Failed:Claim Type investigation details are not verified from UI and Data base through data sheet.");
		Log.info("Claim Type investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" Investigation Type of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_Investigation_Type_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("Investigation Type investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String investigationStatus_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getInvestigationTypeUI();
		System.out.println("Investigation Type investigate status from UI"+" "+ investigationStatus_FromUI);


		//Investigation Type investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("Investigation Type investigation details from Service response"+" "+ response_InvestigationDetails.get("Request Type"));
		Assert.assertTrue(investigationStatus_FromUI.equals(response_InvestigationDetails.get("Request Type")), "Failed:Investigation Type investigation details are not verified from UI and Response");
		Assert.assertTrue(investigationStatus_FromUI.equals(expRespDB), "Failed:Investigation Type investigation details are not verified from UI and Data base through data sheet.");
		Log.info("Investigation Type investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" Comments of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_Comments_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("Comments investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String comments_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCommentsUI();
		System.out.println("Comments investigate status from UI"+" "+ comments_Investigate_FromUI);


		//Comments investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("Comments investigation details from Service response"+" "+ response_InvestigationDetails.get("Comment"));
		Assert.assertTrue(comments_Investigate_FromUI.equals(response_InvestigationDetails.get("Comment")), "Failed:Comments investigation details are not verified from UI and Response");
		Assert.assertTrue(comments_Investigate_FromUI.equals(expRespDB), "Failed:Comments investigation details are not verified from UI and Data base through data sheet.");
		Log.info("Comments investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" submitter id of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_SubmitterID_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("SubmitterID investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String SubmitterID_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getSubmitterIDUI();
		System.out.println("SubmitterID investigate status from UI"+" "+ SubmitterID_Investigate_FromUI);


		//SubmitterID investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("SubmitterID investigation details from Service response"+" "+ response_InvestigationDetails.get("SubmitterId"));
		Assert.assertTrue(SubmitterID_Investigate_FromUI.equals(response_InvestigationDetails.get("SubmitterId")), "Failed:SubmitterID investigation details are not verified from UI and Response");
		Assert.assertTrue(SubmitterID_Investigate_FromUI.equals(expRespDB), "Failed:SubmitterID investigation details are not verified from UI and Data base through data sheet.");
		Log.info("SubmitterID investigation details are verified from UI ,Service response and Database.");

	}

	
	@When("^Verify the \"([^\"]*)\" Status of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_Status_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("Status investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String status_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getStatusUI();
		System.out.println("Status investigate status from UI"+" "+ status_Investigate_FromUI);


		//Status investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("Status investigation details from Service response"+" "+ response_InvestigationDetails.get("Request Status"));
		Assert.assertTrue(status_Investigate_FromUI.equals(response_InvestigationDetails.get("Request Status")), "Failed:Status investigation details are not verified from UI and Response");
		Assert.assertTrue(status_Investigate_FromUI.equals(expRespDB), "Failed:Status investigation details are not verified from UI and Data base through data sheet.");
		Log.info("Status investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM User of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_FM_User_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("FM User investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String fmUser_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getFMUserUI();
		System.out.println("FM User investigate status from UI"+" "+ fmUser_Investigate_FromUI);


		//FM User investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("FM User investigation details from Service response"+" "+ response_InvestigationDetails.get("User Id"));
		Assert.assertTrue(fmUser_Investigate_FromUI.equals(response_InvestigationDetails.get("User Id")), "Failed:FM User investigation details are not verified from UI and Response");
		Assert.assertTrue(fmUser_Investigate_FromUI.equals(expRespDB), "Failed:FM User investigation details are not verified from UI and Data base through data sheet.");
		Log.info("FM User investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM Date of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_FM_Date_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("FM Date investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String fmDate_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getFMDateUI();
		System.out.println("FM Date investigate status from UI"+" "+ fmDate_Investigate_FromUI);


		//FM Date investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("FM Date investigation details from Service response"+" "+ response_InvestigationDetails.get("FM Date"));
		Assert.assertTrue(fmDate_Investigate_FromUI.equals(response_InvestigationDetails.get("FM Date")), "Failed:FM Date investigation details are not verified from UI and Response");
		Assert.assertTrue(fmDate_Investigate_FromUI.equals(expRespDB), "Failed:FM Date investigation details are not verified from UI and Data base through data sheet.");
		Log.info("FM Date investigation details are verified from UI ,Service response and Database.");

	}
	
	@When("^Verify the \"([^\"]*)\" FM Time of Investigation status from service response , COB details screen and from DB$")
	public void verify_The_FM_Time_From_Investigation_Status_from_Response_COB_Screen_And_DataBase(String claimTypeInvestigateExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimTypeInvestigateExpResponse.length() >0 && claimTypeInvestigateExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimTypeInvestigateExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimTypeInvestigateExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		String expRespDB =  claimTypeInvestigateExpResponse;
		System.out.println("FM Date investigate status Expected Response from DB through DataSheet"+" "+expRespDB);

		String fmTime_Investigate_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getFMTimeUI();
		System.out.println("FM Time investigate status from UI"+" "+ fmTime_Investigate_FromUI);


		//FM Time investigation status validation Response from Service
		Map<String,String> response_InvestigationDetails = getPage(COBCarrierDetailsRestAPIValidations.class).investigationDetailsResp(attributes);
		System.out.println("FM Time investigation details from Service response"+" "+ response_InvestigationDetails.get("FM Time"));
		Assert.assertTrue(fmTime_Investigate_FromUI.equals(response_InvestigationDetails.get("FM Time")), "Failed:FM Time investigation details are not verified from UI and Response");
		Assert.assertTrue(fmTime_Investigate_FromUI.equals(expRespDB), "Failed:FM Time investigation details are not verified from UI and Data base through data sheet.");
		Log.info("FM Time investigation details are verified from UI ,Service response and Database.");

	}

}







