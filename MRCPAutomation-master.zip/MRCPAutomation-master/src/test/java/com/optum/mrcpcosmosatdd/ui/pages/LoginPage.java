package com.optum.mrcpcosmosatdd.ui.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.optum.mrcpcosmosatdd.reporting.Log;

public class LoginPage extends BasePage {

	/*private By textField_Username = By.id("USER");
	private By textField_Password = By.id("Password");*/
	private By textField_Username = By.id("username");
	private By textField_Password = By.id("password");
	private By button_Login = By.xpath(".//button[contains(text(),'Submit')]");
	/*private By textField_Username = By.id("varUserId");
	private By textField_Password = By.id("varPasswordMask");
	private By button_Login = By.id("varLoginBtn");*/
	private By label_ErrorMsg = By.xpath(".//form[@name='Login']");

	/*
	 * Login the Test application 
	 * @param username
	 * @param password
	 */
	public String login(String username, String password) {
		Log.info("Login page opened");
		try {
			// Enter User Name
			WebElement userName = driver.findElement(textField_Username);
			userName.clear();
			userName.sendKeys(username);
			Log.info("Entered username: " + username);
			// Enter Password
			WebElement passWord = driver.findElement(textField_Password);
			passWord.clear();
			passWord.sendKeys(password);
			Log.info("Entered Passsword");
			// Click on the Sign In Button
			WebElement signin = driver.findElement(button_Login);
			signin.click();
			Log.info("Clicked on Login button");
			Set<String> windowHandles = driver.getWindowHandles();
			if(windowHandles.size()>1) {
				Log.info("New Window opened up");
				return "Logged In";
			}
			else {
				Log.error("New Window not opened");
				return "Not Logged In";
			}
		}
		catch(Exception e) {
			Log.error("Error Occurred");
			return "Not Logged In";
		}
	}

	public boolean switchWindow() throws InterruptedException {
		Set<String> windowHandles = driver.getWindowHandles();
		if(windowHandles.size()>1) {
			String firstWinHandle = driver.getWindowHandle();
			String secondWinHandle;

			windowHandles.remove(firstWinHandle);
			String winHandle=windowHandles.iterator().next();
			if (winHandle!=firstWinHandle){
				secondWinHandle=winHandle;
				driver.switchTo().window(secondWinHandle);
				driver.manage().window().maximize();
				waitForPageToLoad();
				return true;
			}
			else {
				Log.error("Single Window is there");
				return false;
			}
		}
		else {
			Log.error("New Window/popup not opened");
			return false;
		}
	}

	/*
	 * Return the error message displayed on Login page if logged in using wrong user credentials
	 * 
	 * @return
	 */
	public String getErrorMessage() {
		WebElement errorEle = driver.findElement(label_ErrorMsg);
		return errorEle.getText();
	}
}