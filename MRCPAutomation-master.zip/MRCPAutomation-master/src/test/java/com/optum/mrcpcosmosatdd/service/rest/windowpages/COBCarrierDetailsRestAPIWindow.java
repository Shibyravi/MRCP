package com.optum.mrcpcosmosatdd.service.rest.windowpages;

import static io.restassured.RestAssured.baseURI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.common.JWTToken;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

import io.restassured.RestAssured;

public class COBCarrierDetailsRestAPIWindow extends BasePage {

	private By windowRootEle = By.id("COBCarrierDetailsWindow");


	//Input fields elements
	private By auditNo_HospAdjusmtnet = By.id("hospAdjAuditNumberId");
	private By input_Member = By.id("cobRecarrierMemberNumber");
	private By input_Site = By.id("cobRecarrierSite");
	private By input_AuditNbr = By.className("audit_span");
	private By input_AsOfDt = By.id("cobRecarrierAsOfDate");
	private By input_ToDt = By.id("cobRecarriertoDate");
	private By input_CobOtherCarrier = By.id("cob_other_Carrier");
	private By underlined_Headers = By.xpath(".//cob-element//tr//th");
	private By Error_MsgBar = By.id("CobDetailErrorMsgBar");
	private By text_Gender = By.className("cob_gender");
	private By dob_Value = By.className("dateofBirth");
	private By auditNbr_Value = By.className("audit_span");
	private By input_ClaimType = By.className("claim_span");
	private By value_MemFullName = By.className("mem_name");
	private By value_CarrierName0 = By.id("carrierName_0");
	private By value_PolicyNbr0 = By.id("policyNumber_0");
	private By value_OthrPlan0 = By.id("otherPlanInfo_0");
	private By value_CarrierName2 = By.id("carrierName_2");
	private By value_PolicyNbr2 = By.id("policyNumber_2");
	private By value_OthrPlan2 = By.id("otherPlanInfo_2");
	private By errorMsgBar_COB = By.xpath("(.//input[@id='CobDetailErrorMsgBar'])[1]");



	//investigation status
	private By auditNbr_Invest = By.id("lobAudit");
	private By claimType_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[2]/span");
	private By investigationType_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[3]/span");
	private By commentSection_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[4]/span");
	private By submitterID_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[5]/span");
	private By status_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[6]/span");
	private By fmUser_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[7]/span");
	private By fmDate_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[8]/span");
	private By fmTime_Invest = By.xpath("//*[@id='cob_Data']/tbody/tr/td[9]/span");


	//Buttons
	private By buttons_Inquire = By.id("cobDetailsInquire");
	private By buttons_Add = By.id("cobDetailsAdd");
	private By buttons_Change = By.id("cobDetailsChange");
	private By buttons_Close = By.id("cobDetailsClose");
	private By buttons_Investigate = By.id("cobDetailsInvestigate");

	private By underlined_Labels = By.xpath(".//*[@id='COBCarrierDetailsWindow']//span");

	//Radio button
	private By radio_ActiveEdit = By.id("cobCarriersRadioPhy");
	private By radio_EditHistory = By.id("cobCarriersRadioHosp");

	private By radio_ActiveEdits = By.xpath(".//label[text()='Active Edits']//following-sibling::input[@type='radio']");

	//Dropdown fields
	private By dropdown_LOB = By.id("cob_lob_select");
	private By dropdown_ReqType = By.id("cob_req_select");
	private By dropdown_Comments = By.id("cob_comment_select");

	// Other Insurance Section
	private By primacy_Dropdown = By.id("primacy_0");
	private By CovType_Dropdown = By.id("covType_0");
	private By CarrierType_Dropdown = By.id("carrierType_0");
	private By CarrierNumber_Text = By.id("number_0");
	private By CarrierName_Text = By.id("carrierName_0");
	private By Eff_DT_Text = By.id("effDt_0");
	private By Exp_Dt_Text = By.id("expDt_0");
	private By PolicyGrp_Nbr = By.id("policyNumber_0");
	private By CommuRsn_Dropdown = By.id("expRsn_0");
	private By OthrUHCPlanInfo = By.id("otherPlanInfo_0");

	//Recovery Section
	private By incidentDt_Dropdown = By.id("recoveryIncDt_0");
	private By CarrierType_Dropdown_Recovery = By.id("recoveryCarrierType_0");
	private By CarrierNumber_Text_Recovery = By.id("recoveryCarrierNbr_0");
	private By CarrierName_TextRecovery = By.id("recoveryCarrierName_0");
	private By Eff_DT_TextRecovery = By.id("recoveryEffDt_0");
	private By Exp_Dt_TextRecovery = By.id("recoveryExpDt_0");
	private By PolicyGrp_NbrRecovery = By.id("policyGrp_0");
	private By CommuRsn_DropdownRecovery = By.id("recoveryRsn_0");
	private By ApportPect_Recovery = By.id("recoveryApportionment_0");
	private By Diagnosis_Desc_Recovery = By.id("recoveryDiagDesc_0");
	private By BL_Recovery = By.id("blackLung_0");
	private By I_Recovery = By.id("recoveryICDANum_0");
	private By ICDA1_Recovery = By.id("recoveryICDA1_0");
	private By ICDA2_Recovery = By.id("recoveryICDA2_0");
	private By ICDA3_Recovery = By.id("recoveryICDA3_0");
	private By ICDA4_Recovery = By.id("recoveryICDA4_0");
	private By ICDA5_Recovery = By.id("recoveryICDA5_0");
	private By ICDA6_Recovery = By.id("recoveryICDA6_0");
	private By ICDA7_Recovery = By.id("recoveryICDA7_0");
	private By ICDA8_Recovery = By.id("recoveryICDA8_0");
	private By ICDA9_Recovery = By.id("recoveryICDA9_0");
	private By ICDA10_Recovery = By.id("recoveryICDA10_0");
	private By CarrierName2_TextRecovery = By.id("recoveryCarrierName_2");
	private By Eff_DT_TextRecovery2 = By.id("recoveryEffDt_2");
	private By Exp_Dt_TextRecovery2 = By.id("recoveryExpDt_2");
	private By PolicyGrp_NbrRecovery2 = By.id("policyGrp_2");
	private By CommuRsn_DropdownRecovery2 = By.id("recoveryRsn_2");
	private By ApportPect_Recovery2 = By.id("recoveryApportionment_2");
	private By Diagnosis_Desc_Recovery2 = By.id("recoveryDiagDesc_2");


	public By getWindowRoot() {
		return windowRootEle;
	}

	public boolean performInquire(String memberNBR, String memSite, String asOfDate, String activeEdit) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			Map<String,String> headerAtt = new HashMap();
			//Enter the Member number 
			enterText(input_Member, memberNBR); 
			//Enter the site
			enterText(input_Site, memSite);
			//Enter the From Date
			enterText(input_AsOfDt, asOfDate);
			//Select the Active Edits
			if(activeEdit.equals("true"))
			{
				if(isElementSelected(radio_ActiveEdit))
				{
					Log.info("Active Edit radio button is selsected");
				}
				else
				{
					Assert.assertTrue(selectRadioButton(radio_ActiveEdit));
				}
			}

			//Click on Inquire Button
			mouseClick(buttons_Inquire);
			Thread.sleep(20000);
			System.out.println(driver.findElement(Error_MsgBar).getAttribute("value"));
			//Assert.assertTrue(driver.findElement(MsgBar).getText().equals("Successfully Inquired"), "Failed: Inquiry is failed");
			Log.info("Verified:Inquiry is successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}

	public String getMemberNbr()
	{
		String memNbr = "";
		try {

			memNbr =  driver.findElement(input_Member).getAttribute("value");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return memNbr;


	}

	public List<String> getMemberDetails()
	{
		String memNbr = "";
		String site="";
		String asOfDate="";

		String gender="";
		String dob="";
		String auditNumber="";
		String middleName="";
		String firstName="";
		String lastName="";
		String fullmemberName="";
		String claimType = "";
		List<String> memDetails_Actual = new ArrayList();
		try {

			memNbr =  driver.findElement(input_Member).getAttribute("value");
			site = driver.findElement(input_Site).getAttribute("value");
			asOfDate =	driver.findElement(input_AsOfDt).getAttribute("value");
			gender =	driver.findElement(text_Gender).getText();
			dob =	driver.findElement(dob_Value).getText();
			auditNumber = driver.findElement(input_AuditNbr).getText();
			claimType = driver.findElement(input_ClaimType).getText();
			fullmemberName = driver.findElement(value_MemFullName).getText();
			String memNameArray[] = fullmemberName.split(" ");

			for(int i=0;i<memNameArray.length;i++)
			{
				if(!memNameArray[i].equals(","))  
				{
					memDetails_Actual.add(memNameArray[i]);
				}
			}
			//memDetails_Actual.addAll(Arrays.asList(memNameArray));
			memDetails_Actual.add(memNbr);
			memDetails_Actual.add(site);
			memDetails_Actual.add(asOfDate);
			memDetails_Actual.add(gender);
			memDetails_Actual.add(dob);
			memDetails_Actual.add(auditNumber);
			memDetails_Actual.add(claimType);
			memDetails_Actual.removeAll(Arrays.asList("", null));
			Collections.sort(memDetails_Actual);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return memDetails_Actual;
	}

	public Map<String,List<String>> getCarrierDetailsUI()
	{	
		Map<String,List<String>> carrierDetailsValues = new HashMap();
		List<String> lstPrimacy = new ArrayList();
		List<String> lstCovType = new ArrayList();
		List<String> lstCarrierType = new ArrayList();
		List<String> lstCarrierNbr = new ArrayList();
		List<String> lstCarrierName = new ArrayList();
		List<String> lstEffDate = new ArrayList();
		List<String> lstExpDt = new ArrayList(); 
		List<String> lstPolicyNbr = new ArrayList();
		List<String> lstCommnRsn = new ArrayList();
		List<String> lstOthrUHCInfo = new ArrayList();
		List<String> lstFmUser = new ArrayList();
		List<String> lstFMDate = new ArrayList();
		List<String> lstFmTime = new ArrayList();


		//find out the total number of rows in carrier detail section
		try{
			int noOfRows = driver.findElements(By.xpath(".//*[@id='COBCarrierDetailsWindow']//table[@id='cob_his_mainTable']//tbody//tr")).size();

			System.out.println("total number of rows in carrier details:"+" "+ noOfRows);
			String [] primacy = new String[noOfRows];
			String [] cov_Type = new String[noOfRows];
			String [] carrier_Type=new String[noOfRows];
			String [] carrier_Number=new String[noOfRows];
			String [] carrier_Name = new String[noOfRows];
			String [] Eff_Date = new String[noOfRows];
			String [] Exp_Date = new String[noOfRows];
			String [] policyNumber = new String[noOfRows];
			String [] commnRsn = new String[noOfRows];
			String [] otherUHCPlan = new String[noOfRows];
			String [] fmUser = new String[noOfRows];
			String [] fmDt = new String[noOfRows];
			String [] fmTime = new String[noOfRows];

			//Get the detail values
			for(int i=0;i<noOfRows;i++)
			{
				Select selectPrimacy = new Select(driver.findElement(By.id("primacy_"+i+"")));
				//if(!(selectPrimacy.getFirstSelectedOption().getText().equals("")||selectPrimacy.getFirstSelectedOption().getText().length()<0))
				primacy[i] = selectPrimacy.getFirstSelectedOption().getText();

				lstPrimacy.add(primacy[i] );

				Select selectCovType = new Select(driver.findElement(By.id("covType_"+i+"")));
				cov_Type[i] = selectCovType.getFirstSelectedOption().getText();
				lstCovType.add(cov_Type[i]);

				Select selectCarrierType = new Select(driver.findElement(By.id("carrierType_"+i+"")));
				carrier_Type[i] = selectCarrierType.getFirstSelectedOption().getText();
				lstCarrierType.add(carrier_Type[i]);

				//if(!(driver.findElement(By.id("number_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("number_"+i+"")).getAttribute("value").length()<0))
				carrier_Number[i] = driver.findElement(By.id("number_"+i+"")).getAttribute("value");
				lstCarrierNbr.add(carrier_Number[i]);
				//System.out.println("Carrier Details Carrier number values:"+ " "+ carrier_Number[i]);
				//if(!(driver.findElement(By.id("carrierName_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("carrierName_"+i+"")).getAttribute("value").length()<0))
				carrier_Name[i] = driver.findElement(By.id("carrierName_"+i+"")).getAttribute("value");
				lstCarrierName.add(carrier_Name[i]);
				//System.out.println("Carrier Details Carrier name values:"+ " "+ carrier_Name[i]);
				//if(!(driver.findElement(By.id("effDt_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("effDt_"+i+"")).getAttribute("value").length()<0))
				Eff_Date[i] = driver.findElement(By.id("effDt_"+i+"")).getAttribute("value");
				lstEffDate.add(Eff_Date[i]);
				//System.out.println("Carrier Details Eff Date values:"+ " "+ Eff_Date[i]);
				//if(!(driver.findElement(By.id("expDt_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("expDt_"+i+"")).getAttribute("value").length()<0))
				Exp_Date[i] = driver.findElement(By.id("expDt_"+i+"")).getAttribute("value");
				lstExpDt.add(Exp_Date[i]);
				//System.out.println("Carrier Details Exp date values:"+ " "+ Exp_Date[i]);
				//if(!(driver.findElement(By.id("policyNumber_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("policyNumber_"+i+"")).getAttribute("value").length()<0))
				policyNumber[i] = driver.findElement(By.id("policyNumber_"+i+"")).getAttribute("value");
				lstPolicyNbr.add(policyNumber[i]);
				//System.out.println("Carrier Details policy number values:"+ " "+ policyNumber[i]);
				Select selectCommRsn = new Select(driver.findElement(By.id("expRsn_"+i+"")));
				//if(!(selectPrimacy.getFirstSelectedOption().getText().equals("")||selectPrimacy.getFirstSelectedOption().getText().length()<0))
				commnRsn[i] = selectCommRsn.getFirstSelectedOption().getText();
				lstCommnRsn.add(commnRsn[i]);
				//System.out.println("Carrier Details commu Rsn values:"+ " "+ commnRsn[i]);
				//if(!(driver.findElement(By.id("otherPlanInfo_"+i+"")).getAttribute("value").equals("")||driver.findElement(By.id("otherPlanInfo_"+i+"")).getAttribute("value").length()<0))
				otherUHCPlan[i] = driver.findElement(By.id("otherPlanInfo_"+i+"")).getAttribute("value");
				lstOthrUHCInfo.add(otherUHCPlan[i]);
				//System.out.println("Carrier Details other UHC info values:"+ " "+ otherUHCPlan[i]);
				fmUser[i] = driver.findElement(By.id("fmUser_"+i+"")).getText();
				lstFmUser.add(fmUser[i]);
				fmDt[i] = driver.findElement(By.id("fmDate_"+i+"")).getText();
				lstFMDate.add(fmDt[i]);
				fmTime[i] = driver.findElement(By.id("fmTime_"+i+"")).getText();
				lstFmTime.add(fmTime[i]);
			}
			lstPrimacy.removeAll(Arrays.asList("", null));
			lstCovType.removeAll(Arrays.asList("", null));
			lstCarrierType.removeAll(Arrays.asList("", null));
			lstCarrierNbr.removeAll(Arrays.asList("", null));
			lstCarrierName.removeAll(Arrays.asList("", null));
			lstEffDate.removeAll(Arrays.asList("", null));
			lstExpDt.removeAll(Arrays.asList("", null));
			lstPolicyNbr.removeAll(Arrays.asList("", null));
			lstCommnRsn.removeAll(Arrays.asList("", null));
			lstOthrUHCInfo.removeAll(Arrays.asList("", null));
			lstFmUser.removeAll(Arrays.asList("", null));
			lstFMDate.removeAll(Arrays.asList("", null));
			lstFmTime.removeAll(Arrays.asList("", null));

			carrierDetailsValues.put("Primacy", lstPrimacy);
			carrierDetailsValues.put("CovType", lstCovType);
			carrierDetailsValues.put("CarrierType", lstCarrierType);
			carrierDetailsValues.put("CarrierNumber", lstCarrierNbr);
			carrierDetailsValues.put("CarrierName", lstCarrierName);
			carrierDetailsValues.put("Eff Date", lstEffDate);
			carrierDetailsValues.put("Exp Date", lstExpDt);
			carrierDetailsValues.put("Policy Number", lstPolicyNbr);
			carrierDetailsValues.put("Communication Rsn", lstCommnRsn);
			carrierDetailsValues.put("OtherUHCInfo", lstOthrUHCInfo);
			carrierDetailsValues.put("FM User", lstFmUser);
			carrierDetailsValues.put("FM Date", lstFMDate);
			carrierDetailsValues.put("FM Time", lstFmTime);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}


		return carrierDetailsValues;
	}


	public Map<String,List<String>> getRecoveryDetailsUI()
	{	
		Map<String,List<String>> recoveryDetailsValues = new HashMap();
		List<String> lstIncidentDtRec = new ArrayList();
		List<String> lstCarrierTypeRec = new ArrayList();
		List<String> lstCarrierNbrRec = new ArrayList();
		List<String> lstCarrierNameRec = new ArrayList();
		List<String> lstEffDateRec = new ArrayList();
		List<String> lstExpDtRec = new ArrayList();
		List<String> lstPolicyNbrRec = new ArrayList();
		List<String> lstCommnRsnRec = new ArrayList();
		List<String> lstApportPectRec = new ArrayList();
		List<String> lstDiagDescRec = new ArrayList();
		List<String> lstICDANumRec = new ArrayList();
		List<String> lstICDA1Rec = new ArrayList();
		List<String> lstICDA2Rec = new ArrayList();
		List<String> lstICDA3Rec = new ArrayList();
		List<String> lstICDA4Rec = new ArrayList();
		List<String> lstICDA5Rec = new ArrayList();
		List<String> lstICDA6Rec = new ArrayList();
		List<String> lstICDA7Rec = new ArrayList();
		List<String> lstICDA8Rec = new ArrayList();
		List<String> lstICDA9Rec = new ArrayList();
		List<String> lstICDA10Rec = new ArrayList();
		List<String> lstFmUserRec = new ArrayList();
		List<String> lstFMDateRec = new ArrayList();
		List<String> lstFmTimeRec = new ArrayList();


		//find out the total number of rows in Recovery detail section
		try{
			int noOfRows = driver.findElements(By.xpath(".//*[@id='COBCarrierDetailsWindow']//table[@id='cob_recoveryTable']//tbody//tr")).size();

			System.out.println("total number of rows in recovery details:"+" "+ noOfRows);
			String [] incident_DtREC = new String[noOfRows];
			String [] carrier_Type_Rec=new String[noOfRows];
			String [] carrier_Number_Rec=new String[noOfRows];
			String [] carrier_Name_Rec = new String[noOfRows];
			String [] Eff_Date_Rec = new String[noOfRows];
			String [] Exp_Date_Rec = new String[noOfRows];
			String [] policyNumber_Rec = new String[noOfRows];
			String [] commnRsn_Rec = new String[noOfRows];
			String [] apport_Pect_Rec = new String[noOfRows];
			String [] diag_Desc_Rec = new String[noOfRows];
			String [] icda_Num_Rec = new String[noOfRows];
			String [] icda1_Rec = new String[noOfRows];
			String [] icda2_Rec = new String[noOfRows];
			String [] icda3_Rec = new String[noOfRows];
			String [] icda4_Rec = new String[noOfRows];
			String [] icda5_Rec = new String[noOfRows];
			String [] icda6_Rec = new String[noOfRows];
			String [] icda7_Rec = new String[noOfRows];
			String [] icda8_Rec = new String[noOfRows];
			String [] icda9_Rec = new String[noOfRows];
			String [] icda10_Rec = new String[noOfRows];
			String [] fmUser_Rec = new String[noOfRows];
			String [] fmDt_Rec = new String[noOfRows];
			String [] fmTime_Rec = new String[noOfRows];

			//Get the recovery detail values
			for(int i=0;i<noOfRows;i++)
			{
				incident_DtREC[i] = driver.findElement(By.id("recoveryIncDt_"+i+"")).getAttribute("value");
				lstIncidentDtRec.add(incident_DtREC[i]);

				Select slt_CarrTypeRec = new Select(driver.findElement(By.id("recoveryCarrierType_"+i+"")));
				carrier_Type_Rec[i] = slt_CarrTypeRec.getFirstSelectedOption().getText();
				lstCarrierTypeRec.add(carrier_Type_Rec[i]);

				carrier_Number_Rec[i] = driver.findElement(By.id("recoveryCarrierNbr_"+i+"")).getAttribute("value");
				lstCarrierNbrRec.add(carrier_Number_Rec[i]);

				carrier_Name_Rec[i] = driver.findElement(By.id("recoveryCarrierName_"+i+"")).getAttribute("value");
				lstCarrierNameRec.add(carrier_Name_Rec[i]);

				Eff_Date_Rec[i] = driver.findElement(By.id("recoveryEffDt_"+i+"")).getAttribute("value");
				lstEffDateRec.add(Eff_Date_Rec[i]);

				Exp_Date_Rec[i] = driver.findElement(By.id("recoveryExpDt_"+i+"")).getAttribute("value");
				lstExpDtRec.add(Exp_Date_Rec[i]);

				policyNumber_Rec[i] = driver.findElement(By.id("policyGrp_"+i+"")).getAttribute("value");
				lstPolicyNbrRec.add(policyNumber_Rec[i]);

				Select selectCommRsnRec = new Select(driver.findElement(By.id("recoveryRsn_"+i+"")));
				commnRsn_Rec[i] = selectCommRsnRec.getFirstSelectedOption().getText();
				lstCommnRsnRec.add(commnRsn_Rec[i]);

				apport_Pect_Rec[i] = driver.findElement(By.id("recoveryApportionment_"+i+"")).getAttribute("value");
				lstApportPectRec.add(apport_Pect_Rec[i]);

				diag_Desc_Rec[i] = driver.findElement(By.id("recoveryDiagDesc_"+i+"")).getAttribute("value");
				lstDiagDescRec.add(diag_Desc_Rec[i]);

				icda_Num_Rec[i] = driver.findElement(By.id("recoveryICDANum_"+i+"")).getAttribute("value");
				lstICDANumRec.add(icda_Num_Rec[i]);

				icda1_Rec[i] = driver.findElement(By.id("recoveryICDA1_"+i+"")).getAttribute("value");
				lstICDA1Rec.add(icda1_Rec[i]);

				icda2_Rec[i] = driver.findElement(By.id("recoveryICDA2_"+i+"")).getAttribute("value");
				lstICDA2Rec.add(icda2_Rec[i]);

				icda3_Rec[i] = driver.findElement(By.id("recoveryICDA3_"+i+"")).getAttribute("value");
				lstICDA3Rec.add(icda3_Rec[i]);

				icda4_Rec[i] = driver.findElement(By.id("recoveryICDA4_"+i+"")).getAttribute("value");
				lstICDA4Rec.add(icda4_Rec[i]);

				icda5_Rec[i] = driver.findElement(By.id("recoveryICDA5_"+i+"")).getAttribute("value");
				lstICDA5Rec.add(icda5_Rec[i]);

				icda6_Rec[i] = driver.findElement(By.id("recoveryICDA6_"+i+"")).getAttribute("value");
				lstICDA6Rec.add(icda6_Rec[i]);

				icda7_Rec[i] = driver.findElement(By.id("recoveryICDA7_"+i+"")).getAttribute("value");
				lstICDA7Rec.add(icda7_Rec[i]);

				icda8_Rec[i] = driver.findElement(By.id("recoveryICDA8_"+i+"")).getAttribute("value");
				lstICDA8Rec.add(icda8_Rec[i]);

				icda9_Rec[i] = driver.findElement(By.id("recoveryICDA9_"+i+"")).getAttribute("value");
				lstICDA9Rec.add(icda9_Rec[i]);

				icda10_Rec[i] = driver.findElement(By.id("recoveryICDA10_"+i+"")).getAttribute("value");
				lstICDA10Rec.add(icda10_Rec[i]);

				fmUser_Rec[i] = driver.findElement(By.id("RecoveryfmUserId_"+i+"")).getText();
				lstFmUserRec.add(fmUser_Rec[i]);

				fmDt_Rec[i] = driver.findElement(By.id("RecoveryfmUserDate_"+i+"")).getText();
				lstFMDateRec.add(fmDt_Rec[i]);

				fmTime_Rec[i] = driver.findElement(By.id("RecoveryfmUserTime_"+i+"")).getText();
				lstFmTimeRec.add(fmTime_Rec[i]);
			}
			lstIncidentDtRec.removeAll(Arrays.asList("", null));
			lstCarrierTypeRec.removeAll(Arrays.asList("", null));
			lstCarrierNbrRec.removeAll(Arrays.asList("", null));
			lstCarrierNameRec.removeAll(Arrays.asList("", null));
			lstEffDateRec.removeAll(Arrays.asList("", null));
			lstExpDtRec.removeAll(Arrays.asList("", null));
			lstPolicyNbrRec.removeAll(Arrays.asList("", null));
			lstCommnRsnRec.removeAll(Arrays.asList("", null));
			lstApportPectRec.removeAll(Arrays.asList("", null));
			lstDiagDescRec.removeAll(Arrays.asList("", null));
			lstICDANumRec.removeAll(Arrays.asList("", null));
			lstICDA1Rec.removeAll(Arrays.asList("", null));
			lstICDA2Rec.removeAll(Arrays.asList("", null));
			lstICDA3Rec.removeAll(Arrays.asList("", null));
			lstICDA4Rec.removeAll(Arrays.asList("", null));
			lstICDA5Rec.removeAll(Arrays.asList("", null));
			lstICDA6Rec.removeAll(Arrays.asList("", null));
			lstICDA7Rec.removeAll(Arrays.asList("", null));
			lstICDA8Rec.removeAll(Arrays.asList("", null));
			lstICDA9Rec.removeAll(Arrays.asList("", null));
			lstICDA10Rec.removeAll(Arrays.asList("", null));
			lstFmUserRec.removeAll(Arrays.asList("", null));
			lstFMDateRec.removeAll(Arrays.asList("", null));
			lstFmTimeRec.removeAll(Arrays.asList("", null));


			recoveryDetailsValues.put("IncidentDT", lstIncidentDtRec);
			recoveryDetailsValues.put("CarrierTypeRec", lstCarrierTypeRec);
			recoveryDetailsValues.put("CarrierNumberRec", lstCarrierNbrRec);
			recoveryDetailsValues.put("CarrierNameRec", lstCarrierNameRec);
			recoveryDetailsValues.put("Eff Date Rec", lstEffDateRec);
			recoveryDetailsValues.put("Exp Date Rec", lstExpDtRec);
			recoveryDetailsValues.put("Policy Number Rec", lstPolicyNbrRec);
			recoveryDetailsValues.put("Communication Rsn Rec", lstCommnRsnRec);
			recoveryDetailsValues.put("Apport Pect Rec", lstApportPectRec);
			recoveryDetailsValues.put("Diag Desc Rec", lstDiagDescRec);
			recoveryDetailsValues.put("ICDA Num Rec", lstICDANumRec);
			recoveryDetailsValues.put("ICDA1 Rec", lstICDA1Rec);
			recoveryDetailsValues.put("ICDA2 Rec", lstICDA2Rec);
			recoveryDetailsValues.put("ICDA3 Rec", lstICDA3Rec);
			recoveryDetailsValues.put("ICDA4 Rec", lstICDA4Rec);
			recoveryDetailsValues.put("ICDA5 Rec", lstICDA5Rec);
			recoveryDetailsValues.put("ICDA6 Rec", lstICDA6Rec);
			recoveryDetailsValues.put("ICDA7 Rec", lstICDA7Rec);
			recoveryDetailsValues.put("ICDA8 Rec", lstICDA8Rec);
			recoveryDetailsValues.put("ICDA9 Rec", lstICDA9Rec);
			recoveryDetailsValues.put("ICDA10 Rec", lstICDA10Rec);
			recoveryDetailsValues.put("FM User Rec", lstFmUserRec);
			recoveryDetailsValues.put("FM Date Rec", lstFMDateRec);
			recoveryDetailsValues.put("FM Time Rec", lstFmTimeRec);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}


		return recoveryDetailsValues;
	}

	public String getAuditNbrInvestigateUI()
	{
		String auditNbr = null;
		try {
			auditNbr = driver.findElement(auditNbr_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return auditNbr;
	}

	public String getClaimTypeInvestigateUI()
	{
		String clmType = null;
		try {
			clmType = driver.findElement(claimType_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return clmType;
	}

	public String getCommentsUI()
	{
		String comments = null;
		try {
			comments = driver.findElement(commentSection_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return comments;
	}
	
	public String getSubmitterIDUI()
	{
		String submitterID = null;
		try {
			submitterID = driver.findElement(submitterID_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return submitterID;
	}

	public String getInvestigationTypeUI()
	{
		String investigationType = null;
		try {
			investigationType = driver.findElement(investigationType_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return investigationType;
	}

	public String getStatusUI()
	{
		String status = null;
		try {
			status = driver.findElement(status_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return status;
	}

	public String getFMUserUI()
	{
		String fmUser = null;
		try {
			fmUser = driver.findElement(fmUser_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return fmUser;
	}

	public String getFMDateUI()
	{
		String fmDate = null;
		try {
			fmDate = driver.findElement(fmDate_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return fmDate;
	}

	public String getFMTimeUI()
	{
		String fmTime = null;
		try {
			fmTime = driver.findElement(fmTime_Invest).getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();	
		}

		return fmTime;
	}

	public boolean changeInOthrInsuranceAndInquire(String fieldName, String updatedValue) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			if(fieldName.equals("Carrier Name"))
			{
				enterText(value_CarrierName0, updatedValue);
			}
			else if(fieldName.equals("Policy Number"))
			{
				enterText(value_PolicyNbr0, updatedValue);
			}
			else if(fieldName.equals("Other Plan"))
			{
				enterText(value_OthrPlan0, updatedValue);
			}
			else if(fieldName.equals("Carrier Name Rec"))
			{
				enterText(CarrierName_TextRecovery, updatedValue);
			}
			else if(fieldName.equals("Policy Number Rec"))
			{
				enterText(PolicyGrp_NbrRecovery, updatedValue);
			}
			else if(fieldName.equals("Diag Desc Rec"))
			{
				enterText(Diagnosis_Desc_Recovery, updatedValue);
			}
			else if(fieldName.equals("ICDA2"))
			{
				enterText(ICDA2_Recovery, updatedValue);
			}
			else if(fieldName.equals("ICDA4"))
			{
				enterText(ICDA4_Recovery, updatedValue);
			}
			else if(fieldName.equals("ICDA5"))
			{
				enterText(ICDA5_Recovery, updatedValue);
			}
			else if(fieldName.equals("ICDA8"))
			{
				enterText(ICDA8_Recovery, updatedValue);
			}
			else if(fieldName.equals("ICDA10"))
			{
				enterText(ICDA10_Recovery, updatedValue);
			}

			else
			{
				System.out.println("Wrong field found");
				Assert.fail();
			}
			//click on change button
			mouseClick(buttons_Change);
			Thread.sleep(10000);
			//verify the message
			Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equals("Record Changed Successfully"), "Failed: Record did not changed successfully");
			Log.info("Verified:Record changed successfully");
			//again inquire the data for change validation
			mouseClick(buttons_Inquire);
			Thread.sleep(10000);
			//verify the message
			Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equals("Successfully inquired"), "Failed: Record did not inquired successfully");
			Log.info("Verified:Record inquired successfully");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}

	public boolean clearChangesInOthrInsuranceAndInquire(String fieldName) throws InterruptedException
	{
		waitForPageToLoad();
		try {
			if(fieldName.equals("Carrier Name"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(value_CarrierName0, "Carrier name");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("Policy Number"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(value_PolicyNbr0, "Policy number");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("Other Plan"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(value_OthrPlan0, "Other Plan");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("Carrier Name Rec"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(CarrierName_TextRecovery, "Carrier name Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("Policy Number Rec"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(PolicyGrp_NbrRecovery, "Policy Number Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("Diag Desc Rec"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(Diagnosis_Desc_Recovery, "Diagnosis desc Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("ICDA2"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(ICDA2_Recovery, "ICDA2 Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("ICDA4"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(ICDA4_Recovery, "ICDA4 Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("ICDA5"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(ICDA5_Recovery, "ICDA5 Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("ICDA8"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(ICDA8_Recovery, "ICDA8 Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else if(fieldName.equals("ICDA10"))
			{
				clickOnElement(input_Member, "Member number");
				clickOnElement(ICDA10_Recovery, "ICDA10 Recovery");
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");
			}
			else
			{
				System.out.println("Wrong field found");
				Assert.fail();
			}
			Thread.sleep(4000);
			//click on change button
			mouseClick(buttons_Change);
			Thread.sleep(15000);
			//verify the message
			Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equals("Record Changed Successfully"), "Failed: Record did not changed successfully");
			Log.info("Verified:Record changed successfully");
			//again inquire the data for change validation
			mouseClick(buttons_Inquire);
			waitForPageToLoad();
			Thread.sleep(15000);
			//verify the message
			Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equals("Successfully inquired"), "Failed: Record did not inquired successfully");
			Log.info("Verified:Record inquired successfully");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		} 

		return true;
	}

	public boolean validateErrorMessageforChnage(String fieldName, String updatedValue, String mandatoryField) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			if(fieldName.equals("Carrier Name"))
			{
				enterText(value_CarrierName2, updatedValue);
			}
			else if(fieldName.equals("Policy Number"))
			{
				enterText(value_PolicyNbr2, updatedValue);
			}
			else if(fieldName.equals("Other Plan"))
			{
				enterText(value_OthrPlan2, updatedValue);
			}
			else if(fieldName.equals("Carrier Name Rec"))
			{
				enterText(CarrierName_TextRecovery, updatedValue);
			}
			else if(fieldName.equals("Policy Number Rec"))
			{
				enterText(PolicyGrp_NbrRecovery2, updatedValue);
			}
			else if(fieldName.equals("Diag Desc Rec"))
			{
				enterText(Diagnosis_Desc_Recovery2, updatedValue);
			}
			else
			{
				System.out.println("Wrong field found");
				Assert.fail();
			}
			//make mandatory field as blank
			if(mandatoryField.equals("Carrier Number"))
			{
				KeyUtils.keyPressShiftPlusTab();
				KeyUtils.keyPressBackspace();
				clickOnElement(input_Member, "Member number");

				//click on change button
				mouseClick(buttons_Change);
				Thread.sleep(10000);
				//verify the message
				Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equals("No changes detected"), "Failed: Error message did not validated");
				Log.info("Verified:Error message validated successfully");
			}

			else if(mandatoryField.equals("Carrier Type"))
			{
				Select select = new Select(driver.findElement(CarrierType_Dropdown));
				select.selectByIndex(0);
				clickOnElement(input_Member, "Member number");

				//click on change button
				mouseClick(buttons_Change);
				Thread.sleep(10000);
				//verify the message
				Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equalsIgnoreCase("No changes detected"), "Failed: Error message did not validated");
				Log.info("Verified:Error message validated successfully");
			}

			else if(mandatoryField.equals("Cov Type"))
			{
				Select select = new Select(driver.findElement(CovType_Dropdown));
				select.selectByIndex(0);
				clickOnElement(input_Member, "Member number");

				//click on change button
				mouseClick(buttons_Change);
				Thread.sleep(10000);
				//verify the message
				Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equalsIgnoreCase("No changes detected"), "Failed: Error message did not validated");
				Log.info("Verified:Error message validated successfully");
			}

			else if(mandatoryField.equals("Primacy"))
			{
				Select select = new Select(driver.findElement(primacy_Dropdown));
				select.selectByIndex(0);
				clickOnElement(input_Member, "Member number");

				//click on change button
				mouseClick(buttons_Change);
				Thread.sleep(10000);
				//verify the message
				Assert.assertTrue(driver.findElement(errorMsgBar_COB).getAttribute("value").equalsIgnoreCase("No changes detected"), "Failed: Error message did not validated");
				Log.info("Verified:Error message validated successfully");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean performInquirehistory(String memberNBR, String memSite, String asOfDate ,String Edithistory) throws InterruptedException
	{
	   waitForPageToLoad();
	   Thread.sleep(15000);
	   try {
	      Map<String,String> headerAtt = new HashMap();
	      //Enter the Member number
	      enterText(input_Member, memberNBR);
	      //Enter the site
	      enterText(input_Site, memSite);
	      //Enter the From Date
	      enterText(input_AsOfDt, asOfDate);
	      //Select the Active Edits
	      if(Edithistory.equalsIgnoreCase("true"))


	      {
	         if(isElementSelected(radio_EditHistory))

	         {
	            Log.info("EditHistory radio button is selected");
	         }
	         else
	         {
	            Assert.assertTrue(selectRadioButton(radio_EditHistory));
	         }
	      }

	      //Click on Inquire Button
	      mouseClick(buttons_Inquire);
	      Thread.sleep(20000);
	      System.out.println(driver.findElement(Error_MsgBar).getAttribute("value"));
	      //Assert.assertTrue(driver.findElement(MsgBar).getText().equals("Successfully Inquired"), "Failed: Inquiry is failed");
	      Log.info("Verified:Inquiry is successfully");
	   }
	   catch(Exception e)
	   {
	      e.printStackTrace();
	      Assert.fail();
	   }

	   return true;
	}

}