package com.optum.mrcpcosmosatdd.services.rest;

import static io.restassured.RestAssured.baseURI;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;
import io.restassured.response.Response;
import io.restassured.RestAssured;





public class PauseReleaseAPIValidations {

    public static Response getJsonResponseAsJSONObjectforClaimPause(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
        RestAssured.baseURI ="http://claimdev-master.origin-ctc-core.optum.com";
        RequestSpecification request = RestAssured.given();
        request.contentType(ContentType.JSON);
        request.body(requestBody);
        Response response=request.request(Method.POST,"/claim-pause");
        // Response response = request.post("/claim-pause");


        return response;
    }

    //Return the Retrun message  response
    public Map<String,String> rtnStatus(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
    {

        Map<String,String> Pauseclaim_Resp= new HashMap();
        String rtncode ;
        String rtnStatus ;

        Response response = getJsonResponseAsJSONObjectforClaimPause(requestParams);

        JSONObject JSONOBJ= new JSONObject(response.getBody().asString());

        rtncode =JSONOBJ.getString("code");

       // System.out.println(rtncode);

        rtnStatus=JSONOBJ.getString("msg");

        //System.out.println(rtnStatus);

        Pauseclaim_Resp.put("code", rtncode);
        Pauseclaim_Resp.put("msg", rtnStatus);

        return Pauseclaim_Resp;
    }









}
