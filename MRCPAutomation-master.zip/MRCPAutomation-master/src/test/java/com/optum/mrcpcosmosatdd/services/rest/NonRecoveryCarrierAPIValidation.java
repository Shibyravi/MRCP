package com.optum.mrcpcosmosatdd.services.rest;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class NonRecoveryCarrierAPIValidation {
	
	public static Response getJsonResponseAsJSONObject(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://cobrestapi-unita1.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/cob-edit/non-recovery-closed");
		return response;
	}
	
	//Return the response
	public Map<String,String> nonRecoveryCarrierResponse(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		Map<String,String> nonRecvryCarrier_Resp = new HashMap();
		String returnCode = "";
		String returnMsg = "";
		String nonRcvryFmDate= "";
		
		Response response = getJsonResponseAsJSONObject(requestParams);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		returnCode = jsonObj.getString("returnCode");
		returnMsg = jsonObj.getString("returnMessage");
		if(returnMsg.equals("Success"))
		{
		nonRcvryFmDate = jsonObj.getString("nonRecFmDate");
		nonRecvryCarrier_Resp.put("Non Recovery FM Date", nonRcvryFmDate);
		}
		nonRecvryCarrier_Resp.put("Return Code", returnCode);
		nonRecvryCarrier_Resp.put("Return Msg", returnMsg);
		

		return nonRecvryCarrier_Resp;
	}

}
