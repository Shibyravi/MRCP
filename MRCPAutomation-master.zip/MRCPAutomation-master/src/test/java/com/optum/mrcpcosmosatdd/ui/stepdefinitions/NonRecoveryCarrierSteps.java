package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.NonRecoveryCarrierAPIValidation;
import com.optum.mrcpcosmosatdd.services.rest.SimpleTableAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class NonRecoveryCarrierSteps extends MRCPTestBase {

	File JSON_NONRECVYCARRIERSUCCESS;
	File JSON_NONRECVYCARRIERBLNKSITE;
	File JSON_NONRECVYCARRIERBLNKMEMGRP;
	File JSON_NONRECVYCARRIERBLNKMEMSUBGRP;
	File JSON_NONRECVYCARRIERBLNKMEMDEP;
	File JSON_NONRECVYCARRIERMISSINGCARRIERNAME;
	File JSON_NONRECVYCARRIERINVALIDSITE;
	File JSON_NONRECVYCARRIERINVALIDMEMGRP;
	File JSON_NONRECVYCARRIERINVALIDMEMSUB;
	File JSON_NONRECVYCARRIERINVALIDMEMDEP;

	@When("^I get the request body parameter from payload json file for Non Recovery Carrier$")
	public void I_get_the_body_Params_From_Json_Payload_File()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_NONRECVYCARRIERSUCCESS = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERSUCCESS"));
		JSON_NONRECVYCARRIERBLNKSITE = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERBLNKSITE"));
		JSON_NONRECVYCARRIERBLNKMEMGRP = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERBLNKMEMGRP"));
		JSON_NONRECVYCARRIERBLNKMEMSUBGRP = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERBLNKMEMSUBGRP"));
		JSON_NONRECVYCARRIERBLNKMEMDEP = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERBLNKMEMDEP"));
		JSON_NONRECVYCARRIERMISSINGCARRIERNAME = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERMISSINGCARRIERNAME"));
		JSON_NONRECVYCARRIERINVALIDSITE = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERINVALIDSITE"));
		JSON_NONRECVYCARRIERINVALIDMEMGRP = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERINVALIDMEMGRP"));
		JSON_NONRECVYCARRIERINVALIDMEMSUB = new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERINVALIDMEMSUB"));
		JSON_NONRECVYCARRIERINVALIDMEMDEP =  new File(PropertyReader.getInstance().readProperty("JSON_NONRECVYCARRIERINVALIDMEMDEP"));

	}

	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when record successfully found$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERSUCCESS);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}

	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when claim site is blank$")
	public void verify_The_Return_Code_Blank_Site(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when Member group is blank$")
	public void verify_The_Return_Code_Blank_MemGrp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMGRP);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when Member sub group is blank$")
	public void verify_The_Return_Code_Blank_MemSubGrp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMSUBGRP);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when Member dep is blank$")
	public void verify_The_Return_Code_Blank_MemDepGrp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMDEP);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when carrier name is missing$")
	public void verify_The_Return_Code_Missing_CarrierName(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERMISSINGCARRIERNAME);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when site is invalid$")
	public void verify_The_Return_Code_Site_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when mem grp is invalid$")
	public void verify_The_Return_Code_MemGrp_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMGRP);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when mem sub is invalid$")
	public void verify_The_Return_Code_MemSub_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMSUB);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Non Recovery Carrier when mem dep is invalid$")
	public void verify_The_Return_Code_MemDep_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMDEP);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}

	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when record successfully found$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERSUCCESS);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}

	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when claim site is blank$")
	public void verify_The_Return_Msg_Blank_Site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when Member group is blank$")
	public void verify_The_Return_Msg_Blank_MemGrp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMGRP);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when Member sub group is blank$")
	public void verify_The_Return_Msg_Blank_MemSubGrp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMSUBGRP);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when Member dep is blank$")
	public void verify_The_Return_Msg_Blank_MemDep(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERBLNKMEMDEP);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when carrier name is missing$")
	public void verify_The_Return_Msg_Missing_CarrierName(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERMISSINGCARRIERNAME);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when site is invalid$")
	public void verify_The_Return_Msg_Invalid_Site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when mem grp is invalid$")
	public void verify_The_Return_Msg_Invalid_MemGrp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMGRP);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when mem sub is invalid$")
	public void verify_The_Return_Msg_Invalid_MemSub(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMSUB);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Non Recovery Carrier when mem dep is invalid$")
	public void verify_The_Return_Msg_Invalid_MemDep(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERINVALIDMEMDEP);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
	}

	@When("^Verify the non Recovery FM date as \"([^\"]*)\" of Non Recovery Carrier when record successfully found$")
	public void verify_The_NonRecovery_FMDate(String FMDate)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (FMDate.length() >0 && FMDate.substring(0, 1).equalsIgnoreCase("*"))
			FMDate = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, FMDate, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(NonRecoveryCarrierAPIValidation.class).nonRecoveryCarrierResponse(JSON_NONRECVYCARRIERSUCCESS);
		System.out.println("FM Date from Response:"+" "+ response_ClaimsDetails.get("Non Recovery FM Date"));
		System.out.println("FMDate from Database:"+" "+FMDate);
		Assert.assertTrue(response_ClaimsDetails.get("Non Recovery FM Date").equals(FMDate), "Failed:Fm Date are not verified from response and Data base through data sheet.");
	}
	

}
