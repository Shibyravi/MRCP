package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class ClaimsObjectAPISteps extends MRCPTestBase {

	//JSONObject requestParams = new JSONObject();
	Map<String,String> attributes = new HashMap();

	@When("^I send the request for site as \"([^\"]*)\" and Audit Number as \"([^\"]*)\" and Sub Audit as \"([^\"]*)\" and Claim Type as \"([^\"]*)\" for Claims Object API$")
	public void I_send_The_Request_For_Site_and_AuditNbr_and_SubAuditNbr_and_ClaimType_on_COB_Carrier_Details_page(String site, String auditNbr, String subAuditNbr, String claimType) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (site.length() >0 && site.substring(0, 1).equalsIgnoreCase("*"))
			site = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, site, PropertyReader.getInstance().readProperty("Environment"));
		if (auditNbr.length() >0 && auditNbr.substring(0, 1).equalsIgnoreCase("*"))
			auditNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, auditNbr, PropertyReader.getInstance().readProperty("Environment"));
		if (subAuditNbr.length() >0 && subAuditNbr.substring(0, 1).equalsIgnoreCase("*"))
			subAuditNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, subAuditNbr, PropertyReader.getInstance().readProperty("Environment"));
		if (claimType.length() >0 && claimType.substring(0, 1).equalsIgnoreCase("*"))
			claimType = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimType, PropertyReader.getInstance().readProperty("Environment"));

		attributes.put("Site", site);
		attributes.put("AuditNbr", auditNbr);
		attributes.put("SubauditNbr", subAuditNbr);
		attributes.put("ClaimType", claimType);

	} 

	@When("^Verify the claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).claimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("^Verify the claims and Audit data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_ClaimsAuditData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsAuditDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the medical flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_MedicalFlag_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		System.out.println("Medical flag value:"+" "+ response_ClaimsDetails.get("Medical flag"));
		Assert.assertTrue(response_ClaimsDetails.get("Medical flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header denial from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Denial_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Header Denial").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header system disallow flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Systyem_Disallow_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Header Sys Dilw flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header close flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Close_Flag_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Header Close Flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the par status from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Par_Status_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Par Status").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the ufe id from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Ufe_Id_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Ufe Id").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the claim source from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Clm_SrcFrom_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Claim Source").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the vendor id from service response and \"([^\"]*)\" from DB$")
	public void verify_The_VendorID_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Vendor id").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the from date from service response and \"([^\"]*)\" from DB$")
	public void verify_The_From_Date_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("From date").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the thru date from service response and \"([^\"]*)\" from DB$")
	public void verify_The_thru_Date_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Thru date").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the claim accident type from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Claim_Accident_Type_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("clm accident type").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the hospital remarks from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hospital_Remarks_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Hosp Remarks").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the dev flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Dev_Flag_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Dev Flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the closure flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Closure_Flag_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("closure flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header contract amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Header_Contract_Amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Hdr Contract amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the claim accident date from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Claim_Accident_date_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Clm Accident date").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the cob eligible from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Cob_Eligible_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Cob eligible").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header copay amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Copay_amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Hdr Copay amount").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header deduct amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Deduct_amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Hdr Deduct Amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the header liability amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Hdr_Liability_amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Hdr Liability amount").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the impatient flag from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Impatient_Flag_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Impatient flag").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig audit number from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_Audit_Nbr_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Orig audit number").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig audit sub from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_Audit_Sub_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Orig audit sub").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig header denial from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_Header_Denial_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Orig header denial").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig ufe id from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_Ufe_Id_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Orig Ufe Id").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the Member group from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Mem_Grp_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Mem group").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the Member sub from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Mem_Sub_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Mem sub").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the Member dep from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Mem_Dep_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Mem Dep").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the new denial code from service response and \"([^\"]*)\" from DB$")
	public void verify_The_New_Denial_code_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("New Denial code").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the new contract amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_New_Contract_Amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("New Contract amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the new claim paid amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_New_ClmPaid_Amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("New Clm paid amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the new copay amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_New_Copay_Amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("New copay amount").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the new deduct amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_New_Deduct_Amt_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("New deduct amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the POS from service response and \"([^\"]*)\" from DB$")
	public void verify_The_POS_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("POS").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the POS from service response and \"([^\"]*)\" from DB2$")
	public void verify_The_POS_DataBase_forPhysician(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).PhyclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("POS").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the Tin number from service response and \"([^\"]*)\" from DB2$")
	public void verify_The_TIN_DataBase_forPhysician(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).PhyclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Tin").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig Submitted Charge amount from service response and \"([^\"]*)\" from DB2$")
	public void verify_The_Orig_subt_chrge_amt_DataBase_forPhysician(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).PhyclaimsObjectResp(attributes);
	System.out.println("Claims Details Expected Response from API"+" "+response_ClaimsDetails.get("Orig Submt Chrge Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Orig Submt Chrge Amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the claim paid amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Clm_Paid_Amt_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Clm paid amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the Tin number from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Tin_Nbr_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.get("Tin").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}
	
	@When("^Verify the orig Submitted Charge amount from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_Sbmt_Chrg_Amt_From_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+claimsResponse);

		//Response from Service
	Map<String,String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).HospclaimsObjectResp(attributes);
	System.out.println("orig submtted amount"+ " "+ response_ClaimsDetails.get("Orig Submt Chrge Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Orig Submt Chrge Amt").equals(claimsResponse), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}

	@When("^Verify the amounts claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Amounts_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).amountClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("^Verify the impatientflag,orig audit nbr, orig sub audit, orig hdr denial and ufe id claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Orig_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).origClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("^Verify the diagnosis codes claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_diagCodes_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).diagCodesClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the cause codes claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_causeCodes_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).causeCodesClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the occ codes claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_occCodes_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).occCodesClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the cond codes claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_condCodes_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).condCodesClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the eob objects claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_eobObjects_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the member details claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_memDetails_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).memDetailsClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("Verify the new denial code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_newDenialCode_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).newDenialCodeClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("Verify the new contract amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_cnctamt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).newconctamtClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("Verify the new claim paid amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_clmpaidAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).newClmPaidAmtClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	} 

	@When("Verify the new copay amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_NewCopayAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).newCopayAmtClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}

	@When("Verify the new deduct amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_NewDeductAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).newDeductAmtClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}

	@When("Verify the clm paidt amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Clm_Paid_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).clmPaidAmtClaimsDetailsResp(attributes);
		System.out.println("Claims Details Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");
	}

	@When("^Verify the service lines detail numbers claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_DetailsNbr_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line detail number Response:"+" "+ response_ClaimsDetails.get("Detail Number"));
		Assert.assertTrue(response_ClaimsDetails.get("Detail Number").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail reason codes claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_DetailsRsn_Code_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line detail reason code Response:"+" "+ response_ClaimsDetails.get("Detail Reason Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Detail Reason Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines denial flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_DenialFlag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line denial flags Response:"+" "+ response_ClaimsDetails.get("Denial Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("Denial Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail sys disallow flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_SysDisallowed_Flag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Sys Disallow flag Response:"+" "+ response_ClaimsDetails.get("dt sys Disallw Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("dt sys Disallw Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail close flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Detail_Close_Flag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dt Close flag Response:"+" "+ response_ClaimsDetails.get("Dt Close Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Close Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines override flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Override_Flag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Override flag Response:"+" "+ response_ClaimsDetails.get("Override Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("Override Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines svc code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Svc_Code_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Svc Code Response:"+" "+ response_ClaimsDetails.get("Svc Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Svc Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail claimed amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_clmd_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl Clmt Amt Response:"+" "+ response_ClaimsDetails.get("Dt Claimed Amount"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Claimed Amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail disallow amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Disallow_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl disallow Amt Response:"+" "+ response_ClaimsDetails.get("Dt Disallow amount"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Disallow amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail copay amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Copay_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl copay Amt Response:"+" "+ response_ClaimsDetails.get("Detail Copay Amount"));
		Assert.assertTrue(response_ClaimsDetails.get("Detail Copay Amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail deduct amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Deduct_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl deduct Amt Response:"+" "+ response_ClaimsDetails.get("Detail Copay Amount"));
		Assert.assertTrue(response_ClaimsDetails.get("Detail Copay Amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail discount amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Discount_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl discount Amt Response:"+" "+ response_ClaimsDetails.get("Detail Deduct Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Detail Deduct Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail fee max claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_FeeMax_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl Fee max Response:"+" "+ response_ClaimsDetails.get("Dt Fee Max"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Fee Max").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail liability amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Liability_Amount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line Dtl liability amount Response:"+" "+ response_ClaimsDetails.get("Dt liability Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt liability Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail ben tier Number claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Dtl_Ben_Tier_Number_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line  Ben tier number Response:"+" "+ response_ClaimsDetails.get("Ben Tier Nbr"));
		Assert.assertTrue(response_ClaimsDetails.get("Ben Tier Nbr").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail reason code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_new_Detail_RsnCode_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line  new detail reason code Response:"+" "+ response_ClaimsDetails.get("New Dt Rsn Code"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dt Rsn Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail cob eligible claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Cob_Eligible_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line  Cob eligible Response:"+" "+ response_ClaimsDetails.get("Dt Cob eligible"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Cob eligible").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail paid amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Paid_Amount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line  paid amount Response:"+" "+ response_ClaimsDetails.get("Dt Paid Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Dt Paid Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail paid amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_New_DetailPaid_Amount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail paid amount Response:"+" "+ response_ClaimsDetails.get("New Dt Paid Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dt Paid Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail copay amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_New_Detail_Copay_Amount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail copay amount Response:"+" "+ response_ClaimsDetails.get("New Dt copay Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dt copay Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail deduct amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_New_Detail_Deduct_Amount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("New Dt Deduct Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dt Deduct Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines cpt code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_CPTCode_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("CPT Code"));
		Assert.assertTrue(response_ClaimsDetails.get("CPT Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines revenue code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_RevenueCode_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("Revenue Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Revenue Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail contract amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_newDetail_ContractAmount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("New Dtl Contract Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dtl Contract Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail contract amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Detail_ContractAmount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("Dtl Contract Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Dtl Contract Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines new detail eligible amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_New_Detail_EligibleAmount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("New Dtl Eligible Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("New Dtl Eligible Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the service lines detail eligible amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_serviceLines_Detail_EligibleAmount_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).serviceLinesDetailsClaimsDetailsResp(attributes);
		System.out.println("Service line new detail deduct amount Response:"+" "+ response_ClaimsDetails.get("Dtl Eligible Amt"));
		Assert.assertTrue(response_ClaimsDetails.get("Dtl Eligible Amt").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the Reviews Code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Reviews_Code_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).reviewsClaimsDetailsResp(attributes);
		System.out.println("Review code Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the Reviews status claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Reviews_Status_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).reviewsClaimsDetailsResp(attributes);
		System.out.println("Review status Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the Reviews initial claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Reviews_Initial_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).reviewsClaimsDetailsResp(attributes);
		System.out.println("Review initial Response:"+" "+ response_ClaimsDetails.get("Review Initial"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Initial").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the Reviews clear date claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Reviews_ClearDate_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).reviewsClaimsDetailsResp(attributes);
		System.out.println("Review clear date Response:"+" "+ response_ClaimsDetails.get("Review Clr Date"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Clr Date").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the Reviews user code claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_Reviews_UserCode_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).reviewsClaimsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("Review Usr Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Usr Code").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header paid amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderPaidAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR Paid amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR Paid amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header discount amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderDiscountAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR discount amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR discount amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header disallow amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderDisallowAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR disallow amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR disallow amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header allowable amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderAllowableAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR allowable amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR allowable amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header deduct amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderDeductAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR deduct amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR deduct amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header copay amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_HeaderCopayAmt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR copay amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR copay amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB header claimed amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Header_Claimed_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR claimed amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR claimed amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB carrier name claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_CarrierName_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("Carrier name"));
		Assert.assertTrue(response_ClaimsDetails.get("Carrier name").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}

	@When("^Verify the EOB claim filling Ind claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Claim_Filling_Ind_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("Claim filling ind"));
		Assert.assertTrue(response_ClaimsDetails.get("Claim filling ind").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the EOB mva carrier flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_MVA_Carrier_Flag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("MVA Carrier Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("MVA Carrier Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the EOB Excep carrier flag claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Excep_Carrier_Flag_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("Excep Carrier Flag"));
		Assert.assertTrue(response_ClaimsDetails.get("Excep Carrier Flag").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the EOB header pat resp amount claims data from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Hdr_Pat_Resp_Amt_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDetailsResp(attributes);
		System.out.println("Review user code Response:"+" "+ response_ClaimsDetails.get("HDR PatResp Amount"));
		Assert.assertTrue(response_ClaimsDetails.get("HDR PatResp Amount").equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the detail number of eob objects from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Dtl_Nbr_ClaimsData_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDtlNbrDetailsResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the claim adjustment reason code of eob objects from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Clm_Adj_Rsn_code_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsClmAdjRsnCdDetailsResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
	
	@When("^Verify the detail adjustment reason code of eob objects from service response and \"([^\"]*)\" from DB$")
	public void verify_The_EOB_Dtl_Adj_Rsn_code_from_Response_And_DataBase(String claimsResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (claimsResponse.length() >0 && claimsResponse.substring(0, 1).equalsIgnoreCase("*"))
			claimsResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, claimsResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB2(claimsResponse);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(COBCarrierDetailsRestAPIValidations.class).eobObjectsDtlAdjRsnCdDetailsResp(attributes);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Claims details are not verified from response and Data base through data sheet.");
		Log.info("Verified:Claims details are verified from Service response and Database.");

	}
}