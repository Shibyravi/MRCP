package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.PhysicianRestartClaimAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class PhysicianRestartClaimSteps extends MRCPTestBase{
	
	File JSON_PHYRESTRTRVW;
	File JSON_PHYCLRRVW;
	File JSON_PHYRESTRTRVWRNGAUDT;
	File JSON_PHYRESTRTRVWRNGADTFRMT;
	File JSON_PHYRESTRTRVWRNGSITE;
	File JSON_PHYRESTRTRVWRNGUSERID;
	

	@When("^I get the request body parameter from payload json file for Physician Restart claim$")
	public void get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_PHYRESTRTRVW = new File(PropertyReader.getInstance().readProperty("JSON_PHYRESTRTRVW"));
		JSON_PHYRESTRTRVWRNGAUDT = new File(PropertyReader.getInstance().readProperty("JSON_PHYRESTRTRVWRNGAUDT"));
		JSON_PHYRESTRTRVWRNGADTFRMT = new File(PropertyReader.getInstance().readProperty("JSON_PHYRESTRTRVWRNGADTFRMT"));
		JSON_PHYRESTRTRVWRNGSITE = new File(PropertyReader.getInstance().readProperty("JSON_PHYRESTRTRVWRNGSITE"));
		JSON_PHYRESTRTRVWRNGUSERID = new File(PropertyReader.getInstance().readProperty("JSON_PHYRESTRTRVWRNGUSERID"));
		JSON_PHYCLRRVW = new File(PropertyReader.getInstance().readProperty("JSON_PHYCLRRVW"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of physician claim when claim Successfully changes$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVW);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of physician claim when claim Successfully changes$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVW);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician claim when audit number incorrect$")
	public void verify_The_Return_CodeWhen_Audt_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of physician claim when audit number incorrect$")
	public void verify_The_Return_MsgWen_Audt_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician claim when audit number format incorrect$")
	public void verify_The_Return_CodeWhen_Audt_FormatIncorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGADTFRMT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of physician claim when audit number format incorrect$")
	public void verify_The_Return_MsgWen_Audt_FormatIncorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGADTFRMT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician claim when site is incorrect$")
	public void verify_The_Return_CodeWhen_Site_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of physician claim when site is incorrect$")
	public void verify_The_Return_MsgWen_Site_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician claim when userid is incorrect$")
	public void verify_The_Return_CodeWhen_UserId_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of physician claim when userid is incorrect$")
	public void verify_The_Return_MsgWen_UserId_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(PhysicianRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYRESTRTRVWRNGUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}


}
