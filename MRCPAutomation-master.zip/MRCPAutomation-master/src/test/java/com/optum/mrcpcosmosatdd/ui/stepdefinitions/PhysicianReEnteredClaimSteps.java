package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.ReEnterPhysicianClaimAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class PhysicianReEnteredClaimSteps extends MRCPTestBase{
	
	File JSON_PHYREENTERCLM;
	
	File JSON_PHYREENTYWRNGAUDT;
	File JSON_PHYREENTYBLNKSITE;
	File JSON_PHYREENTRYCLMRNGSITE;
	File JSON_PHYREENTRINVLDUSERID;
	
	//For Sub audits
	File JSON_PHYREENTERCLMSUBADT;
	File JSON_PHYREENTERCLMSUBADTFALSE;
	File JSON_PHYREENTYWRNGAUDTSUBADT;
	File JSON_PHYREENTYWRNGUSRIDSUBADT;
	File JSON_PHYREENTYWRNGSITESUBADT;
	File JSON_PHYREENTYBLNKSITESUBADT;
	

	@When("^I get the request body parameter from payload json file for Physician Re-Enter claim$")
	public void I_get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_PHYREENTERCLM = new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTERCLM"));
		JSON_PHYREENTYWRNGAUDT = new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYWRNGAUDT"));
		JSON_PHYREENTYBLNKSITE = new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYBLNKSITE"));
		JSON_PHYREENTRYCLMRNGSITE = new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTRYCLMRNGSITE"));
		JSON_PHYREENTRINVLDUSERID = new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTRINVLDUSERID"));
		
		JSON_PHYREENTERCLMSUBADT= new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTERCLMSUBADT"));
		JSON_PHYREENTERCLMSUBADTFALSE=new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTERCLMSUBADTFALSE"));
		JSON_PHYREENTYWRNGAUDTSUBADT=new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYWRNGAUDTSUBADT"));
		JSON_PHYREENTYWRNGUSRIDSUBADT=new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYWRNGUSRIDSUBADT"));
		JSON_PHYREENTYWRNGSITESUBADT=new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYWRNGSITESUBADT"));
		JSON_PHYREENTYBLNKSITESUBADT=new File(PropertyReader.getInstance().readProperty("JSON_PHYREENTYBLNKSITESUBADT"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when claim Successfully reEnterd$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTERCLM);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when claim Successfully reEnterd for a sub audit$")
	public void verify_The_Return_CodeSub_Audt(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTERCLMSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when claim unsuccessfully reEnterd for a sub audit$")
	public void verify_The_Return_CodeSub_AudtFalse(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTERCLMSUBADTFALSE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when claim Successfully reEnterd$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTERCLM);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Databse:"+" "+ rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when claim Successfully reEnterd for a sub audit$")
	public void verify_The_Return_MsgSubAudt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTERCLMSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when claim unsuccessfully reEnterd for a sub audit$")
	public void verify_The_Return_MsgSubAudtFalse(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTERCLMSUBADTFALSE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when audit number is not correct$")
	public void verify_The_Return_CodeAdtInvalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTYWRNGAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when audit number is not correct for a sub audit$")
	public void verify_The_Return_CodeAdtInvalidSubAdt(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYWRNGAUDTSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when audit number is not correct$")
	public void verify_The_Return_MsgAdtInvalid(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTYWRNGAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when audit number is not correct for a sub audit$")
	public void verify_The_Return_MsgAdtInvalidSubAdt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYWRNGAUDTSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when user id is invalid$")
	public void verify_The_Return_CodeUsrIdInvalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTRINVLDUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when user id is not correct for a sub audit$")
	public void verify_The_Return_CodeUsrIdInvalidSubAdt(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYWRNGUSRIDSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when user id is invalid$")
	public void verify_The_Return_MsgUseIdInvalid(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTRINVLDUSERID);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when user id is not correct for a sub audit$")
	public void verify_The_Return_MsgUseIdInvalidSubAdt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTYWRNGUSRIDSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when site is invalid$")
	public void verify_The_Return_CodeSiteInvalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTRYCLMRNGSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when site is not correct for a sub audit$")
	public void verify_The_Return_CodeSiteInvalidSubAdt(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYWRNGSITESUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when site is invalid$")
	public void verify_The_Return_MsgSiteInvalid(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTRYCLMRNGSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when site is not correct for a sub audit$")
	public void verify_The_Return_MsgSiteInvalidSubAdt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYWRNGSITESUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when site is blank$")
	public void verify_The_Return_CodeSiteBlank(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTYBLNKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician claim when site is blank for a sub audit$")
	public void verify_The_Return_CodeSiteBlankSubAdt(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYBLNKSITESUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when site is blank for a sub audit$")
	public void verify_The_Return_MsgSiteBlankSubAdt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsgSubAudt(JSON_PHYREENTYBLNKSITESUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Databse:"+" "+ rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician claim when site is blank$")
	public void verify_The_Return_MsgSiteBlank(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(ReEnterPhysicianClaimAPIValidation.class).reviewCodeAndMsg(JSON_PHYREENTYBLNKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Databse:"+" "+ rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}


}
