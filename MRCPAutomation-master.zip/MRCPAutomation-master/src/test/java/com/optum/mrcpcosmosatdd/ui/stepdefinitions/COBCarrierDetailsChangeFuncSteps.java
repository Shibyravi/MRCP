package com.optum.mrcpcosmosatdd.ui.stepdefinitions;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import java.util.Collections;
import java.util.List;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;


public class COBCarrierDetailsChangeFuncSteps extends MRCPTestBase {

	//JSONObject requestParams = new JSONObject();
	Map<String,String> attributes = new HashMap();

	@When("^I inquire Member number as \"([^\"]*)\" and Site as \"([^\"]*)\" and AsOfDt as \"([^\"]*)\" and Active Edit as \"([^\"]*)\" on COB Carrier Details page for Inquire$")
	public void i_inquire_Member_number_and_Site_and_AsOfDate_and_ActiveEdit_on_COB_Carrier_Details_page(String memNbr, String memSite, String asOfDt, String activEdit) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (memNbr.length() >0 && memNbr.substring(0, 1).equalsIgnoreCase("*"))
			memNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memNbr, PropertyReader.getInstance().readProperty("Environment"));
		if (memSite.length() >0 && memSite.substring(0, 1).equalsIgnoreCase("*"))
			memSite = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memSite, PropertyReader.getInstance().readProperty("Environment"));
		if (asOfDt.length() >0 && asOfDt.substring(0, 1).equalsIgnoreCase("*"))
			asOfDt = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, asOfDt, PropertyReader.getInstance().readProperty("Environment"));
		if (activEdit.length() >0 && activEdit.substring(0, 1).equalsIgnoreCase("*"))
			activEdit = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, activEdit, PropertyReader.getInstance().readProperty("Environment"));

		attributes.put("memberNumber", memNbr);
		attributes.put("site", memSite);
		attributes.put("asOfDate", asOfDt);
		attributes.put("isActiveEdit", activEdit);

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).performInquire(memNbr, memSite, asOfDt, activEdit), true);

	} 
 
	@When("^Verify the \"([^\"]*)\" Carrier Name values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire before change$")
	public void verify_The_CarrierName_CarrierDetails_from_Response_COB_Screen_And_DataBase_Before_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carier Name Carrier Details Expected Response from DB through DataSheet before change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Name Carrier details from UI before change"+" "+ carrier_Details_FromUI.get("CarrierName"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carier Name Carrier details from Service response after change"+" "+ response_CarrierDetails.get("CarrierName"));

		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(response_CarrierDetails.get("CarrierName")), "Failed:Primacy Carrier details are not verified from UI and Response before change");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(expRespDB), "Failed:Carrier Name carrier details are not verified from UI and Data base through data sheet before change.");
		Log.info("Verified:Carrier Name carrier details are verified from UI ,Service response and Database before change.");

	}

	@When("^I make any changes in \"([^\"]*)\" with value \"([^\"]*)\" in other insurance section and inquire it again$")
	public void i_Make_Any_Changes_In_Other_Insurance_Section(String fieldName ,String updatedValueOthrInsur) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (fieldName.length() >0 && fieldName.substring(0, 1).equalsIgnoreCase("*"))
			fieldName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, fieldName, PropertyReader.getInstance().readProperty("Environment"));
		if (updatedValueOthrInsur.length() >0 && updatedValueOthrInsur.substring(0, 1).equalsIgnoreCase("*"))
			updatedValueOthrInsur = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, updatedValueOthrInsur, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).changeInOthrInsuranceAndInquire(fieldName,updatedValueOthrInsur), true);

	}  
	
	@When("^I make any changes in \"([^\"]*)\" with value \"([^\"]*)\" in Recovery section and inquire it again$")
	public void i_Make_Any_Changes_In_Recovery_Section(String fieldName ,String updatedValueOthrInsur) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (fieldName.length() >0 && fieldName.substring(0, 1).equalsIgnoreCase("*"))
			fieldName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, fieldName, PropertyReader.getInstance().readProperty("Environment"));
		if (updatedValueOthrInsur.length() >0 && updatedValueOthrInsur.substring(0, 1).equalsIgnoreCase("*"))
			updatedValueOthrInsur = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, updatedValueOthrInsur, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).changeInOthrInsuranceAndInquire(fieldName,updatedValueOthrInsur), true);

	} 

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_CarrierName_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carier Name Carrier Details Expected Response from DB through DataSheet after change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Name Carrier details from UI after change"+" "+ carrier_Details_FromUI.get("CarrierName"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carier Name Carrier details from Service response after change"+" "+ response_CarrierDetails.get("CarrierName"));
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(response_CarrierDetails.get("CarrierName")), "Failed:Primacy Carrier details are not verified from UI and Response after change");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(expRespDB), "Failed:Carrier Name carrier details are not verified from UI and Data base through data sheet after change.");
		Log.info("Verified:Carrier Name carrier details are verified from UI ,Service response and Database after change.");

	} 

	@When("^I clear the made changes in \"([^\"]*)\" in other insurance section and inquire it again$")
	public void i_Clear_The_Made_Changes_In_Other_Insurance_Section(String fieldName) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (fieldName.length() >0 && fieldName.substring(0, 1).equalsIgnoreCase("*"))
			fieldName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, fieldName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).clearChangesInOthrInsuranceAndInquire(fieldName), true);

	} 
	
	@When("^I clear the made changes in \"([^\"]*)\" in Recovery section and inquire it again$")
	public void i_Clear_The_Made_Changes_In_Recovery_Section(String fieldName) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (fieldName.length() >0 && fieldName.substring(0, 1).equalsIgnoreCase("*"))
			fieldName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, fieldName, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).clearChangesInOthrInsuranceAndInquire(fieldName), true);

	} 

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_CarrierName_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Reset(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Carier Name Carrier Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Carrier Name Carrier details from UI after reset"+" "+ carrier_Details_FromUI.get("CarrierName"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Carier Name Carrier details from Service response after change"+" "+ response_CarrierDetails.get("CarrierName"));
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(response_CarrierDetails.get("CarrierName")), "Failed:Primacy Carrier details are not verified from UI and Response after reset");
		Assert.assertTrue(carrier_Details_FromUI.get("CarrierName").equals(expRespDB), "Failed:Carrier Name carrier details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Verified:Carrier Name carrier details are verified from UI ,Service response and Database after reset.");

	}

	@When("^Verify the \"([^\"]*)\" Policy Number values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire before change$")
	public void verify_The_PolicyNumber_CarrierDetails_from_Response_COB_Screen_And_DataBase_Before_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Policy Number Carrier Details Expected Response from DB through DataSheet before change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Policy Number Carrier details from UI"+" "+ carrier_Details_FromUI.get("Policy Number"));


		//Policy Number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Policy Number Carrier details from Service response"+" "+ response_CarrierDetails.get("PolicyNumber"));
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(response_CarrierDetails.get("PolicyNumber")), "Failed:Policy Number details are not verified from UI and Response before change");
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(expRespDB), "Failed:Policy Number carrier details are not verified from UI and Data base through data sheet before change.");
		Log.info("Policy Number carrier details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" Policy Number values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_Policy_Number_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Policy Number Carrier Details Expected Response from DB through DataSheet after change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Policy Number Carrier details from UI after change"+" "+ carrier_Details_FromUI.get("Policy Number"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Policy Number Carrier details from Service response after change"+" "+ response_CarrierDetails.get("PolicyNumber"));
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(response_CarrierDetails.get("PolicyNumber")), "Failed:Policy Number Carrier details are not verified from UI and Response after change");
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(expRespDB), "Failed:Policy Number carrier details are not verified from UI and Data base through data sheet after change.");
		Log.info("Verified:Policy Number carrier details are verified from UI ,Service response and Database after change.");

	} 

	@When("^Verify the \"([^\"]*)\" Policy Number values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_Policy_Number_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Reset(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Policy Number Carrier Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Policy Number Carrier details from UI after reset"+" "+ carrier_Details_FromUI.get("Policy Number"));


		//Carrier number validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Policy Number Carrier details from Service response after change"+" "+ response_CarrierDetails.get("PolicyNumber"));
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(response_CarrierDetails.get("PolicyNumber")), "Failed:Policy Number Carrier details are not verified from UI and Response after reset");
		Assert.assertTrue(carrier_Details_FromUI.get("Policy Number").equals(expRespDB), "Failed:Policy Number carrier details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Verified:Policy Number carrier details are verified from UI ,Service response and Database after reset.");

	}

	@When("^Verify the \"([^\"]*)\" Other Plan values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire before change$")
	public void verify_The_Other_Plan_CarrierDetails_from_Response_COB_Screen_And_DataBase_Before_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Other Plan Carrier Details Expected Response from DB through DataSheet before change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Other Plan Carrier details from UI before change"+" "+ carrier_Details_FromUI.get("OtherUHCInfo"));


		//Other Plan validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Other Plan Carrier details from Service response before change"+" "+ response_CarrierDetails.get("OthrUHCPlan"));
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(response_CarrierDetails.get("OthrUHCPlan")), "Failed:Other Plan details are not verified from UI and Response before change");
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(expRespDB), "Failed:Other Plan carrier details are not verified from UI and Data base through data sheet before change.");
		Log.info("Other Plan carrier details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" Other Plan values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_Other_Plan_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Change(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Other Plan Carrier Details Expected Response from DB through DataSheet after change"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Other Plan Carrier details from UI after change"+" "+ carrier_Details_FromUI.get("OtherUHCInfo"));


		//Other Plan validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Other Plan Carrier details from Service response after change"+" "+ response_CarrierDetails.get("OthrUHCPlan"));
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(response_CarrierDetails.get("OthrUHCPlan")), "Failed:Other Plan Carrier details are not verified from UI and Response after change");
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(expRespDB), "Failed:Other Plan carrier details are not verified from UI and Data base through data sheet after change.");
		Log.info("Verified:Other Plan carrier details are verified from UI ,Service response and Database after change.");

	} 

	@When("^Verify the \"([^\"]*)\" Other Plan values of Other insurance Carrier details from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_Other_Plan_CarrierDetails_from_Response_COB_Screen_And_DataBase_After_Reset(String carrierDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (carrierDetailsExpResponse.length() >0 && carrierDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			carrierDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(carrierDetailsExpResponse);
		System.out.println("Other Plan Carrier Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> carrier_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getCarrierDetailsUI();
		System.out.println("Other Plan Carrier details from UI after reset"+" "+ carrier_Details_FromUI.get("OtherUHCInfo"));


		//Other Plan validation Response from Service
		Map<String,List<String>> response_CarrierDetails = getPage(COBCarrierDetailsRestAPIValidations.class).CarrierDetailsResp(attributes);
		System.out.println("Other Plan Carrier details from Service response after change"+" "+ response_CarrierDetails.get("OthrUHCPlan"));
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(response_CarrierDetails.get("OthrUHCPlan")), "Failed:Other Plan Carrier details are not verified from UI and Response after reset");
		Assert.assertTrue(carrier_Details_FromUI.get("OtherUHCInfo").equals(expRespDB), "Failed:Other Plan carrier details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Verified:Other Plan carrier details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" Carrier Name values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_Carrier_Name_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Name Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Name Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("CarrierNameRec"));


		//Carrier Name Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Name Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("CarrierNameRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(response_RecoveryDetails.get("CarrierNameRec")), "Failed:Carrier Name recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(expRespDB), "Failed:Carrier Name recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("Carrier Name recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_Carrier_Name_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Name Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Name Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("CarrierNameRec"));


		//Carrier Name Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Name Recovery details from Service response after change"+" "+ response_RecoveryDetails.get("CarrierNameRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(response_RecoveryDetails.get("CarrierNameRec")), "Failed:Carrier Name recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(expRespDB), "Failed:Carrier Name recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("Carrier Name recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" Carrier Name values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_Carrier_Name_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Carrier Name Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Carrier Name Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("CarrierNameRec"));


		//Carrier Name Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Carrier Name Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("CarrierNameRec"));
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(response_RecoveryDetails.get("CarrierNameRec")), "Failed:Carrier Name recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("CarrierNameRec").equals(expRespDB), "Failed:Carrier Name recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Carrier Name recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" Policy number values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_Policy_Number_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Policy number Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Policy number Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("Policy Number Rec"));


		//Policy number Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Policy number Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("Policy Number Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(response_RecoveryDetails.get("Policy Number Rec")), "Failed:Policy number recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(expRespDB), "Failed:Policy number recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("Policy number recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" Policy number values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_Policy_number_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Policy number Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Policy number Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("Policy Number Rec"));


		//Policy number Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Policy number Recovery details from Service response after change"+" "+ response_RecoveryDetails.get("Policy Number Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(response_RecoveryDetails.get("Policy Number Rec")), "Failed:Policy number recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(expRespDB), "Failed:Policy number recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("Policy number recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" Policy number values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_Policy_number_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Policy number Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Policy number Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("Policy Number Rec"));


		//Policy number Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Policy number Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("Policy Number Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(response_RecoveryDetails.get("Policy Number Rec")), "Failed:Policy number recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("Policy Number Rec").equals(expRespDB), "Failed:Policy number recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Policy number recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" Diagnosis Description values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_Diagnosis_Description_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Diagnosis Description Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Diagnosis Description Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("Diag Desc Rec"));


		//Diagnosis Description Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Diagnosis Description Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("Diag Desc Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(response_RecoveryDetails.get("Diag Desc Rec")), "Failed:Diagnosis Description recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(expRespDB), "Failed:Diagnosis Description recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("Diagnosis Description recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" Diagnosis Description values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_Diagnosis_Description_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Diagnosis Description Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Diagnosis Description Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("Diag Desc Rec"));


		//Diagnosis Description Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Diagnosis Description Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("Diag Desc Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(response_RecoveryDetails.get("Diag Desc Rec")), "Failed:Diagnosis Description recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(expRespDB), "Failed:Diagnosis Description recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("Diagnosis Description recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" Diagnosis Description values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_Diagnosis_Description_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("Diagnosis Description Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("Diagnosis Description Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("Diag Desc Rec"));


		//Diagnosis Description Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("Diagnosis Description Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("Diag Desc Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(response_RecoveryDetails.get("Diag Desc Rec")), "Failed:Diagnosis Description recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("Diag Desc Rec").equals(expRespDB), "Failed:Diagnosis Description recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("Diagnosis Description recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA2 values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_ICDA2_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA2 Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA2 Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("ICDA2 Rec"));


		//ICDA2 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA2 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA2 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(response_RecoveryDetails.get("ICDA2 Rec")), "Failed:ICDA2 recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(expRespDB), "Failed:ICDA2 recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("ICDA2 recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA2 values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_ICDA2_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA2 Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA2 Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("ICDA2 Rec"));


		//ICDA2 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA2 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA2 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(response_RecoveryDetails.get("ICDA2 Rec")), "Failed:ICDA2 recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(expRespDB), "Failed:ICDA2 recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("ICDA2 recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA2 values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_ICDA2_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA2 Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA2 Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("ICDA2 Rec"));


		//ICDA2 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA2 Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("ICDA2 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(response_RecoveryDetails.get("ICDA2 Rec")), "Failed:ICDA1 recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA2 Rec").equals(expRespDB), "Failed:ICDA2 recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("ICDA2 recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA4 values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_ICDA4_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA4 Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA4 Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("ICDA4 Rec"));


		//ICDA4 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA4 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA4 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(response_RecoveryDetails.get("ICDA4 Rec")), "Failed:ICDA4 recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(expRespDB), "Failed:ICDA4 recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("ICDA4 recovery details are verified from UI ,Service response and Database before change.");

	} 

	@When("^Verify the \"([^\"]*)\" ICDA4 values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_ICDA4_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA4 Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA4 Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("ICDA4 Rec"));


		//ICDA4 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA4 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA4 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(response_RecoveryDetails.get("ICDA4 Rec")), "Failed:ICDA4 recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(expRespDB), "Failed:ICDA4 recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("ICDA4 recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA4 values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_ICDA4_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA4 Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA4 Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("ICDA4 Rec"));


		//ICDA4 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA4 Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("ICDA4 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(response_RecoveryDetails.get("ICDA4 Rec")), "Failed:ICDA4 recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA4 Rec").equals(expRespDB), "Failed:ICDA4 recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("ICDA4 recovery details are verified from UI ,Service response and Database after reset.");

	}
	

	@When("^Verify the \"([^\"]*)\" ICDA5 values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_ICDA5_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA5 Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA5 Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("ICDA5 Rec"));


		//ICDA5 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA5 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA5 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(response_RecoveryDetails.get("ICDA5 Rec")), "Failed:ICDA5 recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(expRespDB), "Failed:ICDA5 recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("ICDA5 recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA5 values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_ICDA5_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA5 Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA5 Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("ICDA5 Rec"));


		//ICDA4 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA5 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA5 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(response_RecoveryDetails.get("ICDA5 Rec")), "Failed:ICDA5 recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(expRespDB), "Failed:ICDA5 recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("ICDA5 recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA5 values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_ICDA5_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA5 Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA5 Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("ICDA5 Rec"));


		//ICDA5 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA5 Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("ICDA5 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(response_RecoveryDetails.get("ICDA5 Rec")), "Failed:ICDA5 recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA5 Rec").equals(expRespDB), "Failed:ICDA5 recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("ICDA5 recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA8 values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_ICDA8_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA8 Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA8 Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("ICDA8 Rec"));


		//ICDA8 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA8 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA8 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(response_RecoveryDetails.get("ICDA8 Rec")), "Failed:ICDA8 recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(expRespDB), "Failed:ICDA8 recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("ICDA8 recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA8 values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_ICDA8_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA8 Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA8 Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("ICDA8 Rec"));


		//ICDA8 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA8 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA8 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(response_RecoveryDetails.get("ICDA8 Rec")), "Failed:ICDA8 recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(expRespDB), "Failed:ICDA8 recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("ICDA8 recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA8 values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_ICDA8_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA8 Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA8 Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("ICDA8 Rec"));


		//ICDA8 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA8 Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("ICDA8 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(response_RecoveryDetails.get("ICDA8 Rec")), "Failed:ICDA8 recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA8 Rec").equals(expRespDB), "Failed:ICDA8 recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("ICDA8 recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^Verify the \"([^\"]*)\" ICDA10 values of Recovery details from service response , COB details screen and from DB before change$")
	public void verify_The_ICDA10_RecoveryDetails_from_Response_COB_Screen_And_DataBase_BeforeChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA10 Recovery Details Expected Response from DB through DataSheet Before change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA10 Recovery details from UI before change"+" "+ recovery_Details_FromUI.get("ICDA10 Rec"));


		//ICDA10 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA10 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA10 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(response_RecoveryDetails.get("ICDA10 Rec")), "Failed:ICDA10 recovery details are not verified from UI and Response before change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(expRespDB), "Failed:ICDA10 recovery details are not verified from UI and Data base through data sheet before change.");
		Log.info("ICDA10 recovery details are verified from UI ,Service response and Database before change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA10 values of Recovery from service response , COB details screen and from DB for Inquire after change$")
	public void verify_The_ICDA10_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterChange(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA10 Recovery Details Expected Response from DB through DataSheet After change"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA10 Recovery details from UI after change"+" "+ recovery_Details_FromUI.get("ICDA10 Rec"));


		//ICDA10 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA10 Recovery details from Service response before change"+" "+ response_RecoveryDetails.get("ICDA10 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(response_RecoveryDetails.get("ICDA10 Rec")), "Failed:ICDA10 recovery details are not verified from UI and Response after change");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(expRespDB), "Failed:ICDA10 recovery details are not verified from UI and Data base through data sheet after change.");
		Log.info("ICDA10 recovery details are verified from UI ,Service response and Database after change.");

	}

	@When("^Verify the \"([^\"]*)\" ICDA10 values of Recovery from service response , COB details screen and from DB for Inquire after reset$")
	public void verify_The_ICDA10_RecoveryDetails_from_Response_COB_Screen_And_DataBase_AfterReset(String recoveryDetailsExpResponse) throws InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException, InvalidFormatException, IOException {

		if (recoveryDetailsExpResponse.length() >0 && recoveryDetailsExpResponse.substring(0, 1).equalsIgnoreCase("*"))
			recoveryDetailsExpResponse = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, recoveryDetailsExpResponse, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesFromDB(recoveryDetailsExpResponse);
		System.out.println("ICDA10 Recovery Details Expected Response from DB through DataSheet after reset"+" "+expRespDB);

		Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
		System.out.println("ICDA10 Recovery details from UI after reset"+" "+ recovery_Details_FromUI.get("ICDA10 Rec"));


		//ICDA10 Recovery validation Response from Service
		Map<String,List<String>> response_RecoveryDetails = getPage(COBCarrierDetailsRestAPIValidations.class).recoveryDetailsResp(attributes);
		System.out.println("ICDA10 Recovery details from Service response after reset"+" "+ response_RecoveryDetails.get("ICDA10 Rec"));
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(response_RecoveryDetails.get("ICDA10 Rec")), "Failed:ICDA10 recovery details are not verified from UI and Response after reset");
		Assert.assertTrue(recovery_Details_FromUI.get("ICDA10 Rec").equals(expRespDB), "Failed:ICDA10 recovery details are not verified from UI and Data base through data sheet after reset.");
		Log.info("ICDA10 recovery details are verified from UI ,Service response and Database after reset.");

	}
	
	@When("^I make any changes in \"([^\"]*)\" with value \"([^\"]*)\" and remove the \"([^\"]*)\" in other insurance section and validate the error msg$")
	public void i_Make_Any_Changes_In_Other_Insurance_Section_And_make_required_Field_As_Blank(String fieldName ,String updatedValueOthrInsur, String mandatoryField) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (fieldName.length() >0 && fieldName.substring(0, 1).equalsIgnoreCase("*"))
			fieldName = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, fieldName, PropertyReader.getInstance().readProperty("Environment"));
		if (updatedValueOthrInsur.length() >0 && updatedValueOthrInsur.substring(0, 1).equalsIgnoreCase("*"))
			updatedValueOthrInsur = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, updatedValueOthrInsur, PropertyReader.getInstance().readProperty("Environment"));
		if (mandatoryField.length() >0 && mandatoryField.substring(0, 1).equalsIgnoreCase("*"))
			mandatoryField = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, mandatoryField, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).validateErrorMessageforChnage(fieldName,updatedValueOthrInsur,mandatoryField), true);
 
	}   
}
