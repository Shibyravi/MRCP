package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.util.concurrent.TimeUnit;

import com.optum.mrcpcosmosatdd.security.GeneratePlainPassword;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.LoginPage;

import cucumber.api.java.en.Given;


/**
 *
 */
public class MRCPStartSteps extends MRCPTestBase {

	private String environment = PropertyReader.getInstance().readProperty("Environment");

	private String url = PropertyReader.getInstance().readProperty(environment);

	@Given("^I Am On CPA Login Page$")
	public void iAmOnTheCpaHomePage() throws Throwable {
		String baseUrl = url;
		driver.manage().window().maximize();
		driver.get(baseUrl);

	}
 
	@Given("^I Am On CPA Login Page And Login With Valid Credentials$")
	public void iAmOnTheCpaHomePageAndLoginWithValidCredentials() throws Throwable {
		String baseUrl = url;
		driver.manage().window().maximize();
		driver.get(baseUrl);
		String username = PropertyReader.getInstance().readProperty("ValidUsername");
		String password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("ValidPassword"));
		getPage(LoginPage.class).login(username, password);
	}
	
	
	@Given("^I Am on COB dummy screen for POC$")
	public void COB_POC_Validation() throws Throwable {
		String baseUrl = url;
		driver.manage().window().maximize();
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		
		

}
}