package com.optum.mrcpcosmosatdd.ui.utilities;

import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.saucelabs.saucerest.SauceREST;
import org.apache.commons.lang.StringUtils;

import org.json.JSONException;
import org.junit.Assert;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("unused")
public class SauceUtils {


    private static SauceREST sauceRESTClient;
    private String sauceUser;
    private String sauceAccessKey;

    private static SauceREST getSauceRestClient(String username, String accessKey) {
        if (sauceRESTClient == null) {
            sauceRESTClient = new SauceREST(username, accessKey);
        }
        return sauceRESTClient;
    }

    public static void updateResults(String username, String accessKey, boolean testResults, String sessionId)
            throws JSONException, IOException {
        SauceREST client = getSauceRestClient(username, accessKey);
        Map<String, Object> updates = new HashMap<String, Object>();
        updates.put("passed", testResults);
        client.updateJobInfo(sessionId, updates);
    }
    public static final String WORK_DIRECTORY = System.getProperty("user.dir");
    private static DesiredCapabilities createCapabilities(String value) throws FileNotFoundException {
        Map<String, Object> platform = parseYAML(WORK_DIRECTORY + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "platforms.yml", value);
        DesiredCapabilities capabilities = new DesiredCapabilities();
        for (String key : platform.keySet()) {
            capabilities.setCapability(key, platform.get(key));
        }
        return capabilities;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> parseYAML(String filename, String parameter) throws FileNotFoundException {
        try {
            FileReader file = new FileReader(filename);
            Map<String, Object> platforms = (Map<String, Object>) new Yaml().load(file);
            Map<String, Object> platform = (Map<String, Object>) platforms.get(parameter);
            assert platform != null;
            return platform;
        } catch (Exception e) {
            System.out.println("Unable to find file" + e.getMessage());
        }
        return null;
    }


    public static DesiredCapabilities setDesireCapabilitiesForRemoteDriver(String scenarioName) {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        //   List<String> variables = Arrays.asList("tunnelIdentifier", "platform", "version");
        // jenkins jobb will pass platform value if it is not passed from jenkins it will take default value windows_7_ff
        if (!StringUtils.isBlank(System.getenv("platform"))) {
            try {
                desiredCapabilities = createCapabilities(System.getenv("platform"));
                assert !StringUtils.isBlank(System.getenv("tunnelIdentifier"));
                desiredCapabilities.setCapability("tunnelIdentifier", System.getenv("tunnelIdentifier"));
                desiredCapabilities.setCapability("build", System.getenv("JOB_NAME") + "__" + System.getenv("BUILD_NUMBER"));

            } catch (FileNotFoundException e) {
                Assert.fail("unable to find file platform.yml" + e.getMessage());
            }
        } else {
            try {
                desiredCapabilities = createCapabilities(PropertyReader.getInstance().readProperty("platform"));
                desiredCapabilities.setCapability("tunnelIdentifier", PropertyReader.getInstance().readProperty("tunnelIdentifier"));
            } catch (FileNotFoundException e) {
                Assert.fail("unable to find file platform.yml" + e.getMessage());
            }
        }
        desiredCapabilities.setCapability("parent-tunnel", "optumtest");
        desiredCapabilities.setCapability("idleTimeout", "10800");
        desiredCapabilities.setCapability("maxDuration", "1500");
        desiredCapabilities.setCapability("commandTimeout", "600");
        desiredCapabilities.setCapability("name", scenarioName);
        return desiredCapabilities;
    }


    private static DesiredCapabilities getDesiredCapabilitiesFromSauceConnectPlugin() {
        DesiredCapabilities caps;
        caps = new DesiredCapabilities();
        caps.setBrowserName(System.getenv("SELENIUM_BROWSER"));
        caps.setVersion(System.getenv("SELENIUM_VERSION"));
        caps.setCapability(CapabilityType.PLATFORM_NAME, System.getenv("SELENIUM_PLATFORM"));
        caps.setCapability("build", System.getenv("JOB_NAME") + "__" + System.getenv("BUILD_NUMBER"));
        return caps;
    }

    private static String readPropertyOrEnv(String key) {
        String v = System.getProperty(key);
        if (v == null) {
            return System.getenv(key);
        } else {
            return v;
        }
    }

    public static String getSauceConnectUrl() {
        if (!StringUtils.isBlank(System.getenv("SAUCE_USERNAME"))) {
        	System.out.println("Sauce lab Url:"+ " "+ "http://" + System.getenv("SAUCE_USERNAME") + ":" + System.getenv("SAUCE_ACCESS_KEY") + "@ondemand.saucelabs.com:80/wd/hub");
            return "http://" + System.getenv("SAUCE_USERNAME") + ":" + System.getenv("SAUCE_ACCESS_KEY") + "@ondemand.saucelabs.com:80/wd/hub";
        } else {
        	System.out.println("Sauce lab url:"+" "+ "http://" + PropertyReader.getInstance().readProperty("SAUCE_USERNAME") + ":" +PropertyReader.getInstance().readProperty(("SAUCE_ACCESS_KEY")) + "@ondemand.saucelabs.com:80/wd/hub");
            return "http://" + PropertyReader.getInstance().readProperty("SAUCE_USERNAME") + ":" +PropertyReader.getInstance().readProperty(("SAUCE_ACCESS_KEY")) + "@ondemand.saucelabs.com:80/wd/hub";
        }
//                    if (username == null || accessKey == null) {
//                Assert.fail("Missing value for environment variable(s) SAUCE_USERNAME or SAUCE_ACCESS_KEY.  Check environment configuration and try again");
//            }
    }
}
