package com.optum.mrcpcosmosatdd.services.rest;

import static io.restassured.RestAssured.baseURI;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.api.dto.ClearReviewDTO;
import com.optum.mrcpcosmosatdd.api.dto.response.ClearReviewResponseDTO;
import com.optum.mrcpcosmosatdd.services.common.JWTToken;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PhysicianCL601ClearReviewValidation {

/*public static void main(String ar[]) throws JSONException, IllegalArgumentException, JWTCreationException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
{
	String body = "{\r\n" + 
			"\"auditNumber\": \"72457773\",\r\n" + 
			"\"site\": \"BHM\",\r\n" + 
			"\"userId\": \"03734\",\r\n" + 
			"\"type\": \"P\",\r\n" + 
			"\"subAudit\": \"00\",\r\n" + 
			"\"initials\": \"AA\",\r\n" + 
			"\"status\": \"A\",\r\n" + 
			"\"review\": 100\r\n" + 
			"}";
	
	
	JSONObject requestParams = new JSONObject(body);
	Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
	//List<ClearReviewDTO> clrRvwDTOList = (List<ClearReviewDTO>) new ObjectMapper().readValue(jsonResponse.getBody().asString(), List.class);
	
	JSONArray response = new JSONArray(jsonResponse.getBody().asString());
			int code  =(Integer) ((JSONObject)( response.get(0))).get("code");
	
			System.out.println("code :: "+code);
	List<ClearReviewDTO> clrRvwDTOList = jsonResponse.getBody().jsonPath().getList(".",ClearReviewDTO.class);
	ClearReviewResponseDTO responseDTO = new ObjectMapper().readValue(body, ClearReviewResponseDTO.class);
	responseDTO = new ObjectMapper().convertValue(requestParams, ClearReviewResponseDTO.class);

	System.out.println(clrRvwDTOList);
	//System.out.println(clrRvwDTOList.get(0).getCode());
	for(ClearReviewDTO data : clrRvwDTOList) {
		System.out.println(data.getCode());
		
	}
	
}*/
	public static Response getJsonResponseAsJSONObjectforClaimsObject(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://cobtransaction-unita1-hotfix.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/physician/clear-review");
		return response;
	}
	
	public static Response getJsonResponseAsJSONObjectforClaimsObjectSubAudit(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://cobtransaction-unita1-hotfix.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/physician/clear-review-sub");
		return response;
	}

	//Return the response
	public Map<String,List<String>> reviewCodeAndMsg(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		Map<String,List<String>> clearReview_Resp = new HashMap();
		List<String> rvwCode = new ArrayList();
		List<String> rvwMsg = new ArrayList();
		
		Response response = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
		JSONArray jsonArry = new JSONArray(response.getBody().asString());
		System.out.println("number of Json Array"+ " "+ jsonArry.length());
		for(int i=0;i<jsonArry.length();i++)
		{
			rvwCode.add(((JSONObject)jsonArry.get(i)).getString("code"));
			rvwMsg.add(((JSONObject)jsonArry.get(i)).getString("message"));	
		}
		clearReview_Resp.put("Review Code", rvwCode);
		clearReview_Resp.put("Review Msg", rvwMsg);

		return clearReview_Resp;
	}
	
	//Return the Review Status response
		public Map<String,List<String>> reviewStatus(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
		{

			Map<String,List<String>> clearReview_Resp = new HashMap();
			List<String> rvwNbr = new ArrayList();
			List<String> rvwClrStatus = new ArrayList();
			
			Response response = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONArray jsonArry = new JSONArray(response.getBody().asString());
			System.out.println("number of Json Array"+ " "+ jsonArry.length());
			for(int i=0;i<jsonArry.length();i++)
			{
			JSONObject jsonobj = (JSONObject) ((JSONObject)jsonArry.get(i));
			JSONArray jsonRvwArry = jsonobj.getJSONArray("review");
			for(int j=0;j<jsonRvwArry.length();j++)
			{
				JSONObject rvwSts_Obj = (JSONObject)jsonRvwArry.get(j);
				rvwNbr.add(rvwSts_Obj.getString("reviewNbr"));
				rvwClrStatus.add(rvwSts_Obj.getString("clear"));
			}
			
			}
			clearReview_Resp.put("Review Number", rvwNbr);
			clearReview_Resp.put("Review Status", rvwClrStatus);

			return clearReview_Resp;
		}
		
		public List<String> reviewStatusForClearingReview(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
		{

			String rvwCode ="";
			String rvwMsg ="";
			List<String> rvwNbr = new ArrayList();
			List<String> rvwClrStatus = new ArrayList();
			List<String> clearReview_Resp = new ArrayList();
			Response response = getJsonResponseAsJSONObjectforClaimsObjectSubAudit(requestParams);
			JSONObject jsonObj = new JSONObject(response.getBody().asString());
			rvwCode = jsonObj.getString("code");
			rvwMsg= jsonObj.getString("message");
			JSONArray jsonArray = jsonObj.getJSONArray("review");
			for(int i=0;i<jsonArray.length();i++)
			{
				rvwNbr.add(jsonArray.getJSONObject(i).getString("reviewNbr"));
				rvwClrStatus.add(jsonArray.getJSONObject(i).getString("clear"));
			}
			
			clearReview_Resp.add(rvwCode);
			clearReview_Resp.add(rvwMsg);
			clearReview_Resp.addAll(rvwNbr);
			clearReview_Resp.addAll(rvwClrStatus);
		
			return clearReview_Resp;
		}

}
