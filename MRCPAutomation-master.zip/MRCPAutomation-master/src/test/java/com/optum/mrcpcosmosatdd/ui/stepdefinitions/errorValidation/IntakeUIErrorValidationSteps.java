package com.optum.mrcpcosmosatdd.ui.stepdefinitions.errorValidation;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.pages.errorValidations.IntakeErrorValidationWindow;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class IntakeUIErrorValidationSteps extends MRCPTestBase{
	
	String act_Error_Msg;

	Map<String,String> attributes = new HashMap();
	@When("^I submit Cob Review as \"([^\"]*)\" and Request type as \"([^\"]*)\" and audit number as \"([^\"]*)\" and As of date as \"([^\"]*)\" and Comment as \"([^\"]*)\" on Intake form pop up$")
	public void i_submit_CobReview_and_RequestType_and_AuditNumber_and_AsOfDate_And_Comment_on_Intake_popup(String cobReview, String requestType, String auditNumber, String asOfDate, String comment) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (cobReview.length() >0 && cobReview.substring(0, 1).equalsIgnoreCase("*"))
			cobReview = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, cobReview, PropertyReader.getInstance().readProperty("Environment"));
		if (requestType.length() >0 && requestType.substring(0, 1).equalsIgnoreCase("*"))
			requestType = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, requestType, PropertyReader.getInstance().readProperty("Environment"));
		if (auditNumber.length() >0 && auditNumber.substring(0, 1).equalsIgnoreCase("*"))
			auditNumber = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, auditNumber, PropertyReader.getInstance().readProperty("Environment"));
		if (asOfDate.length() >0 && asOfDate.substring(0, 1).equalsIgnoreCase("*"))
			asOfDate = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, asOfDate, PropertyReader.getInstance().readProperty("Environment"));
		if (comment.length() >0 && comment.substring(0, 1).equalsIgnoreCase("*"))
			comment = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, comment, PropertyReader.getInstance().readProperty("Environment"));

		attributes.put("Cob Review", cobReview);
		attributes.put("Request Type", requestType);
		attributes.put("Audit Number", auditNumber);
		attributes.put("Af of Date", asOfDate);
		attributes.put("Comment", comment);

		 act_Error_Msg = getPage(IntakeErrorValidationWindow.class).performSubmit(cobReview, requestType, auditNumber, asOfDate, comment);

	} 


	@When("^Verify the Error message \"([^\"]*)\" on Intake form pop up$")
	public void verify_The_Error_Msg_on_Intake_Popup(String expErrorMsg) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(IntakeErrorValidationWindow.class).validateErrorMsg(expErrorMsg,act_Error_Msg), true);

	} 	

}



