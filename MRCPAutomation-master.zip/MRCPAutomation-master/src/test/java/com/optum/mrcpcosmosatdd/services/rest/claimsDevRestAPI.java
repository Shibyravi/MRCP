package com.optum.mrcpcosmosatdd.services.rest;
import com.optum.mrcpcosmosatdd.reporting.Log;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;

public class claimsDevRestAPI {

    public boolean validateResponse(JSONObject requestParams, String expectedData){
        RestAssured.baseURI ="http://clinkapi-cpadev.ose-ctc-core.optum.com";
        RequestSpecification request = given();
        request.body(requestParams);
        request.contentType(ContentType.JSON);
        request.header("cosmosID","03734");
        Response response = request.post("/notifyaddinfo");
        String actualResponse="";
        //Replacing the Transaction ID with Site+AuditNo as Timestamp cannot be matched
        if(response.jsonPath().get("transactionID")!=null)
            actualResponse=response.body().asString().replace(response.jsonPath().get("transactionID"),""+requestParams.get("site")+requestParams.get("auditNo"));
        else
            actualResponse=response.body().asString();
        //Validating Response
        if(actualResponse.equals(expectedData)) {
            Log.info("Response matched");
            return true;
        }
        else {
            Log.error("Response did not matched. Expected Response is "+expectedData+" and Actual Response is "+actualResponse);
            return false;
        }
    }
}