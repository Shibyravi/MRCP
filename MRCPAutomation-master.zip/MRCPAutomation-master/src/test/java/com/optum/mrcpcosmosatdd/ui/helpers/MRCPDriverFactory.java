package com.optum.mrcpcosmosatdd.ui.helpers;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.Hooks;
import com.optum.mrcpcosmosatdd.ui.utilities.SauceUtils;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * @author sgupt228
 *
 */
public class MRCPDriverFactory {

	public static final String WORK_DIRECTORY = System.getProperty("user.dir");
	public static String browserName = PropertyReader.getInstance().readProperty("browserName");
	public static String browserVersion = PropertyReader.getInstance().readProperty("browserVersion");
	public static String browserPlatform = PropertyReader.getInstance().readProperty("browserPlatform");
	public static String userName_CBT = PropertyReader.getInstance().readProperty("SAUCE_USERNAME");
	public static String authKey_CBT = PropertyReader.getInstance().readProperty("SAUCE_ACCESS_KEY");
	
	RemoteWebDriver remoteWebDriver;

	private String sessionID;

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	protected static WebDriver driver;
	private static String pathToDrivers;

	protected static WebDriverWait MICRODRIVERWAIT, MINDRIVERWAIT, MIDDRIVERWAIT, MAXDRIVERWAIT, ULTRAMAXEDDRIVERWAIT;
	protected static Wait<WebDriver> MINFLUENTWAIT, MIDFLUENTWAIT, MAXFLUENTWAIT;
	protected static Robot ROBOT;

	public static JavascriptExecutor JAVASCRIPTEXECUTOR;

	public static Actions ACTION;

	public MRCPDriverFactory() {
		initialize();
	}

	/**
	 * @throws URISyntaxException 
	 * @throws MalformedURLException 
	 *  
	 */
	public void initialize() {
		if (driver == null) {
			String platform = PropertyReader.getInstance().readProperty("platform");
			//BUILD_NUMBER is coming from Jenkins
			if (StringUtils.isEmpty(System.getenv("BUILD_NUMBER"))) {
				if (platform.contains("Local")) {
					Log.info("Creating Driver instance for Local");
					driver = initBrowserForDriver(platform);
				}
				else if((platform.contains("API"))){
					Log.info("Creating headless driver instance for API");
					driver = initBrowserForDriver(platform);
				}
				
				else {
					Log.info("Creating Driver instance for SauceLab");
					try {
						driver = initSauceBrowserForDriver();
					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (URISyntaxException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} else {
				Log.info("Creating Driver instance for SauceLab");
				try {
					driver = initSauceBrowserForDriver();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			MICRODRIVERWAIT = new WebDriverWait(driver, 5);
			MINDRIVERWAIT = new WebDriverWait(driver, 15);
			MIDDRIVERWAIT = new WebDriverWait(driver, 30);
			MAXDRIVERWAIT = new WebDriverWait(driver, 60);
			ULTRAMAXEDDRIVERWAIT = new WebDriverWait(driver, 60);

			MINFLUENTWAIT = new FluentWait<WebDriver>(driver)
					.withTimeout(10, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);
			MIDFLUENTWAIT = new FluentWait<WebDriver>(driver)
					.withTimeout(30, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);
			MAXFLUENTWAIT = new FluentWait<WebDriver>(driver)
					.withTimeout(60, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);

			JAVASCRIPTEXECUTOR = (JavascriptExecutor) driver;

			ACTION = new Actions(driver);

			try {
				ROBOT = new Robot();
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private WebDriver initSauceBrowserForDriver() throws URISyntaxException, MalformedURLException {
		//return setRemoteWebDriver(SauceUtils.getSauceConnectUrl());
		System.out.println("browserName -" +browserName + "browserVersion -" + browserVersion + "platform -" + browserPlatform);
		URI uri = new URI("http://" + userName_CBT + ":" + authKey_CBT +"@hub.crossbrowsertesting.com:80/wd/hub");
		System.out.println("hub -" +"http://" + userName_CBT + ":" + authKey_CBT +"@hub.crossbrowsertesting.com:80/wd/hub");
		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("name", "MRCP_CBT_Suite");
		caps.setCapability("build", "MRCP_4.7");
		caps.setCapability("browserName", browserName);
		caps.setCapability("version", browserVersion);
		caps.setCapability("plateform", browserPlatform);
		caps.setCapability("record_video", true);
		
		remoteWebDriver = new RemoteWebDriver(uri.toURL(), caps);
		//remoteWebDriver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps);
		setSessionID(remoteWebDriver.getSessionId().toString());
		
		return remoteWebDriver;
	}

	/**
	 * @return
	 */
	public WebDriver getDriver() {
		return driver;
	}

	/**
	 * Destroy existing driver instance
	 *
	 * @throws IOException
	 * @throws InterruptedException
	 *
	 */
	public void destroyDriver() throws IOException, InterruptedException {
		driver.quit();
		driver = null;
		BasePage.windowRootWebElement = null;
		//new HomePage().logout();
		//Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
	}

	/**
	 * @return
	 */
	private WebDriver initBrowserForDriver(String platform) {
		// Write code here that turns the phrase above into concrete actions
		String path = "/drivers/";

		if (platform.contains("Mac")) {
			pathToDrivers = path.replace("/", "//");
		} else {
			pathToDrivers = path.replace("/", "\\\\");
		}

		switch (platform) {
		case "firefoxLocal":
			Log.info("Setting up Firefox Driver for Windows");
			setFireFoxLocalDriverForWindows();
			break;
		case "firefoxLocalMac":
			Log.info("Setting up Firefox Driver for Mac");
			setFireFoxLocalDriverForMac();
			break;
		case "chromeLocal":
			Log.info("Setting up Chrome Driver for Windows");
			setChromeLocalDriver();
			break;
		case "chromeLocalMac":
			Log.info("Setting up Chrome Driver for Mac");
			setChromeLocalDriverForMac();
			break;
		case "internetExplorerLocal":
			Log.info("Setting up Internet Explorer Driver for Windows");
			setInternetExplorerDriver();
			break;
		case "API":
			Log.info("Setting up html unit Driver for Windows");
			setHtmlUnitLocalDriver();
			break;
		default:
			Log.error("Select correct platform in Properties file");
			Assert.fail("Select correct platform in Properties file");
		}
		return driver;
	}

	private static void setChromeLocalDriver() {
		System.setProperty("webdriver.chrome.driver", WORK_DIRECTORY + pathToDrivers + "\\chromedriver.exe");
	//	System.setProperty("webdriver.chrome.driver","C:\\ProgramData\\ChromeDriver_84\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--js-flags=--expose-gc");
		options.addArguments("--enable-precise-memory-info");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-default-apps");
		options.addArguments("test-type=browser");
		options.addArguments("disable-infobars");
		options.addArguments("disable-extensions");
		//Added for ATG pages to load unsafe scripts
		options.addArguments("allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
		//options.addArguments("--enable-automation");
		options.addArguments("--no-sandbox"); 
		options.addArguments("--disable-infobars");
		options.addArguments("--disable-dev-shm-usage");
		options.addArguments("--disable-browser-side-navigation"); 
		options.addArguments("--disable-gpu");
		
		driver = new ChromeDriver(options);
	}

	private void setChromeLocalDriverForMac() {
		System.setProperty("webdriver.chrome.driver", WORK_DIRECTORY + pathToDrivers + "chrome//chromedriver");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver(options);
	}

	private void setFireFoxLocalDriverForMac() {
		System.setProperty("webdriver.gecko.driver", WORK_DIRECTORY + pathToDrivers + "firefox//geckodriver");
		FirefoxOptions options = new FirefoxOptions();
		options.setAcceptInsecureCerts(true);
		options.setCapability("marionette", true);
		driver = new FirefoxDriver(options);
	}

	private void setFireFoxLocalDriverForWindows() {
		System.setProperty("webdriver.gecko.driver", WORK_DIRECTORY + pathToDrivers + "\\geckodriver.exe");
		FirefoxOptions options = new FirefoxOptions();
		options.setAcceptInsecureCerts(true);
		options.setCapability("marionette", true);
		options.addPreference("browser.download.folderList", 2);
		options.addPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream,application/pdf");
		options.addPreference("browser.download.manager.showWhenStarting", false);
		options.addPreference("browser.download.useDownloadDir", true);
		options.addPreference("browser.helperApps.alwaysAsk.force", false);
		options.addPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
		options.addPreference("plugin.disable_full_page_plugin_for_types", "application/octet-stream,application/pdf");
		options.addPreference("pdfjs.disabled", true);
		driver = new FirefoxDriver(options);
	}
	
	private void setHtmlUnitLocalDriver() {
		
		System.setProperty("webdriver.chrome.driver", WORK_DIRECTORY + pathToDrivers + "\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\ProgramData\\ChromeDriver_89\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
			options.addArguments("--profile-directory=Default") ;
			driver = new ChromeDriver(options);
		
		
	}

	private void setInternetExplorerDriver() {
		System.setProperty("webdriver.ie.driver", WORK_DIRECTORY + pathToDrivers + "\\IEDriverServer.exe");
		InternetExplorerOptions options = new InternetExplorerOptions();
		options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		options.setCapability("ignoreZoomSetting", true);
		options.setCapability("ignoreProtectedModeSettings", true);
		options.setCapability("requireWindowFocus", true);
		options.setCapability("unexpectedAlertBehaviour", "ignore");
		driver = new InternetExplorerDriver(options);
	}

	private WebDriver setRemoteWebDriver(String url) {
		RemoteWebDriver remoteDriver = null;
		try {
			Log.info("Setting up Remote Driver:Sauce Lab");
			remoteDriver = new RemoteWebDriver(new URL(url), SauceUtils.setDesireCapabilitiesForRemoteDriver(Hooks.jobName));
			setSessionID(remoteDriver.getSessionId().toString());
		} catch (MalformedURLException e) {
			Log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return remoteDriver;
	}

}