package com.optum.mrcpcosmosatdd.ui.helpers;

import java.time.LocalDateTime;

import com.optum.mrcpcosmosatdd.ui.utilities.GeneralFunctions;

/**
 * Constants class for storing Values which are used all over the framework
 */

public class Constants {

	public final static int IMPLICITWAIT = 10; 

	public final static String PROPERTYPATH = "src/mrcp-config.properties";

	public static final String PRIVATEKEY = "FFEA8D126F60B6B27827F4AEEB24EF6A";

	public static final String SUITENAME = "MRCP Regression Suite";

	public static final String REPORTPATH = System.getProperty("user.dir") + "\\ExecutionReports\\"+GeneralFunctions.getDate()+"\\Reports"+GeneralFunctions.gettimeStamp()+".html";

	public static String SCENARIONAME = null;
 
	public static String FEATURENAME = null;

	public static LocalDateTime STARTTIME = null;

	public static LocalDateTime ENDTIME = null;

	public static String PHYSICIANSITE = "OEB";

	public static String HOSPITALSITE = "OEB";

	public static String BACKGROUNDCOLOR = null;

	public static String MRCP_TRANSACTION_SECRET = "Q4b2arKtCfOp5Ms7hIKRD1Ov4SI3ISwJ";

	public static String MRCP_TRANSACTION_KEY = "v49rjm0M2k7RMSCpX3SKRUK3M7y8fp1m";

	public static String MRCPA_SECRET = "TBxcighjX6tPK7c4JxYkAs7eT1cYs1Sd";

	public static String MRCPA_KEY = "nG07kPX7KoUPj5Zx4Bb8V6w92AI6Yard";

}