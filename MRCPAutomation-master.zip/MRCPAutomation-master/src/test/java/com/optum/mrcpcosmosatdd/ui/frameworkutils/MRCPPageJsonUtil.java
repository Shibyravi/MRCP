package com.optum.mrcpcosmosatdd.ui.frameworkutils;

import org.json.simple.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * @author sgupt228
 *
 */
public class MRCPPageJsonUtil {

    protected static HashMap<String, JSONObject> cachedPages = new HashMap<>();

    /**
     * Prints out the values of all locators
     */
    public static void displayPageJSONHash() {
        for (Map.Entry mapEntry : cachedPages.entrySet()) {
            System.out.println("project page cache: key: '" + mapEntry.getKey() + "' Value: '" + mapEntry.getValue() + "'");
        }

    }


    public static String findPageElementValue(MRCPPageElement elementData) {
        return null;
    }
}
