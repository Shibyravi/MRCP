package com.optum.mrcpcosmosatdd.api.dto.response;

import java.util.List;

import com.optum.mrcpcosmosatdd.api.dto.ClearReviewDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ClearReviewResponseDTO {
	
	private List<ClearReviewDTO> clrRvw;

}
