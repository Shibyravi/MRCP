package com.optum.mrcpcosmosatdd.api.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ClearReviewDTO {

	private String auditNumber ;
	private String site ;
	private String userId ;
	private String type ;
	private String subAudit ;
	private String initials ;
	private String status ;
	private int code ;
	private String message ;
	private List<ReviewStatusDTO> review ;
	
	public int getCode() {
		return this.code;
	}
	
	public void setCode(int code) {
		this.code = code;
	}
	
       
}
