package com.optum.mrcpcosmosatdd.services.rest;

import com.auth0.jwt.exceptions.JWTCreationException;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class MemberNotesAPIValidations {

    public static Response getJsonResponseAsJSONObjectforMembernotes(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
        RestAssured.baseURI ="http://generic-cpa-transactions-unita1.origin-ctc-core-nonprod.optum.com";
        RequestSpecification request = RestAssured.given();
        request.contentType(ContentType.JSON);
        request.body(requestBody);
        Response response=request.request(Method.POST,"/member-notes/add");
        return response;
    }
    //Return the Retrun message  response
    public Map<String,String> rtnStatus(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
    {
        Map<String,String> Membernotesadd_Resp= new HashMap();
        String rtncode,rtnStatus ;
        Response response = getJsonResponseAsJSONObjectforMembernotes(requestParams);
        JSONObject JSONOBJ= new JSONObject(response.getBody().asString());
        rtncode =JSONOBJ.getString("Return Code");
        rtnStatus=JSONOBJ.getString("Return Message");
        Membernotesadd_Resp.put("Return Code", rtncode);
        Membernotesadd_Resp.put("Return Message", rtnStatus);
        return Membernotesadd_Resp;
    }


}
