package com.optum.mrcpcosmosatdd.ui.stepdefinitions.errorValidation;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.pages.errorValidations.COBErrorValidationsWindow;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class COBUIErrorValidationSteps extends MRCPTestBase{

	String act_Error_Msg;

	Map<String,String> attributes = new HashMap();
	@When("^I inquire Member number as \"([^\"]*)\" and Site as \"([^\"]*)\" and AsOfDt as \"([^\"]*)\" on COB Carrier Details page$")
	public void i_inquire_Member_number_and_Site_and_AsOfDate_on_COB_Carrier_Details_page(String memNbr, String memSite, String asOfDt) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (memNbr.length() >0 && memNbr.substring(0, 1).equalsIgnoreCase("*"))
			memNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memNbr, PropertyReader.getInstance().readProperty("Environment"));
		if (memSite.length() >0 && memSite.substring(0, 1).equalsIgnoreCase("*"))
			memSite = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memSite, PropertyReader.getInstance().readProperty("Environment"));
		if (asOfDt.length() >0 && asOfDt.substring(0, 1).equalsIgnoreCase("*"))
			asOfDt = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, asOfDt, PropertyReader.getInstance().readProperty("Environment"));

		attributes.put("memberNumber", memNbr);
		attributes.put("site", memSite);
		attributes.put("asOfDate", asOfDt);

		act_Error_Msg = getPage(COBErrorValidationsWindow.class).performInquire(memNbr, memSite, asOfDt);

	} 

	@When("^User enters Exp date as \"([^\"]*)\" with blank Eff date on COB Carrier Details page$")
	public void enter_Exp_Date_with_Blank_Eff_Date_on_COB_Carrier_Details_page(String expdate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).enterExpDate(expdate);

	} 
	
	@When("^User enters Eff date as \"([^\"]*)\" format on COB Carrier Details page$")
	public void enter_Eff_Date_In_MMDDYY_Fomrat_on_COB_Carrier_Details_page(String effdate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).enterEffDate(effdate);

	}
	
	@When("^User enters Eff date as \"([^\"]*)\" format in Recovery on COB Carrier Details page$")
	public void enter_Eff_Date_In_MMDDYY_Fomrat_in_Recovery_on_COB_Carrier_Details_page(String effdate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).enterEffDateRecovery(effdate);

	}
	
	@When("^User enters Exp date as \"([^\"]*)\" format in Recovery on COB Carrier Details page$")
	public void enter_Exp_Date_In_MMDDYY_Fomrat_in_Recovery_on_COB_Carrier_Details_page(String expDate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).enterExpDateRecovery(expDate);

	}
	
	@When("^User enters Exp date as \"([^\"]*)\" format on COB Carrier Details page$")
	public void enter_Exp_Date_In_MMDDYY_Fomrat_on_COB_Carrier_Details_page(String expdate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).entersExpDate(expdate);

	}
	
	@When("^User enters Incident date as \"([^\"]*)\" format on COB Carrier Details page$")
	public void enter_Incident_Date_In_MMDDYY_Fomrat_on_COB_Carrier_Details_page(String incidentDate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		act_Error_Msg =	getPage(COBErrorValidationsWindow.class).enterIncidentDate(incidentDate);

	}
	

	@When("^Verify the Error message \"([^\"]*)\" on COB Carrier Detail page$")
	public void verify_The_Error_Msg_on_COB_Carrier_Details_page(String expErrorMsg) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).validateErrorMsg(expErrorMsg,act_Error_Msg), true);

	} 	

	@When("^Verify the Error message \"([^\"]*)\" on COB Carrier Detail page after click on Add$")
	public void verify_The_Error_Msg_on_COB_Carrier_Details_page_afterAdd(String expErrorMsg) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).validateErrorMsgAftAdd(expErrorMsg), true);

	} 

	@When("^select primacy as \"([^\"]*)\", cov type as \"([^\"]*)\", Carrier type as \"([^\"]*)\" carrier number as \"([^\"]*)\" and Eff date as \"([^\"]*)\" on page$")
	public void select_The_Value_On_Page(String primacy, String covType, String carrierType, String carrierNumber, String effDate) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (primacy.length() >0 && primacy.substring(0, 1).equalsIgnoreCase("*"))
			primacy = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, primacy, PropertyReader.getInstance().readProperty("Environment"));
		if (covType.length() >0 && covType.substring(0, 1).equalsIgnoreCase("*"))
			covType = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, covType, PropertyReader.getInstance().readProperty("Environment"));
		if (carrierNumber.length() >0 && carrierNumber.substring(0, 1).equalsIgnoreCase("*"))
			carrierNumber = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierNumber, PropertyReader.getInstance().readProperty("Environment"));
		if (carrierType.length() >0 && carrierType.substring(0, 1).equalsIgnoreCase("*"))
			carrierType = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierType, PropertyReader.getInstance().readProperty("Environment"));
		if (effDate.length() >0 && effDate.substring(0, 1).equalsIgnoreCase("*"))
			effDate = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, effDate, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).selectValues(primacy,covType,carrierType,carrierNumber,effDate), true);

	} 

	@When("^change carrier name as \"([^\"]*)\" in another detail line of other insurance.$")
	public void select_another_Detailline_Value_On_OI(String carrierName) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).enterCarrierNameOI(carrierName), true);

	} 
	
	@When("^change carrier name as \"([^\"]*)\" in another detail line of recovery.$")
	public void select_another_Detailline_Value_On_Recovery(String carrierName) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).enterCarrierNameRec(carrierName), true);

	} 

	@When("^Enter the valid date as \"([^\"]*)\" in Exp dt$")
	public void enter_The_Valid_Date_In_Exp_Date(String expDate) throws InvalidFormatException, IOException, InterruptedException, JSONException {

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).enterValidExpDate(expDate), true);

	} 

	@When("^select incident date as \"([^\"]*)\", Carrier type as \"([^\"]*)\" carrier number as \"([^\"]*)\", Eff date as \"([^\"]*)\" and diagnosis Description as \"([^\"]*)\" on page$")
	public void select_The_Values_On_Page(String incidentDt, String carrierType, String carrierNumber, String effDate, String diagDesc) throws InvalidFormatException, IOException, InterruptedException, JSONException {
		if (incidentDt.length() >0 && incidentDt.substring(0, 1).equalsIgnoreCase("*"))
			incidentDt = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, incidentDt, PropertyReader.getInstance().readProperty("Environment"));
		if (carrierType.length() >0 && carrierType.substring(0, 1).equalsIgnoreCase("*"))
			carrierType = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierType, PropertyReader.getInstance().readProperty("Environment"));
		if (carrierNumber.length() >0 && carrierNumber.substring(0, 1).equalsIgnoreCase("*"))
			carrierNumber = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, carrierNumber, PropertyReader.getInstance().readProperty("Environment"));
		if (effDate.length() >0 && effDate.substring(0, 1).equalsIgnoreCase("*"))
			effDate = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, effDate, PropertyReader.getInstance().readProperty("Environment"));
		if (diagDesc.length() >0 && diagDesc.substring(0, 1).equalsIgnoreCase("*"))
			diagDesc = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, diagDesc, PropertyReader.getInstance().readProperty("Environment"));

		Assert.assertEquals(getPage(COBErrorValidationsWindow.class).selectValuesfromRecovery(incidentDt,carrierType,carrierNumber,effDate,diagDesc), true);

	} 

}
