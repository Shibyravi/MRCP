package com.optum.mrcpcosmosatdd.database;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

/**
 * @author sgupt228
 *
 */
public class DragAndDropFunctionalityTest {

	static WebDriver driver = null;
	static Actions action = null;

	public static void main(String args[]) throws InterruptedException, AWTException {

		testCPADragAndDropFunctionality();
		//testDragAndDropFunctionality();
	}

	public static void testDragAndDropFunctionality() throws InterruptedException, AWTException {

		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--js-flags=--expose-gc");
		options.addArguments("--enable-precise-memory-info");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-default-apps");
		options.addArguments("test-type=browser");
		options.addArguments("disable-infobars");
		options.addArguments("disable-extensions");
		//Added for ATG pages to load unsafe scripts
		//options.addArguments("allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

		driver = new ChromeDriver(options);
		
		action = new Actions(driver);
		
		driver.get("http://demo.guru99.com/test/drag_drop.html");

		Thread.sleep(5000);
		
		WebElement draggable = driver.findElement(By.xpath("(.//li[@id='fourth'])[1]/a"));
		WebElement droppable = driver.findElement(By.id("amt8"));

		//driver.switchTo().frame(0);

		action.moveToElement(draggable).moveByOffset(-1,  -1).clickAndHold(draggable).moveToElement(droppable).release(droppable).build().perform();

		//action.dragAndDrop(draggable, droppable).build().perform();

		System.out.println("Done");

	}

	public static void testCPADragAndDropFunctionality() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--js-flags=--expose-gc");
		options.addArguments("--enable-precise-memory-info");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-default-apps");
		options.addArguments("test-type=browser");
		options.addArguments("disable-infobars");
		options.addArguments("disable-extensions");
		//Added for ATG pages to load unsafe scripts
		//options.addArguments("allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

		driver = new ChromeDriver(options);

		action = new Actions(driver);

		driver.get("https://cosmoscpa-tst-charlie.uhc.com/home2");

		Thread.sleep(1000);
		driver.findElement(By.id("USER")).sendKeys("bkumar82");
		driver.findElement(By.id("Password")).sendKeys("Open@all");
		driver.findElement(By.id("varLoginBtn")).click();

		Thread.sleep(5000);

		driver.findElement(By.id("physLink")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("Physician_physician_entry")).click();

		Thread.sleep(5000);

		WebElement draggable = driver.findElement(By.xpath(".//img[@class='dragImgPhyEntry']"));
		WebElement droppable = driver.findElement(By.id("physicianEntryAuditNumber"));

		action.moveToElement(draggable).click().build().perform();

		Thread.sleep(5000);
		//action.moveToElement(draggable).clickAndHold(draggable).moveToElement(droppable).release(droppable).build().perform();
		action.moveToElement(draggable).moveByOffset(-1,  -1).clickAndHold(draggable).moveToElement(droppable).release(droppable).build().perform();

		//action.dragAndDrop(draggable, droppable).build().perform();

		System.out.println("Done");

	}
}