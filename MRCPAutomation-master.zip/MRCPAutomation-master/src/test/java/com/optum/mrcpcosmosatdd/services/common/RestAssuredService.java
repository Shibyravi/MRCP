package com.optum.mrcpcosmosatdd.services.common;

import com.auth0.jwt.exceptions.JWTCreationException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

@SuppressWarnings("unused")
public class RestAssuredService {

	/**
	 * Main function
	 * 
	 * @param args
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException
	 */
	public static void main(String[] args) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		testGet();
		//testPost();
	}

	/**
	 * Sample function to test GET Request
	 * 
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException 
	 */
	private static void testGet() throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		Map<String, String> queryParams = new HashMap<>();
		Map<String, String> headers = new HashMap<>();

		String baseURL = "https://gateway-stage-core.optum.com";
		String childURL = "/api/uat/clm/cics-security/v1/cicscoms";

		queryParams.put("trans-code", "EP635");
		queryParams.put("site-id", "MSP");
		queryParams.put("user-id", "90030");
		queryParams.put("function", "I");

		//Setting JWT Token in Header i.e. Authorization
		headers.put("Authorization", "Bearer "+ JWTToken.generateJWTToken(baseURL));

		String response = getStringResponse(baseURL, childURL, headers, queryParams);
		System.out.println(response);
	}

	/**
	 * Sample function to test POST Request
	 * 
	 * @throws ParseException
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 */
	private static void testPost() throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		Map<String, String> queryParams = new HashMap<>();
		Map<String, String> headers = new HashMap<>();

		String baseURL = "https://gateway-stage-core.optum.com";
		String childURL = "/api/uatbm/clm/notify-add-informations/v1";

		//POST Testing
		String jsonData = "{\r\n" + 
				"  \"auditNo\": \"77777777\",\r\n" + 
				"  \"claimType\": \"P\",\r\n" + 
				"  \"docs\": [\r\n" + 
				"    {\r\n" + 
				"      \"documentId\": \"abctest-abctest-abctest-abctest-abctest\",\r\n" + 
				"      \"reportType\": \"OZ\"\r\n" + 
				"    }\r\n" + 
				"  ],\r\n" + 
				"  \"site\": \"EVC\"\r\n" + 
				"}";
		JSONObject requestParams = new JSONObject(jsonData);

		//headers.put("cosmosID", "90601");
		//Setting JWT Token in Header i.e. Authorization
		//headers.put("Authorization", "Bearer "+ JWTToken.generateJWTToken(baseURL));

		JSONObject jsonObject = postJSONResponse(baseURL, childURL, headers, requestParams);
		String memberNumber = (String) jsonObject.get("memberNumber");
		//memberNumber = jsonObject.getJSONObject("carrierDetail").getJSONArray("").get(0)
		System.out.println(jsonObject.toString());
	}

	/**
	 * GET Request
	 * 
	 * @param baseURL
	 * @param childURL
	 * @param headers
	 * @param queryParams
	 * @return
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException 
	 */
	public static JSONObject getJSONResponse(String baseURL, String childURL, Map<String, String> headers, Map<String, String> queryParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = given();

		//Setting headers in Request
		for(String key : headers.keySet()) {
			request.header(key, headers.get(key));
		}

		//Setting Query Params
		for(String key : queryParams.keySet()) {
			request.queryParam(key, queryParams.get(key));
		}
		{
			//Return response as JSONObject
			//return  (JSONObject) jsonParser. parse(request.get(childURL).getBody().asString());

			//org.json.JSONObject newObj= (org.json.JSONObject) (jsonParser. parse(request.get(childURL).getBody().asString()));
			
			//String memNbr = (String) newObj.getJSONObject("memberDetail").get("memberNumber");
			
		
			return new org.json.JSONObject( request.get(childURL).getBody().asString());
		}
	}


	/**
	 * GET Request
	 * 
	 * @param baseURL
	 * @param childURL
	 * @param headers
	 * @param queryParams
	 * @return
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException 
	 */
	public static String getStringResponse(String baseURL, String childURL, Map<String, String> headers, Map<String, String> queryParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = given();

		//Setting headers in Request
		for(String key : headers.keySet()) {
			request.header(key, headers.get(key));
		}

		//Setting Query Params
		for(String key : queryParams.keySet()) {
			request.queryParam(key, queryParams.get(key));
		}

		//Return response as JSONObject
		return request.get(childURL).getBody().asString();
	}

	/**
	 * POST Request
	 * 
	 * @param baseURL
	 * @param childURL
	 * @param headers
	 * @param requestParams
	 * @return
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException 
	 */
	public static JSONObject postJSONResponse(String baseURL, String childURL, Map<String, String> headers, JSONObject requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = given();

		//Setting Content Type as JSON
		request.contentType(ContentType.JSON);

		//Setting headers in request
		for(String key : headers.keySet()) {
			request.header(key, headers.get(key));
		}

		//Setting Body as JSON Object
		request.body(requestParams);

		//Return response as JSONObject
		return new JSONObject(request.post(childURL).getBody().asString());
	}

	/**
	 * POST Request
	 * 
	 * @param baseURL
	 * @param childURL
	 * @param headers
	 * @param requestParams
	 * @return
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException 
	 */
	public static String postStringResponse(String baseURL, String childURL, Map<String, String> headers, JSONObject requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		RestAssured.baseURI = baseURL;
		RequestSpecification request = given();

		//Setting Content Type as JSON
		request.contentType(ContentType.JSON);

		//Setting headers in request
		for(String key : headers.keySet()) {
			request.header(key, headers.get(key));
		}

		//Setting Body as JSON Object
		request.body(requestParams);

		//Return response as JSONObject
		return request.post(childURL).getBody().asString();
	}

}