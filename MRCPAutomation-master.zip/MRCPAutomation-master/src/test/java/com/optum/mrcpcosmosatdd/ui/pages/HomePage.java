package com.optum.mrcpcosmosatdd.ui.pages;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.common.RestAssuredService;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;
import com.optum.mrcpcosmosatdd.ui.utilities.Utils;

public class HomePage extends BasePage {

	private By label_WindowTitle = By.className("lwd-window-title");
	private By label_PopupTitle = By.className("modal-title");
	private By label_Username = By.id("userLink");
	private By button_Logout = By.id("logOut");
	private By mainmenu_View = By.id("windowLink");
	private By subMenu_ColorPicker = By.id("colorLink");
	private By buttons_OpenedWindows = By.xpath(".//div[@id='lwd-taskbar-button-container']/button");
	private By div_MainMenu = By.id("main-nav");
	private By nav_Toolbar = By.id("toolbar_show");
	private By button_ExpandToolbarArrow = By.className("glyphicon glyphicon-triangle-top gly-icon-top");
	private By button_CollapseToolbarArrow = By.className("glyphicon glyphicon-triangle-bottom gly-icon-Bottom");

	By item_SelectionCriteria = By.id("Processor_selection_criteria");
	//@FindBy(id="Processor_selection_criteria") private WebElement item_SelectionCriteria;
	//@FindBy(id="procLink") private Select list_Processor;

	/** 
	 * Validate the Window title
	 * 
	 * @param strTitle
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateTitle(String strTitle) throws InterruptedException{
		waitForPageToLoad();
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_Username));
		if(Utils.verifyElementPresent(label_Username)){
			if (strTitle.equalsIgnoreCase(driver.getTitle())) {
				Log.info("Window Title matched");
				return true;
			}
			else {
				Log.error("Window Title not matched");
				return false;
			}
		}
		else
			return false;
	}

	/**
	 * Validate Window Title
	 * 
	 * @param strWindowTitle
	 * @return
	 */
	/*public boolean validateWindowTitle(String strWindowTitle){

		if (strWindowTitle.equalsIgnoreCase(getWindowTitle())) {
			Log.info("Window Title matched");
			return true;
		}
		else {
			Log.error("Window Title not matched");
			return false;
		}
	}*/

	/**
	 * Validate Window Title
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean ValidateWindowTitle(String pageName) throws InterruptedException{
		waitForPageToLoad();
		List<WebElement> listWindows = driver.findElements(label_WindowTitle);
		for (WebElement webelement : listWindows) {
			if(webelement.getText().equalsIgnoreCase(pageName)) {
				Log.info(pageName + " is opened in CPA application");
				return true;
			}
		}
		Log.error(pageName + " is not opened in CPA application");
		return false;
	}

	/**
	 * Validate Popup Title
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean ValidatePopupTitle(String popupName) throws InterruptedException{
		waitForPageToLoad();
		List<WebElement> listWindows = driver.findElements(label_PopupTitle);
		for (WebElement webelement : listWindows) {
			if(webelement.getText().equalsIgnoreCase(popupName)) {
				Log.info(popupName + " is opened in CPA application");
				return true;
			}
		}
		Log.error(popupName + " is not opened in CPA application");
		return false;
	}

	/**
	 * Validate that the User Logged In
	 * 
	 * @param strUserName
	 * @return
	 */
	public boolean validateUserLoggedIn(String strUserName) {
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_Username));
		if (strUserName.equalsIgnoreCase(driver.findElement(label_Username).getText()))
			return true;
		else
			return false;
	}

	/**
	 * Get the Logged In Username
	 * 
	 * @return
	 */
	public String getUserNameLoggedIn() {
		return driver.findElement(label_Username).getText();
	}

	/**
	 * Set the User Profile Data so that can be used anywhere
	 * 
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 * @throws ParseException
	 */
	public static void setUserProfileData() throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException {
		String baseURL = "http://cparest-cpasystest.ose-ctc-core.optum.com";
		String childURL = "/profile/getProfileAttributes";

		Map<String,String> headers = new HashMap<>();
		Map<String,String> reqParam = new HashMap<>();
		reqParam.put("userid", PropertyReader.getInstance().readProperty("ValidUsername"));

		String jsonString = RestAssuredService.getStringResponse(baseURL, childURL, headers, reqParam);
		UserProfileDetails profileDetails = new UserProfileDetails();

		JSONObject jsonObject = new JSONObject(jsonString);

		profileDetails.setPhySite((String) jsonObject.getJSONArray("site").get(0));
		profileDetails.setHospSite((String) jsonObject.getJSONArray("hosp_site").get(0));
		profileDetails.setPhyProcGroup((String) jsonObject.getJSONArray("procGroup").get(0));
		profileDetails.setHospProcGroup((String) jsonObject.getJSONArray("hosp_procGroup").get(0));
		profileDetails.setProcessor(PropertyReader.getInstance().readProperty("ValidUsername"));
		profileDetails.setSupervisor((String) jsonObject.getJSONArray("supervisor").get(0));
		profileDetails.setSecurityLevel(Integer.parseInt((String)jsonObject.getJSONArray("imSecurityLevel").get(0)));
	}

	/**
	 * Logout of the CPA application
	 * 
	 * @throws InterruptedException
	 */
	public String logout() throws InterruptedException {
		waitForPageToLoad();
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_Username));
		driver.findElement(label_Username).click();
		Thread.sleep(1000);
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(button_Logout));
		driver.findElement(button_Logout).click();
		waitForPageToLoad();
		if(isElementDisplayed_Driver(By.id("USER"))) {
			Log.info("User Logged Out of CPA Application ");
			return "Logged Out";
		}
		else {
			Log.error("User not Logged Out of CPA Application ");
			return "Not Logged Out";
		}
	}

	/**
	 * Verify that the window is opened in CPA Application
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean verifyWindowOpened(String pageName) {
		List<WebElement> listOpenWindows = driver.findElements(buttons_OpenedWindows);
		for (WebElement webelement : listOpenWindows) {
			if(webelement.getText().equalsIgnoreCase(pageName)) {
				Log.info(pageName + " window is opened");
				return true;
			}
		}
		Log.error(pageName + " window is not opened");
		return false;
	}

	/**
	 * Select and open the window/page from Menu Bar
	 * 
	 * @param subMenuName
	 * @param mainMenuName
	 * @throws InterruptedException
	 */
	public void selectMenu(String subMenuName, String mainMenuName) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top']"));
		WebElement webElementMainMenu = null;
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.findElement(By.xpath("./a")).getText().trim().equals(mainMenuName.trim())) {
				webElementMainMenu = mainMenuWebEle;
				break;
			}
		}
		if (webElementMainMenu == null) {
			Log.error("ERROR - UI: Menu '" + mainMenuName + "' is not found.");
			Assert.fail("ERROR - UI: Menu '" + mainMenuName + "' is not found.");
		}

		//Main Menu Element
		webElementMainMenu.click();

		//SubMenu Click
		List<WebElement> subMenusWebEleList = webElementMainMenu.findElements(By.xpath(".//li"));
		int check = 0;
		for(WebElement webElement: subMenusWebEleList) {
			if(webElement.getText().trim().contains(subMenuName)) {
				webElement.findElement(By.xpath(".//a")).click();
				Log.info(subMenuName + " SubMenu under " + mainMenuName + " Menu has been opened");
				check=1;
				break;
			}
		}
		if(check == 0) {
			Log.error("ERROR - UI: SubMenu '" + subMenuName + "' is not found.");
			Assert.fail("ERROR - UI: SubMenu '" + subMenuName + "' is not found.");
		}

	}

	/**
	 * Select and open the window/page from Menu Bar
	 * 
	 * @param secondSubMenuName
	 * @param subMenuName
	 * @param mainMenuName
	 * @throws InterruptedException
	 */
	public void selectMenu(String secondSubMenuName, String subMenuName, String mainMenuName) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top']"));
		WebElement webElementMainMenu = null;
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.findElement(By.xpath("./a")).getText().trim().equals(mainMenuName.trim())) {
				webElementMainMenu = mainMenuWebEle;
				break;
			}
		}
		if (webElementMainMenu == null) {
			Log.error("ERROR - UI: Menu '" + mainMenuName + "' is not found.");
			Assert.fail("ERROR - UI: Menu '" + mainMenuName + "' is not found.");
		}

		//Main Menu Element
		webElementMainMenu.click();

		//SubMenu Click
		List<WebElement> subMenusWebEleList = webElementMainMenu.findElements(By.xpath(".//li"));
		WebElement webElementSubMenu = null;
		int check = 0;
		for(WebElement webElement: subMenusWebEleList) {
			if(webElement.getText().trim().contains(subMenuName)) {
				webElementSubMenu = webElement;
				webElement.findElement(By.xpath(".//a")).click();
				//Log.info(subMenuName + " SubMenu under " + mainMenuName + " Menu has been opened");
				check=1;
				break;
			}
		}
		if(check == 0) {
			Log.error("ERROR - UI: SubMenu '" + subMenuName + "' is not found.");
			Assert.fail("ERROR - UI: SubMenu '" + subMenuName + "' is not found.");
		}

		//Second Level SubMenu Click

		List<WebElement> secondLevelSubMenusWebEleList = webElementSubMenu.findElements(By.xpath(".//li"));
		int checkSecond = 0;
		for(WebElement webElement1: secondLevelSubMenusWebEleList) {
			if(webElement1.getText().trim().contains(secondSubMenuName)) {
				webElement1.findElement(By.xpath(".//a")).click();
				Log.info(secondSubMenuName + " Second Level Sub Menu under " + subMenuName + " Menu has been opened");
				checkSecond=1;
				break;
			}
		}
		if(checkSecond == 0) {
			Log.error("ERROR - UI: Second Level SubMenu '" + subMenuName + "' is not found.");
			Assert.fail("ERROR - UI: Second Level SubMenu '" + subMenuName + "' is not found.");
		}

	}

	/**
	 * Select and open the window/page from Menu Bar and Start the Timer
	 * 
	 * @param subMenuName
	 * @param mainMenuName
	 * @throws InterruptedException
	 */
	public void selectMenuAndStartTheTimer(String subMenuName, String mainMenuName) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top']"));
		WebElement webElementMainMenu = null;
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.findElement(By.xpath("./a")).getText().trim().equals(mainMenuName.trim())) {
				webElementMainMenu = mainMenuWebEle;
				break;
			}
		}
		if (webElementMainMenu == null) {
			Assert.fail("ERROR - UI: Menu '" + mainMenuName + "' is not found.");
		}

		//Main Menu Element
		webElementMainMenu.click();

		//SubMenu Click
		List<WebElement> subMenusWebEleList = webElementMainMenu.findElements(By.xpath(".//li"));
		int check = 0;
		for(WebElement webElement: subMenusWebEleList) {
			if(webElement.getText().trim().contains(subMenuName)) {
				webElement.findElement(By.xpath(".//a")).click();
				check=1;
				storeStartTime();
				break;
			}
		}
		if(check == 0)
			Assert.fail("ERROR - UI: SubMenu '" + subMenuName + "' is not found.");
	}


	/**
	 * Open the page/window from Toolbar
	 * 
	 * @param toolbarTitle
	 * @throws InterruptedException
	 */
	public void selectToolbar(String toolbarTitle) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//nav [@class='navbar navbar-default icon-nav hidden-xs']//a//img"));
		WebElement webElementToolbar = null;
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.getAttribute("title").equalsIgnoreCase(toolbarTitle.trim())) {
				webElementToolbar = mainMenuWebEle;
				break;
			}
		}
		if (webElementToolbar == null) {
			Assert.fail("ERROR - UI: Toolbar icon '" + toolbarTitle + "' is not found.");
		}

		//Toolbar Click
		webElementToolbar.click();
	}

	/**
	 * Open Window/Page using ALT, Menu and Submenu key in combination while holding the ALT key
	 * 
	 * @param menuKey
	 * @param subMenuKey
	 * @throws InterruptedException
	 */
	public void accessMenuUsingALTandShortcutKeysInCombinationHoldingALTKey(String menuKey, String subMenuKey) throws InterruptedException {
		//KeyUtils.keyPressWithAltUsingRobotClass(menuKey,subMenuKey);
		KeyUtils.keyPressWithAlt(menuKey,subMenuKey);
	}

	/**
	 * Open Window/Page using ALT plus Menu Key and then Releasing ALT key and pressing the SubMenu key
	 * 
	 * @param menuKey
	 * @param subMenuKey
	 * @throws InterruptedException
	 */
	public void accessMenuUsingALTandShortcutKeysHoldingALTKey(String menuKey, String subMenuKey) throws InterruptedException {
		KeyUtils.keyPressWithAlt(menuKey);
		KeyUtils.keyPressAlone(subMenuKey);	
	}

	/**
	 * Open Window/Page using ALT then Menu and then Submenu key without Holding ALT Key
	 * 
	 * @param menuKey
	 * @param subMenuKey
	 * @throws InterruptedException
	 */
	public void accessMenuUsingShortcutKeysReleasingALTKey(String menuKey, String subMenuKey) throws InterruptedException {
		KeyUtils.keyPressAlone(Keys.ALT);
		KeyUtils.keyPressAlone(menuKey);
		KeyUtils.keyPressAlone(subMenuKey);

	}

	public void accessMenuUsingALTandMainMenuShortcutKey(String mainMenuKey) throws InterruptedException {
		//KeyUtils.keyPressWithAltUsingRobotClass(mainMenuKey);
		KeyUtils.keyPressWithAlt(mainMenuKey);
	}

	public void accessWindowUsingWindowShortcutKeyHoldingCTRLKey(String shortcutKey) throws InterruptedException {
		//KeyUtils.keyPressWithCtrlUsingRobotCLass(shortcutKey);
		KeyUtils.keyPressWithCtrl(shortcutKey);
	}

	public boolean mainMenuClick(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.findElement(By.xpath("./a")).getText().trim().equals(mainMenu.trim())) {
				mainMenuWebEle.click();
				Log.info("Clicked on "+mainMenu + " main menu");
				return true;
			}
		}

		Log.error("Menu '" + mainMenu + "' is not found.");
		return false;
	}

	public boolean subMenuClick(String subMenu) throws InterruptedException {
		waitForPageToLoad();
		//SubMenu Click
		List<WebElement> subMenusWebEleList = driver.findElements(By.xpath(".//li[@class='dropdown dropdown-top open']//li"));
		if(subMenusWebEleList.size()>0) {
			int check = 0;
			for(WebElement webElement: subMenusWebEleList) {
				if(webElement.getText().trim().contains(subMenu)) {
					webElement.findElement(By.xpath(".//a")).click();
					Log.info(subMenu + " SubMenu is clicked using mouse");
					return true;
				}
			}
			if(check==0) {
				Log.error(subMenu + " SubMenu is not clicked using mouse");
				return false;
			}
			return false;
		}
		else {
			Log.error("No Main Menu is opened");
			return false;
		}
	}

	/**
	 * Change the CPA Background color and validate that it has been changed
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean changeBackgroundColor() throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		driver.findElement(mainmenu_View).click();;
		Thread.sleep(1000);
		driver.findElement(subMenu_ColorPicker).click();
		Thread.sleep(1000);
		String bgcolor = getBackgroundColor();
		if(!bgcolor.equalsIgnoreCase("rgba(213, 234, 255, 1)")) {
			driver.findElement(By.xpath(".//li[@class='color cyan']")).click();
			Thread.sleep(1000);
			if(getBackgroundColor().equalsIgnoreCase("rgba(213, 234, 255, 1)")) {
				Constants.BACKGROUNDCOLOR = "rgba(213, 234, 255, 1)";
				Log.info("Background color changed to Yellow");
				return true;
			}
			else {
				Constants.BACKGROUNDCOLOR = null;
				Log.error("Background color not changed to Yellow");
				return false;
			}
		}
		else if(!bgcolor.equalsIgnoreCase("rgba(255, 255, 215, 1)")) {
			driver.findElement(By.xpath(".//li[@class='color yellow']")).click();
			Thread.sleep(1000);
			if(getBackgroundColor().equalsIgnoreCase("rgba(255, 255, 215, 1)")) {
				Constants.BACKGROUNDCOLOR = "rgba(213, 234, 255, 1)";
				Log.info("Background color changed to Cyan");
				return true;
			}
			else {
				Constants.BACKGROUNDCOLOR = null;
				Log.error("Background color not changed to Cyan");
				return false;
			}
		}
		return false;
	}

	public boolean clickOnPageButtonInBottomTaskbar(String pageName) throws InterruptedException {
		try {
			waitForPageToLoad();
			WebElement webElement = driver.findElement(By.xpath("//div[@id='lwd-taskbar-button-container']//span[contains(text(),'"+pageName+"')]//ancestor::button"));
			if(webElement.isDisplayed()) {
				webElement.click();
				Log.info("Clicked on "+pageName + " page button available in bottom taskbar");
				return true;
			}
			else {
				Log.info(pageName+ " page button is not dispalyed");
				return false;
			}
		}
		catch(NoSuchElementException e){
			Log.error("No Page button in bottom taskbar with title " + pageName);
			return false;
		}	
	}

	/**
	 * Validate that the Page is displayed in Front(On Top)
	 * 
	 * @param pageName
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validatePageDisplayedOnTop(String pageName) throws InterruptedException {
		try {
			waitForPageToLoad();
			//Thread.sleep(2000);
			WebElement webElement = driver.findElement(By.xpath("//div[@id='lwd-taskbar-button-container']//span[contains(text(),'"+pageName+"')]//ancestor::button"));
			String borderTopColor = webElement.getCssValue("border-top-color");
			if(borderTopColor.equalsIgnoreCase("rgba(194, 86, 8, 1)")) {
				Log.info(pageName + " page is displayed in front");
				return true;
			}
			else{
				Log.error(pageName + " page is not displayed in front");
				return false;
			}
		}
		catch(NoSuchElementException e){
			Log.error("No Page button in bottom taskbar with title " + pageName);
			return false;
		}
	}

	public boolean validateUserCanToggleBetweenPages() throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listOpenWindows = driver.findElements(buttons_OpenedWindows);
		if(listOpenWindows.size()>1) {
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(listOpenWindows.get(0)));
			listOpenWindows.get(0).click();
			for (WebElement page:listOpenWindows) {
				if(!validatePageDisplayedOnTop(page.getText())){
					Log.error("Ctrl + Tab keypress not working fine for switching between pages");
					return false;
				}
				KeyUtils.keyPressCtrlPlusTab();
			}
			if(!validatePageDisplayedOnTop(listOpenWindows.get(0).getText())){
				Log.error("Ctrl + Tab keypress not working fine for switching between pages");
				return false;
			}
		}
		else {
			Log.error("Please open 2 or more pages to check Ctrl + Tab fucntionality for switching between pages");
			return false;
		}

		return true;
	}

	public boolean validatePageClosedOnESCKeyPress(String pageName) throws InterruptedException {
		waitForPageToLoad();
		if(!verifyWindowOpened(pageName)) {
			Log.error(pageName + " page is not opened");
			return false;
		}
		clickOnPageButtonInBottomTaskbar(pageName);
		validatePageDisplayedOnTop(pageName);
		KeyUtils.keyPressEsc();
		waitForPageToLoad();
		if(verifyWindowOpened(pageName)) {
			Log.error(pageName + " page is not closed on ESC key press");
			return false;
		}
		else {
			Log.info(pageName + " page is closed on ESC key press");
			return true;
		}
	}

	public boolean validateMainMenuBackgroundColor() throws InterruptedException {
		waitForPageToLoad();
		String bgColor = getBackgroundColor(div_MainMenu);
		if(bgColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
			Log.info("Background color of Main Menu is white i.e. #FFFFFF");
			return true;
		}
		else {
			Log.error("Background color of Main Menu is not white i.e. #FFFFFF");
			return false;
		}
	}

	public boolean validateToolbarBackgroundColor() throws InterruptedException {
		waitForPageToLoad();
		if(!isElementDisplayed_Driver(nav_Toolbar)) {
			if(isElementDisplayed_Driver(button_ExpandToolbarArrow)) {
				Log.info("Toolbar is not displayed therefore clicking on Expand Button");
				driver.findElement(button_ExpandToolbarArrow).click();
				waitForPageToLoad();
			}
			else {
				Log.error("Toolbar is not displayed. Also, Expand Button is not diplayed as well");
				return false;
			}	
		}

		String bgColor = getBackgroundColor_Driver(nav_Toolbar);
		if(bgColor.equalsIgnoreCase("rgba(239, 239, 238, 1)")) {
			Log.info("Background color of Toolbar is light grey i.e. #EFEFEE");
			return true;
		}
		else {
			Log.error("Background color of Toolbar is not light grey i.e. #EFEFEE");
			return false;
		}
	}

	public boolean validateHomeBackgroundColor() throws InterruptedException {
		if(getBackgroundColor().equalsIgnoreCase(Constants.BACKGROUNDCOLOR)){
			Log.info("Background color matched");
			return true;
		}
		else {
			Log.error("Background color does not match");
			return false;
		}
	}

	public boolean validateHomeBackgroundColor(String color) throws InterruptedException {
		if(getBackgroundColor().equalsIgnoreCase(color)){
			Log.info("Background color matched");
			return true;
		}
		else {
			Log.error("Background color doesn not match");
			return false;
		}
	}

	public boolean validateMainMenuHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			if (mainMenuEle.getText().trim().equals(mainMenu.trim())) {
				if(getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")){
					Log.info(mainMenu + " Main Menu is highlighted in grey color");
					return true;
				}
				else {
					Log.error(mainMenu + " Main Menu is not highlighted in grey color");
					return false;
				}
			}
		}
		Log.error(mainMenu + " Main Menu is not highlighted in grey color");
		return false;
	}

	public boolean validateOnlyMainMenuHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			if (mainMenuEle.getText().trim().equals(mainMenu.trim())) {
				//System.out.println(mainMenuEle.getText().trim()+"--"+getBackgroundColor_Driver(mainMenuEle));
				if(!getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")){
					Log.info(mainMenuEle + " Main Menu is not highlighted in grey color");
					return false;
				}
			}
			else {
				//System.out.println(mainMenuEle.getText().trim()+"--"+getBackgroundColor_Driver(mainMenuEle));
				if(!getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(0, 0, 0, 0)")){
					Log.error(mainMenu + " Main Menu is not having background color as transparent");
					return false;
				}				
			}
		}
		Log.info(mainMenu + " Main Menu is only highlighted in grey color");
		return true;
	}

	public boolean validateNoneOfTheMainMenuHighlighted() throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			System.out.println("main menu BG color"+ " "+ getBackgroundColor(mainMenuEle));
			if(!getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(0, 0, 0, 0)")){
				Log.error(mainMenuEle.getText() + " Main Menu is not having background color as transparent");
				return false;
			}				
		}
		Log.info("None of the main menu is highlighted");
		return true;
	}

	public boolean validateOpenedMainMenuHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			if (mainMenuEle.getText().trim().equals(mainMenu.trim())) {
				System.out.println(getBackgroundColor(mainMenuEle));
				if(getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 225, 233, 1)") || getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")) {
					Log.info(mainMenu + " Main Menu is opened and highlighted in grey color");
					return true;
				}
				else if(getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")){
					Log.info(mainMenu + " Main Menu is opened and highlighted in grey color");
					return true;
				}
				else{
					Log.error(mainMenu + " Main Menu is not opened and highlighted in grey color");
					return false;
				}
			}
		}
		Log.error(mainMenu + " Main Menu is not opened and highlighted in grey color");
		return false;
	}

	public boolean pressRightArrowKeyUntilMainMenuHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top']"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			if (mainMenuEle.getText().trim().equals(mainMenu.trim())) {
				for(int i=0;i<mainMenusWebEleList.size();i++) {
					//KeyUtils.keyPressRightArrowUsingRobotClass();
					KeyUtils.keyPressRightArrow();
					if(getBackgroundColor(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")){
						Log.info(mainMenu + " Main Menu is highlighted in grey color");
						return true;
					}
				}
			}
		}
		Log.error(mainMenu + " Main Menu is not highlighted in grey color");
		return false;
	}

	public boolean pressRightArrowKeyUntilMainMenuOpenedAndHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for(int i=0;i<=mainMenusWebEleList.size();i++){
			WebElement openedMainMenu = driver.findElement(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']/a"));
			if (openedMainMenu.getText().trim().equals(mainMenu.trim())) {
				if(getBackgroundColor(openedMainMenu).equalsIgnoreCase("rgba(223, 225, 233, 1)")){
					Log.info(mainMenu + " Main Menu is opened and highlighted in grey color");
					return true;
				}
			}
			KeyUtils.keyPressRightArrow();
		}
		Log.error(mainMenu + " Main Menu is not opened and highlighted in grey color");
		return false;
	}

	/*
	public boolean pressDownArrowKeyUntilMainMenuHighlighted(String mainMenu) throws InterruptedException {
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top']"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			WebElement mainMenuEle = mainMenuWebEle.findElement(By.xpath("./a"));
			if (mainMenuEle.getText().trim().equals(mainMenu.trim())) {
				for(int i=0;i<mainMenusWebEleList.size();i++) {
					keyPressRightArrowUsingRobotClass();
					if(getBackgroundColor_Driver(mainMenuEle).equalsIgnoreCase("rgba(223, 223, 227, 1)")){
						Log.info(mainMenu + " Main Menu is highlighted in grey color");
						return true;
					}
				} 
			}
		}
		Log.error(mainMenu + " Main Menu is not highlighted in grey color");
		return false;
	} */

	public boolean validateHighligtedSubmenuUnderMenu(String subMenuName, String mainMenuName) throws InterruptedException {

		WebElement openedMainMenu = driver.findElement(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']/a"));
		if(openedMainMenu.getText().trim().equalsIgnoreCase(mainMenuName)) {
			List<WebElement> subMenuList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']//li//a"));
			for( WebElement webElement : subMenuList){
				if(webElement.getText().trim().contains(subMenuName)) {
					if(getBackgroundColor(webElement).equalsIgnoreCase("rgba(223, 223, 227, 1)")) {
						Log.info(subMenuName + " sub menu is highlighted");
						return true;
					}
					else {
						Log.error(subMenuName + " sub menu is not highlighted");
						return false;
					}
				}
			}
		}
		else {
			Log.error(mainMenuName+" main menu is not opened");
			return false;
		}

		Log.error(subMenuName+" sub menu is not highlighted");
		return false;
	}

	public boolean validateOnlyHighligtedSubmenuUnderMenu(String subMenuName, String mainMenuName) throws InterruptedException {

		WebElement openedMainMenu = driver.findElement(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']/a"));
		if(openedMainMenu.getText().trim().equalsIgnoreCase(mainMenuName)) {
			List<WebElement> subMenuList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']//li//a"));
			for( WebElement webElement : subMenuList){
				if(webElement.getText().trim().contains(subMenuName)) {
					if(!getBackgroundColor(webElement).equalsIgnoreCase("rgba(223, 223, 227, 1)")) {
						Log.error(subMenuName + " sub menu is not highlighted");
						return false;
					}
				}
				else {
					if(!getBackgroundColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 0)")) {
						Log.error(subMenuName + " sub menu is not having background color as transparent");
						return false;
					}
				}
			}
		}
		else {
			Log.error(mainMenuName+" main menu is not opened");
			return false;
		}

		Log.info(subMenuName+" sub menu is only highlighted");
		return true;
	}

	public boolean validateWindowDisplayed(String windowName) throws InterruptedException {
		waitForPageToLoad();
		List<WebElement> windowList = driver.findElements(By.xpath(".//span[@class='lwd-window-title']"));
		List<WebElement> popupList = driver.findElements(By.xpath(".//span[@class='modal-title']"));
		windowList.addAll(popupList);
		for(WebElement webElement: windowList) {
			if(webElement.getText().trim().equalsIgnoreCase(windowName)){
				if(isElementDisplayed(webElement)) {
					Log.info(windowName+" window is opened");
					return true;
				}
				else {
					Log.error(windowName+" window is not opened");
					return false;
				}
			}
		}

		Log.error(windowName+" window is not opened");
		return false;
	}

	public boolean hoverOverMainMenu(String mainMenuName) throws InterruptedException{
		waitForPageToLoad();
		//Thread.sleep(1000);
		List<WebElement> mainMenusWebEleList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[contains(@class,'dropdown dropdown-top')]"));
		for (WebElement mainMenuWebEle : mainMenusWebEleList) {
			if (mainMenuWebEle.findElement(By.xpath("./a")).getText().trim().equals(mainMenuName.trim())) {
				mouseHover(mainMenuWebEle);
				Log.info("Hovered over "+mainMenuName + " main menu");
				return true;
			}
		}
		Log.error(mainMenuName + " main menu not found");
		return false;	
	}

	public boolean hoverOverSubMenu(String mainMenuName, String subMenuName) throws InterruptedException{
		waitForPageToLoad();
		WebElement openedMainMenu = driver.findElement(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']/a"));
		if(openedMainMenu.getText().trim().equalsIgnoreCase(mainMenuName)) {
			List<WebElement> subMenuList = driver.findElements(By.xpath(".//div[@id='main-nav']//li[@class='dropdown dropdown-top open']//li//a"));
			for( WebElement webElement : subMenuList){
				if(webElement.getText().trim().contains(subMenuName)) {
					mouseHover(webElement);
					Log.info("Hovered over "+subMenuName +" sub menu under +"+ mainMenuName + " main menu");
					return true;
				}
			}
		}
		else {
			Log.error(mainMenuName+" main menu is not opened");
			return false;
		}
		Log.error(subMenuName+" sub menu is not highlighted");
		return false;
	}

	public void scrollBy(String xPixels, String yPixels) throws InterruptedException, NumberFormatException {
		waitForPageToLoad();
		JAVASCRIPTEXECUTOR.executeScript("window.scrollBy("+Integer.parseInt(xPixels)+","+Integer.parseInt(yPixels)+")");
		waitForPageToLoad();
	}

	public List<String> getAuthKeysFromCookies(String AuthToken, String idToken) throws InterruptedException {

		List<String> authKeys = new ArrayList();
		try {

			/*JavascriptExecutor js = (JavascriptExecutor) driver; 
			String oidcAuthToken =   (String) js.executeScript(String.format("return window.cookies.getItem('%s');", AuthToken));
			String oidcIDToken =   (String) js.executeScript(String.format("return window.cookies.getItem('%s');", idToken));		*/
			String oidcAuthToken  = driver.manage().getCookieNamed(AuthToken).getValue();
			String oidcIdToken  = driver.manage().getCookieNamed(idToken).getValue();
			authKeys.add(oidcAuthToken);
			authKeys.add(oidcIdToken);
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		return authKeys;
	}


}