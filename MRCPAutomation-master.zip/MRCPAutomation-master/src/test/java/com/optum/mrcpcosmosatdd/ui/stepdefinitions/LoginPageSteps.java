package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import com.optum.mrcpcosmosatdd.security.GeneratePlainPassword;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.HomePage;
import com.optum.mrcpcosmosatdd.ui.pages.LoginPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

public class LoginPageSteps extends MRCPTestBase {

	String username;
	String password;

	@When("^I Login With Valid Credentials$")
	public void iLoginWithValidCredentials() throws Throwable {
		username = PropertyReader.getInstance().readProperty("ValidUsername");
		password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("ValidPassword"));
		getPage(LoginPage.class).login(username, password);
	}
	
	@When("^I should be able to switch the window$")
	public void I_Should_Be_Able_To_Switch_The_Window() throws InterruptedException {
		Assert.assertEquals(getPage(LoginPage.class).switchWindow(), true);
	}

	@Then("^I Should Be Logged In$")
	public void iShouldBeLoggedIn() throws Throwable {
		username = PropertyReader.getInstance().readProperty("ValidUsername");
		Assert.assertEquals(new HomePage().validateUserLoggedIn(username), true); 
	}

	@When("^I Login With Invalid Credentails$")
	public void iLoginWithInvalidCredentailsAsAnd() throws Throwable {
		username = PropertyReader.getInstance().readProperty("InvalidUsername");
		password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("InvalidPassword"));
		Assert.assertEquals(getPage(LoginPage.class).login(username, password),"Not Logged In");
	}

	@Then("^I Should See The \"([^\"]*)\" Error Message$")
	public void iShouldSeeTheErrorMessage(String expectedText) throws Throwable {
		String actualText = getPage(LoginPage.class).getErrorMessage();
		Assert.assertTrue(expectedText.equals(actualText.trim()));
	}

	@When("^I login with Superuser credentials$")
	public void iLoginWithSuperUserCredentials() throws Throwable {
		username = PropertyReader.getInstance().readProperty("CICS-SuperUser-Username");
		password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("CICS-SuperUser-Password"));
		Assert.assertEquals(getPage(LoginPage.class).login(username, password), "Logged In");
	}

	@When("^I login with Supervisor credentials$")
	public void iLoginWithSuperwiserUserCredentials() throws Throwable {
		username = PropertyReader.getInstance().readProperty("CICS-Supervisor-Username");
		password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("CICS-Supervisor-Password"));
		Assert.assertEquals(getPage(LoginPage.class).login(username, password), "Logged In");
	}

	@When("^I login with Level0 user credentials$")
	public void iLoginWithLevel0Credentials() throws Throwable {
		username = PropertyReader.getInstance().readProperty("CICS-Level0-Username");
		password = GeneratePlainPassword.getPlainPassword(PropertyReader.getInstance().readProperty("CICS-Level0-Password"));
		getPage(LoginPage.class).login(username, password);}
}