package com.optum.mrcpcosmosatdd.ui.utilities;
//package com.optum.cpacosmosatdd.ui.utilities;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//
//import com.optum.cpacosmosatdd.reporting.Log;
//import com.optum.cpacosmosatdd.ui.pages.BasePage;
//
//public class MouseUtils extends BasePage {
//	
//
//	/**
//	 * Mouse Hover and Click on Webelement
//	 * 
//	 * @param selector
//	 * @return 
//	 * @throws InterruptedException
//	 */
//	public void mouseClick(By selector) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
//			if (rootEle().findElement(selector).isDisplayed()) {
//				ACTION.moveToElement(rootEle().findElement(selector)).click().build().perform();
//				Log.info("Mouse hovered and clicked on WebElement: " + selector);
//			} else
//				Log.error("WebElement: " + selector + "not found");
//		} catch (NoSuchElementException e) {
//			Log.error("Element is not present in DOM");
//		}
//	}
//
//	/**
//	 * Mouse Hover and Click on Web element
//	 * 
//	 * @param webElement
//	 * @throws InterruptedException
//	 */
//	public void mouseClick(WebElement webElement) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
//			if (webElement.isDisplayed()) {
//				ACTION.moveToElement(webElement).click().build().perform();
//				Log.info("Mouse hovered and clicked on WebElement: " + webElement.getText());
//			} else
//				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
//		} catch (NoSuchElementException e) {
//			Log.error("Element is not present in DOM");
//		}
//	}
//
//	/**
//	 * Mouse Hover and Click on Webelement
//	 * 
//	 * @param selector
//	 * @throws InterruptedException
//	 */
//	public void mouseClick_Driver(By selector) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
//			if (driver.findElement(selector).isDisplayed()) {
//				ACTION.moveToElement(driver.findElement(selector)).click().build().perform();
//				Log.info("Mouse hovered and clicked on WebElement: " + selector);
//			} else
//				Log.error("WebElement: " + selector + "not found");
//		} catch (NoSuchElementException e) {
//			Log.error("Element is not present in DOM");
//		}
//	}
//
//	/**
//	 * Perform MouseHover
//	 * 
//	 * @param selector
//	 * @throws InterruptedException
//	 */
//	public void mouseHover(By selector) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
//			if (rootEle().findElement(selector).isDisplayed()) {
//				ACTION.moveToElement(rootEle().findElement(selector)).build().perform();
//				Log.info("Mouse hovered on WebElement: " + rootEle().findElement(selector).getText());
//			} else
//				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector
//						+ " is not displayed");
//		} catch (NoSuchElementException e) {
//			Log.error("Web element with selector as " + selector + " is not present in DOM");
//		}
//	}
//
//	/**
//	 * Perform MouseHover
//	 * 
//	 * @param webElement
//	 * @throws InterruptedException
//	 */
//	public void mouseHover(WebElement webElement) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
//			if (webElement.isDisplayed()) {
//				ACTION.moveToElement(webElement).build().perform();
//				Log.info("Mouse hovered on WebElement: " + webElement.getText());
//			} else
//				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
//		} catch (NoSuchElementException e) {
//			Log.error(webElement.getText() + " web element with selector as " + webElement + " is not present in DOM");
//		}
//	}
//
//	/**
//	 * Mouse Hover and Click on Web element
//	 * 
//	 * @param selector
//	 * @throws InterruptedException
//	 */
//	public void mouseDoubleClick(By selector) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
//			if (rootEle().findElement(selector).isDisplayed()) {
//				ACTION.moveToElement(rootEle().findElement(selector)).doubleClick().build().perform();
//				Log.info(
//						"Mouse hovered and Double clicked on WebElement: " + rootEle().findElement(selector).getText());
//			} else
//				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector
//						+ " is not found");
//		} catch (NoSuchElementException e) {
//			Log.error("Element is not present in DOM");
//		}
//
//	}
//
//	/**
//	 * Mouse Hover and Click on Web element
//	 * 
//	 * @param webElement
//	 * @throws InterruptedException
//	 */
//	public void mouseDoubleClick(WebElement webElement) throws InterruptedException {
//		try {
//			// windowRootWebElement.click();
//			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
//			if (webElement.isDisplayed()) {
//				ACTION.moveToElement(webElement).doubleClick().build().perform();
//				Log.info("Mouse hovered and Double clicked on WebElement: " + webElement.getText());
//			} else
//				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
//		} catch (NoSuchElementException e) {
//			Log.error("Element is not present in DOM");
//		}
//	}
//
//}