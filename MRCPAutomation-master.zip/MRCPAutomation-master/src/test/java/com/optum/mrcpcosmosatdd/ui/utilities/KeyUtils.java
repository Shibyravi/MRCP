package com.optum.mrcpcosmosatdd.ui.utilities;

import org.openqa.selenium.Keys;

//import java.awt.event.KeyEvent;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;

/**
 * @author sgupt228
 *
 */
public class KeyUtils extends BasePage {

	/**
	 * Constructor: Moving mouse pointer to Optum Logo so that it doesn't hinders
	 * with Keypress events
	 * 
	 * @throws InterruptedException
	 */
	
	public KeyUtils() throws InterruptedException {
		// driver.findElement(By.id("CPAHomeLogo")).click();
		//mouseHover(driver.findElement(By.id("CPAHomeLogo")));
	}

	/**
	 * Key Press while holding the ALT key
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	public static void keyPressWithAlt(String keyName) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		keyName = keyName.toLowerCase();
		ACTION.keyDown(Keys.ALT).sendKeys(keyName).keyUp(Keys.ALT).build().perform();
		// ACTION.sendKeys(Keys.chord(Keys.ALT, keyName)).build().perform();
		Log.info("Pressed '" + keyName + "' key while holiding the ALT Key");
		Thread.sleep(1000);
	}

	/**
	 * Key Press while holding the ALT key
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressWithAltUsingRobotClass(String keyName) throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000); char
	 * character = keyName.charAt(0); int ascii = (int) character;
	 * ROBOT.keyPress(KeyEvent.VK_ALT); Thread.sleep(1000); ROBOT.keyPress(ascii);
	 * ROBOT.keyRelease(ascii); ROBOT.keyRelease(KeyEvent.VK_ALT);
	 * //ACTION.KeysendKeys(keyName1).sendKeys(keyName2).keyUp(Keys.ALT).build().
	 * perform(); Log.info("Pressed '" + keyName +
	 * "' key while holiding the ALT Key"); Thread.sleep(1000); }
	 */

	/**
	 * Press Key Press one after another while holding the ALT key
	 * 
	 * @param keyName1
	 * @param keyName2
	 * @throws InterruptedException
	 */
	public static void keyPressWithAlt(String keyName1, String keyName2) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		keyName1 = keyName1.toLowerCase();
		keyName2 = keyName2.toLowerCase();
		ACTION.keyDown(Keys.ALT).sendKeys(keyName1).sendKeys(keyName2).keyUp(Keys.ALT).build().perform();
		Log.info("Pressed '" + keyName1 + " and " + keyName2 + "' key while holiding the ALT Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Key Press one after another while holding the ALT key
	 * 
	 * @param keyName1
	 * @param keyName2
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressWithAltUsingRobotClass(String keyName1, String keyName2)
	 * throws InterruptedException { waitForPageToLoad(); //Thread.sleep(1000); char
	 * character1 = keyName1.charAt(0); char character2 = keyName2.charAt(0); int
	 * ascii1 = (int) character1; int ascii2 = (int) character2;
	 * ROBOT.keyPress(KeyEvent.VK_ALT); Thread.sleep(1000); ROBOT.keyPress(ascii1);
	 * Thread.sleep(1000); ROBOT.keyPress(ascii2); ROBOT.keyRelease(ascii1);
	 * ROBOT.keyRelease(ascii2); ROBOT.keyRelease(KeyEvent.VK_ALT);
	 * //ACTION.KeysendKeys(keyName1).sendKeys(keyName2).keyUp(Keys.ALT).build().
	 * perform(); Log.info("Pressed '" + keyName1 + " and "+keyName2
	 * +"' key while holiding the ALT Key"); Thread.sleep(1000); }
	 */

	/**
	 * Key press while holding CTRL Key
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	public static void keyPressWithCtrl(String keyName) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		keyName = keyName.toLowerCase();
		ACTION.keyDown(Keys.CONTROL).sendKeys(keyName).keyUp(Keys.CONTROL).build().perform();
		Log.info("Pressed '" + keyName + "' key while holiding the Ctrl Key");
		// Thread.sleep(1000);
	}

	/**
	 * Key press while holding CTRL Key using ROBOT Class
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressWithCtrlUsingRobotCLass(String keyName) throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000); char
	 * character = keyName.charAt(0); int ascii = (int) character;
	 * ROBOT.keyPress(KeyEvent.VK_CONTROL); Thread.sleep(1000);
	 * ROBOT.keyPress(ascii); ROBOT.keyRelease(ascii);
	 * ROBOT.keyRelease(KeyEvent.VK_CONTROL);
	 * //ACTION.keyDown(Keys.CONTROL).sendKeys(keyName).keyUp(Keys.CONTROL).build().
	 * perform(); Log.info("Pressed '" + keyName
	 * +"' key while holiding the Ctrl Key"); Thread.sleep(1000); }
	 */

	/**
	 * Key press
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	public static void keyPressAlone(String keyName) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		keyName = keyName.toLowerCase();
		ACTION.sendKeys(keyName).build().perform();
		Log.info("Pressed '" + keyName + "' alone");
		// Thread.sleep(1000);
	}

	/**
	 * Key press
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	public static void keyPressAlone(Keys keyName) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(keyName).build().perform();
		Log.info("Pressed '" + keyName + "' alone");
		// Thread.sleep(1000);
	}

	/**
	 * Key press Using Robot Class
	 * 
	 * @param keyName
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressAloneUsingRobotClass(String keyName) throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000); char
	 * character = keyName.charAt(0); int ascii = (int) character;
	 * ROBOT.keyPress(ascii); ROBOT.keyRelease(ascii); Log.info("Pressed '" +
	 * keyName +"' alone"); Thread.sleep(1000); }
	 */

	/**
	 * Press Page Up Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressPageUp() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.PAGE_UP).build().perform();
		Log.info("Pressed Page Up key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Page Up Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressPageUpUsingRobotClass() throws InterruptedException {
	 * waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_PAGE_UP); ROBOT.keyRelease(KeyEvent.VK_PAGE_UP);
	 * Log.info("Pressed Page Up key"); Thread.sleep(1000); }
	 */

	/**
	 * Press Page Down Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressPageDown() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.PAGE_DOWN).build().perform();
		Log.info("Pressed Page Up key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Page Down Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressPageDownUsingRobotClass() throws InterruptedException {
	 * waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_PAGE_DOWN);
	 * ROBOT.keyRelease(KeyEvent.VK_PAGE_DOWN); Log.info("Pressed Page Up key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press TAB Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressTab() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.TAB).build().perform();
		Log.info("Pressed Tab key");
		// Thread.sleep(1000);
	}

	/**
	 * Press TAB Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressTabUsingRobotClass() throws InterruptedException {
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_TAB);
	 * ROBOT.keyRelease(KeyEvent.VK_TAB); Log.info("Pressed TAB key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press ALT Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressALT() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.ALT).keyUp(Keys.ALT).build().perform();
		Log.info("Pressed ALT key");
		// Thread.sleep(1000);
	}

	/**
	 * Press ALT Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressALTUsingRobotClass() throws InterruptedException {
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_ALT);
	 * ROBOT.keyRelease(KeyEvent.VK_ALT); Log.info("Pressed ALT key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Shift + TAB Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressShiftPlusTab() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.LEFT_SHIFT).sendKeys(Keys.TAB).keyUp(Keys.LEFT_SHIFT).build().perform();
		Log.info("Pressed Shift + Tab key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Shift + TAB Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressShiftPlusTabUsingRobotClass() throws InterruptedException
	 * { waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_SHIFT); Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_TAB); ROBOT.keyRelease(KeyEvent.VK_TAB);
	 * ROBOT.keyRelease(KeyEvent.VK_SHIFT); Log.info("Pressed Shift + TAB key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Shift + Right Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressShiftPlusRightArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.LEFT_SHIFT).sendKeys(Keys.RIGHT).keyUp(Keys.LEFT_SHIFT).build().perform();
		Log.info("Pressed Shift + Right key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Shift + Right Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressShiftPlusRightUsingRobotClass() throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_SHIFT); Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_RIGHT); ROBOT.keyRelease(KeyEvent.VK_RIGHT);
	 * ROBOT.keyRelease(KeyEvent.VK_SHIFT); Log.info("Pressed Shift + Right key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Shift + Left Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressShiftPlusLeftArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.LEFT_SHIFT).sendKeys(Keys.LEFT).keyUp(Keys.LEFT_SHIFT).build().perform();
		Log.info("Pressed Shift + Right key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Shift + Right Left using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressShiftPlusLeftUsingRobotClass() throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_SHIFT); Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_LEFT); ROBOT.keyRelease(KeyEvent.VK_LEFT);
	 * ROBOT.keyRelease(KeyEvent.VK_SHIFT); Log.info("Pressed Shift + Right key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Ctrl + TAB Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressCtrlPlusTab() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).keyUp(Keys.CONTROL).build().perform();
		Log.info("Pressed Ctrl + Tab key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Ctrl + TAB Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressCtrlPlusTabUsingRobotClass() throws InterruptedException
	 * { waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_CONTROL); Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_TAB); ROBOT.keyRelease(KeyEvent.VK_TAB);
	 * ROBOT.keyRelease(KeyEvent.VK_CONTROL); Log.info("Pressed Ctrl + TAB key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Left Arrow Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressLeftArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.LEFT).build().perform();
		Log.info("Pressed Left Arrow Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Left Arrow Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressLeftArrowUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_LEFT);
	 * ROBOT.keyRelease(KeyEvent.VK_LEFT); Log.info("Pressed Left Arrow Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Left Arrow Key Multiple times
	 * 
	 * @param numberOfTimes
	 * @throws InterruptedException
	 */
	public static void keyPressLeftArrowMultipleTimes(int numberOfTimes) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		for (int i = 0; i < numberOfTimes; i++) {
			keyPressLeftArrow();
		}
		Log.info("Pressed Left Arrow Key " + numberOfTimes + " times");
		// Thread.sleep(1000);
	}

	/**
	 * Press Left Arrow Key Multiple times Using Robot Class
	 * 
	 * @param numberOfTimes
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressLeftArrowMultipleTimesUsingRobotClass(int numberOfTimes)
	 * throws InterruptedException{ waitForPageToLoad(); //Thread.sleep(1000);
	 * for(int i=0;i<numberOfTimes;i++) { ROBOT.keyPress(KeyEvent.VK_LEFT);
	 * ROBOT.keyRelease(KeyEvent.VK_LEFT); Thread.sleep(100); }
	 * 
	 * Log.info("Pressed Left Arrow Key " + numberOfTimes + " times");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Right Arrow Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressRightArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.RIGHT).build().perform();
		Log.info("Pressed Right Arrow Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Right Arrow Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressRightArrowUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_RIGHT);
	 * ROBOT.keyRelease(KeyEvent.VK_RIGHT); Log.info("Pressed Right Arrow Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Right Arrow Key Multiple times
	 * 
	 * @param numberOfTimes
	 * @throws InterruptedException
	 */
	public static void keyPressRightArrowMultipleTimes(int numberOfTimes) throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		for (int i = 0; i < numberOfTimes; i++) {
			keyPressRightArrow();
		}
		Log.info("Pressed Right Arrow Key " + numberOfTimes + " times");
		// Thread.sleep(1000);
	}

	/**
	 * Press Right Arrow Key Multiple times Using Robot Class
	 * 
	 * @param numberOfTimes
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressRightArrowMultipleTimesUsingRobotClass(int numberOfTimes)
	 * throws InterruptedException{ waitForPageToLoad(); //Thread.sleep(1000);
	 * for(int i=0;i<numberOfTimes;i++) { ROBOT.keyPress(KeyEvent.VK_RIGHT);
	 * ROBOT.keyRelease(KeyEvent.VK_RIGHT); Thread.sleep(100); }
	 * 
	 * Log.info("Pressed Right Arrow Key " + numberOfTimes + " times");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Up Arrow Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressUpArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.UP).build().perform();
		Log.info("Pressed Up Arrow Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Up Arrow Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressUpArrowUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_UP);
	 * ROBOT.keyRelease(KeyEvent.VK_UP); Log.info("Pressed Up Arrow Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Down Arrow Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressDownArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.DOWN).build().perform();
		Log.info("Pressed Down Arrow Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Down Arrow Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressDownArrowUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_DOWN);
	 * ROBOT.keyRelease(KeyEvent.VK_DOWN); Log.info("Pressed Down Arrow Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Home Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressHome() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.HOME).build().perform();
		Log.info("Pressed Home Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Home Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressHomeUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_HOME);
	 * ROBOT.keyRelease(KeyEvent.VK_HOME); Log.info("Pressed Home Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press BackSpace Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressBackspace() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.BACK_SPACE).build().perform();
		Log.info("Pressed Backspace Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press BackSpace Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressBackspaceUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_BACK_SPACE);
	 * ROBOT.keyRelease(KeyEvent.VK_BACK_SPACE); Log.info("Pressed Backspace Key");
	 * }
	 */

	/**
	 * Press End Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressEnd() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.END).build().perform();
		Log.info("Pressed End Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press End Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressEndUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_END);
	 * ROBOT.keyRelease(KeyEvent.VK_END); Log.info("Pressed End Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press Esc Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressEsc() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.ESCAPE).build().perform();
		Log.info("Pressed Esc Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Esc Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressEscUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_ESCAPE); ROBOT.keyRelease(KeyEvent.VK_ESCAPE);
	 * Log.info("Pressed Esc Key"); Thread.sleep(1000); }
	 */

	/**
	 * Press Enter Key
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressEnter() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.sendKeys(Keys.ENTER).build().perform();
		Log.info("Pressed Enter Key");
		// Thread.sleep(1000);
	}

	/**
	 * Press Enter Key Using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressEnterUsingRobotClass() throws InterruptedException{
	 * waitForPageToLoad(); //Thread.sleep(1000); ROBOT.keyPress(KeyEvent.VK_ENTER);
	 * ROBOT.keyRelease(KeyEvent.VK_ENTER); Log.info("Pressed Enter Key");
	 * Thread.sleep(1000); }
	 */

	/**
	 * Press ALT + Down Arrow Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	public static void keyPressALTPlusDownArrow() throws InterruptedException {
		waitForPageToLoad();
		// Thread.sleep(1000);
		ACTION.keyDown(Keys.ALT).sendKeys(Keys.DOWN).keyUp(Keys.ALT).build().perform();
		Log.info("Pressed ALT + Down Arrow key");
		// Thread.sleep(1000);
	}

	/**
	 * Press ALT + Down Arrow Key using Robot Class
	 * 
	 * @throws InterruptedException
	 */
	/*
	 * public static void keyPressALTPlusDownArrowUsingRobotClass() throws
	 * InterruptedException { waitForPageToLoad(); //Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_ALT); Thread.sleep(1000);
	 * ROBOT.keyPress(KeyEvent.VK_DOWN); ROBOT.keyRelease(KeyEvent.VK_ALT);
	 * ROBOT.keyRelease(KeyEvent.VK_DOWN); Log.info("Pressed ALT + Down Arrow key");
	 * Thread.sleep(1000); }
	 */

}