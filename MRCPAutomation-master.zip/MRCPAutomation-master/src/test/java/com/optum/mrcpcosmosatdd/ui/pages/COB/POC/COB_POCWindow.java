package com.optum.mrcpcosmosatdd.ui.pages.COB.POC;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.aventstack.extentreports.model.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;



public class COB_POCWindow extends BasePage {

	public static NgWebDriver ngDriver;
	private By windowRootEle = By.id("cobCarrier");
	private By labels = By.xpath(".//*[@id='cobCarrier']//label");
	private By Primary = By.xpath("(.//*[@id='cobCarrier']//table)[2]//tbody//tr[1]/td[1]/select");
	private By type = By.xpath("(.//*[@id='cobCarrier']//table)[2]//tbody//tr[1]/td[2]/select");
	private By table_Header = By.xpath("(.//table)[1]//tr//th");



	public By getWindowRoot() {
		return windowRootEle;
	}

	public boolean underlinedHeaderValidation(List<WebElement> ele)
	{
		try
		{
			for(WebElement e:ele)
			{
				Assert.assertTrue(e.getCssValue("font-weight").equals("400"), "Failed:"+" "+e.getText()+" "+ "Header font weight does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font weight follows the UI standard");
				Assert.assertTrue(e.getCssValue("font-size").equals("10px"), "Failed:"+" "+e.getText()+" "+ "Header font Size does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font size follows the UI standard");
				Assert.assertTrue(e.getCssValue("font-family").equals("verdana"), "Failed:"+" "+e.getText()+" "+ "Header font family does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font family follows the UI standard");
				Assert.assertTrue(e.getCssValue("text-decoration-line").equals("underline"), "Failed:"+" "+e.getText()+" "+ "Header font Decoration does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font decoration follows the UI standard");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean pageTitle(String pageTitle) throws InterruptedException
	{
		try
		{
			System.out.println("Actual Page title:"+" "+ driver.getTitle());
			System.out.println("Expected Page title:"+" "+ pageTitle);
			Assert.assertTrue(driver.getTitle().equals(pageTitle), "failed:Page title not matching");
			com.optum.mrcpcosmosatdd.reporting.Log.info("Verified:page title is matching");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			com.optum.mrcpcosmosatdd.reporting.Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}

	public boolean verifyUIElements() throws InterruptedException
	{
		try
		{
			int count=0;
			//Verify the labels
			List<WebElement> list_ele_Label = new ArrayList();
			list_ele_Label.addAll(driver.findElements(labels));
			//Storing all the labels in an Array
			String[] exp_Labels = {"Member:","Site:","Audit Nbr:","DOB:","Gender:","Active Edits","Edit History"};
			//converting Array to List
			List expListLabels = Arrays.asList(exp_Labels);
			for(int i=0;i<list_ele_Label.size();i++)
			{
				Assert.assertTrue(list_ele_Label.get(i).getText().equals(expListLabels.get(i)), "Failed:Actual label is"+" "+list_ele_Label.get(i).getText()+ " "+"And"+" "+ "Expected label is:"+ " "+ expListLabels.get(i));
				count++;
			}
			if(count==list_ele_Label.size())
			{ 
				com.optum.mrcpcosmosatdd.reporting.Log.info("Verified:All Labels are matching");
			}
			else
			{
				com.optum.mrcpcosmosatdd.reporting.Log.error("Failed:Labels are not matching");
				return false;
			}

			//Verify the 'Primary' drop down values
			/*Select select_Primary = new Select(driver.findElement(Primary));
			List<WebElement> ele_Actual_Dropdown = select_Primary.getOptions();
			List<String> actual_Dropdown_Values = new ArrayList();
			for(WebElement e:ele_Actual_Dropdown)
			{
				actual_Dropdown_Values.add(e.getText());
			}
			System.out.println("Primary dropdown actual list values:"+ " "+ actual_Dropdown_Values);
			//Expected dropdown values
			List<String> exp_Values = new ArrayList();
			String[] expValues = {"Primary","Secondary","Tertiary","Recovery"};
			exp_Values.addAll(Arrays.asList(expValues));
			if(actual_Dropdown_Values.equals(exp_Values)){
				com.optum.mrcpcosmosatdd.reporting.Log.info("Verified: Primacy dropdown  values are matching");
			}
			else {
				com.optum.mrcpcosmosatdd.reporting.Log.info("Failed: Primacy dropdown values are not matching");
				return false;
			}

			//Verify the Type drop down values
			Select select_Type = new Select(driver.findElement(type));
			List<WebElement> ele_Actual_Dropdown_Type = select_Type.getOptions();
			List<String> actual_Dropdown_Values_Type = new ArrayList();
			for(WebElement e:ele_Actual_Dropdown_Type)
			{
				actual_Dropdown_Values_Type.add(e.getText());
			}
			System.out.println("Type dropdown actual list values:"+ " "+ actual_Dropdown_Values_Type);
			//Expected Type dropdown values
			List<String> exp_Values_Type = new ArrayList();
			String[] expValues_Type = {"Commercial","Medicare","Medicaid","MVA","Third Party","WC"};
			exp_Values_Type.addAll(Arrays.asList(expValues_Type));
			if(actual_Dropdown_Values_Type.equals(exp_Values_Type)){
				com.optum.mrcpcosmosatdd.reporting.Log.info("Verified:Type dropdown values are matching");
			}
			else {
				com.optum.mrcpcosmosatdd.reporting.Log.info("Failed: Type dropdown values are not matching");
				return false;
			}
*/
			//Verify column header follow the UI standards
			List<WebElement> webEle_Headers = driver.findElements(table_Header);
			this.underlinedHeaderValidation(webEle_Headers);
			

		}
		catch(Exception e)
		{
			e.printStackTrace();
			com.optum.mrcpcosmosatdd.reporting.Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}




}
