package com.optum.mrcpcosmosatdd.ui.pages;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.helpers.MRCPDriverFactory;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.utilities.GeneralFunctions;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
//import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public abstract class BasePage extends MRCPDriverFactory {

	public static final int TIMEOUT = 300;

	public static WebElement windowRootWebElement;

	protected By image_Optum = By.id("CPAHomeLogo");
	private By label_WindowTitle = By.className("lwd-window-title");
	private By button_MinimizeWindow = By.xpath("//span[@class='ui-button-icon-primary ui-icon ui-icon-minimizethick']");
	private By button_MaximizeWindow = By.xpath("//span[@class='ui-button-icon-primary ui-icon ui-icon-maximizethick']");
	private By button_RestoreWindow = By.xpath("//span[@class='ui-button-icon-primary ui-icon ui-icon-restorethick']");
	private By button_CloseWindow = By.xpath("//span[@class='ui-button-icon ui-icon ui-icon-closethick']");
	//private By button_Window = By.xpath(".//div[@id='lwd-taskbar-button-container']//span[contains(text(),'WINDOWNAME')]//ancestor::button");
	private By button_ResizeIcon = By.xpath("//div[@class='ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se']");

	private By icon_Loading = By.id("menuScreensLoading");

	/**
	 * @return
	 */
	public By getWindowRoot() {
		throw new RuntimeException("Implement the getWindowRoot");
	}

	/**
	 * Return WebElement of the window/page
	 * 
	 * @return
	 */
	public WebElement rootEle() {
		//if (windowRootWebElement == null)
		//windowRootWebElement = driver.findElement(this.getWindowRoot());
		return driver.findElement(this.getWindowRoot());
	}

	/**
	 * Store the Start Time
	 * 
	 */
	public void storeStartTime() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
		//Check Login Time
		Constants.STARTTIME = LocalDateTime.parse(GeneralFunctions.gettimeStamp(), formatter);
	}

	/**
	 * Store the End Time
	 * 
	 */
	public void storeEndTime() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
		//Check Login Time
		Constants.ENDTIME = LocalDateTime.parse(GeneralFunctions.gettimeStamp(), formatter);
	}

	/**
	 * Calculate the time difference for Performance Testing
	 * 
	 * @return
	 */
	public long calculateTime() {
		if(Constants.STARTTIME.equals("") || Constants.ENDTIME.equals("") || Constants.STARTTIME.equals(null) || Constants.ENDTIME.equals(null)) {
			Log.error("Please check the Start/End Time as it is null");
			return 0;
		}
		else if(Constants.ENDTIME.isBefore(Constants.STARTTIME)) {
			Log.error("Please check the Start/End Time as Start Time is greater than End Time");
			return 0;
		}
		else{
			Log.info("Time taken(in milli sec):- " + java.time.Duration.between(Constants.STARTTIME, Constants.ENDTIME).toMillis());
			return java.time.Duration.between(Constants.STARTTIME, Constants.ENDTIME).toMillis();
		}
	}

	/**
	 * Wait until Loading gif is displayed
	 * 
	 * @throws InterruptedException
	 */
	public void waitUntilLoadingIconDisplay() throws InterruptedException{
		waitForPageToLoad();
		do{
			Thread.sleep(500);
		}while(driver.findElement(icon_Loading).isDisplayed());

		storeEndTime();
	}

	/**
	 * It will wait or hold for given seconds
	 * 
	 * @throws InterruptedException
	 */
	public void waitTimer(int seconds) throws InterruptedException {
		Thread.sleep(seconds*1000);
	}

	/**
	 * It will wait or hold until the page loads
	 * 
	 * @throws InterruptedException
	 */
	public static void waitForPageToLoad() throws InterruptedException {
		do {
			Thread.sleep(1000);
		}while(!JAVASCRIPTEXECUTOR.executeScript("return document.readyState").equals("complete"));
	}

	/**
	 * Get Window Title
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public String getWindowTitle() throws InterruptedException{
		waitForPageToLoad();
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_WindowTitle));
		return rootEle().findElement(label_WindowTitle).getText();
	}
	
	public void visibilityOfElementLocated(By locator) throws InterruptedException{
		waitForPageToLoad();
		MAXDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(locator));
		
	}

	/**
	 * Maximize the page in CPA
	 * 
	 * @throws InterruptedException
	 */
	public void maximize() throws InterruptedException {
		waitForPageToLoad();
		rootEle().findElement(button_MaximizeWindow).click();
		Log.info("Window Maximized");
	}

	/**
	 * Restore the page in CPA
	 * 
	 * @throws InterruptedException 
	 *
	 */
	public void restore() throws InterruptedException {
		waitForPageToLoad();
		rootEle().findElement(button_RestoreWindow).click();
		Log.info("Window Restored");
	}

	/**
	 * Minimize the page in CPA
	 * 
	 * @throws InterruptedException 
	 *
	 */
	public void minimize() throws InterruptedException {
		waitForPageToLoad();
		rootEle().findElement(button_MinimizeWindow).click();
		Log.info("Window Minimized");
	}

	/**
	 * Close the page on CPA
	 * 
	 * @throws InterruptedException 
	 *
	 */
	public void close() throws InterruptedException {
		waitForPageToLoad();
		rootEle().findElement(button_CloseWindow).click();
		Log.info("Window Closed");
	}

	/**
	 * Perform window operation like Maximize, Minimize, Restore or Close
	 * 
	 * @param operationName
	 * @return
	 * @throws InterruptedException
	 */
	public boolean windowOperation(String operationName) throws InterruptedException{
		waitForPageToLoad();

		if(operationName.equalsIgnoreCase("Maximize")) {
			try{
				if(rootEle().findElement(button_MaximizeWindow).isDisplayed()) {
					rootEle().findElement(button_MaximizeWindow).click();
					Log.info("Window maximized");
					return true;
				}
			}
			catch(NoSuchElementException e) {
				if(rootEle().findElement(button_RestoreWindow).isDisplayed()) {
					rootEle().findElement(button_RestoreWindow).click();
					waitForPageToLoad();
					if(rootEle().findElement(button_MaximizeWindow).isDisplayed()) {
						rootEle().findElement(button_MaximizeWindow).click();
						Log.info("Window maximized");
						return true;
					}
					else {
						Log.error("Window not maximized");
						return false;
					}
				}
			}
			catch(Exception e) {
				Log.error("Window not maximized");
				return false;
			}
		}
		else if(operationName.equalsIgnoreCase("Close")) {
			if(rootEle().findElement(button_CloseWindow).isDisplayed()) {
				rootEle().findElement(button_CloseWindow).click();
				waitForPageToLoad();
				Log.info("Window Closed");
				return true;
			}
			else{
				Log.error("Window not Closed");
				return false;
			}
		}
		else if(operationName.equalsIgnoreCase("Minimize")) {
			if(rootEle().findElement(button_MinimizeWindow).isDisplayed()) {
				rootEle().findElement(button_MinimizeWindow).click();
				Log.info("Window Minimized");
				return true;
			}
			else{
				Log.error("Window not Minimized");
				return false;
			}
		}else if(operationName.equalsIgnoreCase("Restore")) {
			try{
				if(rootEle().findElement(button_RestoreWindow).isDisplayed()) {
					rootEle().findElement(button_RestoreWindow).click();
					Log.info("Window Restored");
					return true;
				}
			}
			catch(NoSuchElementException e) {
				if(rootEle().findElement(button_MaximizeWindow).isDisplayed()) {
					rootEle().findElement(button_MaximizeWindow).click();
					waitForPageToLoad();
					if(rootEle().findElement(button_RestoreWindow).isDisplayed()) {
						rootEle().findElement(button_RestoreWindow).click();
						Log.info("Window Restored");
						return true;
					}
					else {
						Log.error("Window not Restored");
						return false;
					}
				}
			}
			catch(Exception e) {
				Log.error("Window not Restored");
				return false;
			}
		}
		Log.error("Window operation not performed");
		return false;
	}

	/**
	 * Populate the Input Field
	 * 
	 * @param ele
	 * @param text
	 */
	public void winPopulateTextBox(By ele, String text) {
		WebElement webElement = rootEle();
		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfNestedElementLocatedBy(webElement, ele));
		webElement.sendKeys(text);
	}

	/**
	 * Enter Text in Input field
	 * 
	 * @param selector
	 * @param text
	 */
	public void enterText(By selector, String text) {
		WebElement element = MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(rootEle().findElement(selector)));
		element.clear();
		element.sendKeys(text);
	}

	/**
	 * Enter text in a Input Field
	 * 
	 * @param webElement
	 * @param text
	 */
	public void enterText(WebElement webElement, String text) {
		WebElement element = MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		element.clear();
		element.sendKeys(text);
	}

	/**
	 * Select value from drop down
	 * 
	 * @param selector
	 * @param text
	 * @throws InterruptedException 
	 */
	public void selectDropDownBoxValue(By selector, String text) throws InterruptedException {
		//MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(rootEle().findElement(selector)));
		waitForPageToLoad();

		Select select = new Select(rootEle().findElement(selector));
		select.selectByVisibleText(text);
	}

	/**
	 * Select value from drop down
	 * 
	 * @param webElement
	 * @param text
	 * @throws InterruptedException 
	 */
	public void selectDropDownBoxValue(WebElement webElement, String text) throws InterruptedException {
		//MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		waitForPageToLoad();

		Select select = new Select(webElement);
		select.selectByVisibleText(text);
	}

	/**
	 * Select value from drop down
	 * 
	 * @param selector
	 * @param index
	 * @throws InterruptedException 
	 */
	public void selectDropDownBoxValue(By selector, int index) throws InterruptedException {
		//MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));
		waitForPageToLoad();

		Select select = new Select(rootEle().findElement(selector));
		select.selectByIndex(index);
	}

	/**
	 * Select value from drop down
	 * 
	 * @param webElement
	 * @param index
	 * @throws InterruptedException 
	 */
	public void selectDropDownBoxValue(WebElement webElement, int index) throws InterruptedException {
		//MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		waitForPageToLoad();

		Select select = new Select(webElement);
		select.selectByIndex(index);
	}

	/**
	 * Select value from Select Picker
	 * 
	 * @param selector
	 * @param option
	 * @return
	 * @throws InterruptedException
	 */
	public boolean selectPickerValue(By selector, String option) throws InterruptedException {
		waitForPageToLoad();

		new Select(rootEle().findElement(selector)).selectByVisibleText(option);
		if(!getText(new Select(rootEle().findElement(selector)).getFirstSelectedOption()).equalsIgnoreCase(option)) {
			Log.error(option + " value is not selected in drop down");
			return false;
		}

		Log.info("Selected " + option + " value in drop down");
		return true;
	}

	/**
	 * Select value from Select Picker
	 * 
	 * @param webElement
	 * @param option
	 * @return
	 * @throws InterruptedException
	 */
	public boolean selectPickerValue(WebElement webElement, String option) throws InterruptedException {
		waitForPageToLoad();

		new Select(webElement).selectByVisibleText(option);
		if(!getText(new Select(webElement).getFirstSelectedOption()).equalsIgnoreCase(option)) {
			Log.error(option + " value is not selected in drop down");
			return false;
		}

		Log.info("Selected " + option + " value in drop down");
		return true;
	}

	/**
	 * Select value from Select Picker
	 * 
	 * @param selectElement
	 * @param option
	 * @return
	 * @throws InterruptedException
	 */
	public boolean selectPickerValue(Select selectElement, String option) throws InterruptedException {
		waitForPageToLoad();

		selectElement.selectByVisibleText(option);
		if(!getText(selectElement.getFirstSelectedOption()).equalsIgnoreCase(option)) {
			Log.error(option + " value is not selected in drop down");
			return false;
		}

		Log.info("Selected " + option + " value in drop down");
		return true;
	}

	/**
	 * Select value from Select Picker using mouse click
	 * 
	 * @param button
	 * @param list
	 * @param option
	 * @return
	 * @throws InterruptedException
	 */
	public boolean selectPickerValueByClick(By button, By list, String option) throws InterruptedException {
		waitForPageToLoad();

		WebElement optionElement = rootEle().findElement(list).findElement(By.xpath(".//span[@class='text' and contains(text(),'"+ option +"')]"));
		//Click on Select picker button
		mouseClick(button);
		//Mouse over and click on option
		mouseClick(optionElement);
		waitForPageToLoad();

		//Validate highlighted option
		mouseClick(button);
		if(!validateHighlightedOption(list, option)) {
			Log.error(option + " value is not selected in drop down");
			return false;
		}

		Log.info("Selected " + option + " value in drop down");
		return true;
	}

	/**
	 * Select value from Select Picker using mouse click
	 * 
	 * @param button
	 * @param list
	 * @param option
	 * @return
	 * @throws InterruptedException
	 */
	public boolean selectPickerValueByClick(WebElement button, WebElement list, String option) throws InterruptedException {
		waitForPageToLoad();

		WebElement optionElement = list.findElement(By.xpath(".//span[@class='text' and contains(text(),'"+ option +"')]"));

		//Click on Select picker button
		mouseClick(button);
		//Mouse over and click on option
		mouseClick(optionElement);
		waitForPageToLoad();

		//Validate highlighted option
		mouseClick(button);
		if(!validateHighlightedOption(list, option)) {
			Log.error(option + " value is not selected in drop down");
			return false;
		}

		Log.info("Selected " + option + " value in drop down");
		return true;
	}

	/**
	 * Get the Selected value of Dropdown
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getSelectedValueOfDropdown(By selector) throws InterruptedException {
		waitForPageToLoad();

		Select select = new Select(rootEle().findElement(selector));
		return select.getFirstSelectedOption().getText();
	}

	/**
	 * Get the Selected value of Dropdown
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getSelectedValueOfDropdown(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		Select select = new Select(webElement);
		return select.getFirstSelectedOption().getText();
	}

	/**
	 * Validate the selected option in dropdown
	 * 
	 * @param selector
	 * @param text
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateOptionSelectedOfDropdown(By selector, String text) throws InterruptedException {
		waitForPageToLoad();

		Select select = new Select(rootEle().findElement(selector));

		if(select.getFirstSelectedOption().getText().equalsIgnoreCase(text)) {
			Log.info(text + " option is selected in dropdown");
			return true;
		}
		else {
			Log.error(text + " option is not selected in dropdown. Selected value on UI is "+select.getFirstSelectedOption().getText());
			return false;
		}
	}

	/**
	 * Validate the selected option in dropdown
	 * 
	 * @param webElement
	 * @param text
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateOptionSelectedOfDropdown(WebElement webElement, String text) throws InterruptedException {
		waitForPageToLoad();

		Select select = new Select(webElement);

		if(select.getFirstSelectedOption().getText().equalsIgnoreCase(text)) {
			Log.info(text + " option is selected in dropdown");
			return true;
		}
		else {
			Log.error(text + " option is not selected in dropdown. Selected value on UI is "+select.getFirstSelectedOption().getText());
			return false;
		}
	}

	/**
	 * Validate the all options available in Drop down
	 * 
	 * @param selector
	 * @param exp_Values
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateAllValuesOfDropdown(By selector, List<String> expectedOptions) throws InterruptedException {
		waitForPageToLoad();

		Select dropdown = new Select(rootEle().findElement(selector));
		List<String> dropdown_Act_Values = new ArrayList<String>();
		for(WebElement element:dropdown.getOptions())
			dropdown_Act_Values.add(element.getText().trim());

		System.out.println("Actual values:"+" "+dropdown_Act_Values);
		System.out.println("Exp values:"+" "+expectedOptions);
		if(dropdown_Act_Values.equals(expectedOptions)) {
			Log.info("All Drop down values are matched");
			return true;
		}
		else {
			Log.info("All Drop down values are not matched");
			return false;
		}
	}

	/**
	 * Validate the all options available in Drop down
	 * 
	 * @param webElement
	 * @param expectedOptions
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateAllValuesOfDropdown(WebElement webElement, List<String> expectedOptions) throws InterruptedException {
		waitForPageToLoad();

		Select dropdown = new Select(webElement);
		List<String> dropdown_Act_Values = new ArrayList<String>();
		for(WebElement element:dropdown.getOptions())
			dropdown_Act_Values.add(element.getText());

		if(dropdown_Act_Values.equals(expectedOptions)) {
			Log.info("All Drop down values are matched");
			return true;
		}
		else {
			Log.info("All Drop down values are not matched");
			return false;
		}
	}

	/**
	 * Perform CHECK or UNCHECK operation on any Check Box
	 * 
	 * @param selector
	 * @param operation
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean operateOnCheckBox(By selector, String operation) throws InterruptedException {
		waitForPageToLoad();

		WebElement webElement =  rootEle().findElement(selector);
		switch(operation.toUpperCase()) {
		case "CHECK":
			if(!webElement.isSelected())
				webElement.click();
			break;
		case "UNCHECK":
			if(webElement.isSelected())
				webElement.click();
			break;
		default:
			System.out.println("Please provide valid operation");
		}

		//Verify
		waitForPageToLoad();

		if(webElement.isSelected() && operation.equalsIgnoreCase("CHECK"))
			return true;
		else if(!webElement.isSelected() && operation.equalsIgnoreCase("UNCHECK"))
			return true;
		else
			return false;
	}


	/**
	 * Perform CHECK or UNCHECK operation on any Check Box
	 * 
	 * @param webElement
	 * @param operation
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean operateOnCheckBox(WebElement webElement, String operation) throws InterruptedException {
		waitForPageToLoad();

		switch(operation.toUpperCase()) {
		case "CHECK":
			if(!webElement.isSelected())
				webElement.click();
			break;
		case "UNCHECK":
			if(webElement.isSelected())
				webElement.click();
			break;
		default:
			System.out.println("Please provide valid operation");
		}
		//Verify
		waitForPageToLoad();

		if(webElement.isSelected() && operation.equalsIgnoreCase("CHECK"))
			return true;
		else if(!webElement.isSelected() && operation.equalsIgnoreCase("UNCHECK"))
			return true;
		else
			return false;
	}

	/**
	 * Select the Radio button
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean selectRadioButton(By selector) throws InterruptedException {
		waitForPageToLoad();

		WebElement webElement =  rootEle().findElement(selector);
		webElement.click();
		//Verify
		waitForPageToLoad();
		if(webElement.isSelected())
			return true;
		else
			return false;
	}

	/**
	 * Select the Radio button
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean selectRadioButton(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		webElement.click();
		//Verify
		waitForPageToLoad();
		if(webElement.isSelected())
			return true;
		else
			return false;
	}

	/**
	 * To check whether Element is selected or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementSelected(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(rootEle().findElement(selector).isSelected()) {
			Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is selected");
			return true;
		}
		else{
			Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not selected");
			return false;
		}
	}
	
	public boolean isElementSelected(WebElement webelement) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(webelement.isSelected()) {
			Log.info(webelement.findElement(By.xpath("preceding-sibling::span")).getText() + " "+"element is selected");
			return true;
		}
		else{
			Log.error(webelement.findElement(By.xpath("preceding-sibling::span")).getText() + " "+"element is not selected");
			return false;
		}
	}
  
	/**
	 * To check whether Element is selected or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementSelected_Driver(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(driver.findElement(selector).isSelected()) {
			Log.info(driver.findElement(selector).getText() + " web element with selector as " + selector + " is selected");
			return true;
		}
		else{
			Log.error(driver.findElement(selector).getText() + " web element with selector as " + selector + " is not selected");
			return false;
		}
	}

	/**
	 * To check whether Element is displayed or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementDisplayed(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(rootEle().findElement(selector).isDisplayed()) {
			Log.info(rootEle().findElement(selector).getText() + " Web element with selector as " + selector +" is displayed");
			return true;
		}
		else{
			Log.error(rootEle().findElement(selector).getText() + " Web element with selector as " + selector +" is not displayed");
			return false;
		}
	}

	/**
	 * To check whether Element is displayed or not
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementDisplayed(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
		if(webElement.isDisplayed()) {
			Log.info(webElement.getText() + " web element with selector as "+ webElement +" is displayed");
			return true;
		}
		else{
			Log.error(webElement.getText() + " web element with selector as "+ webElement +" is not displayed");
			return false;
		}
	}

	/**
	 * To check whether Element is displayed or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementDisplayed_Driver(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(driver.findElement(selector).isDisplayed()) {
			Log.info(driver.findElement(selector).getText() + " web element with selector as "+ selector +" is displayed");
			return true;
		}
		else{
			Log.error(driver.findElement(selector).getText() + " web element with selector as "+ selector +" is not displayed");
			return false;
		}
	}

	/**
	 * To check whether Element is enabled or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementEnabled(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(rootEle().findElement(selector).isEnabled()) {
			Log.info(rootEle().findElement(selector).getText() + " web element with selector as "+ selector +" is enabled");
			return true;
		}
		else{
			Log.error(rootEle().findElement(selector).getText() + " web element with selector as "+ selector +" is not enabled");
			return false;
		}
	}

	/**
	 * To check whether Element is enabled or not
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementEnabled(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
		if(webElement.isEnabled()) {
			Log.info(webElement.getText() + " web element with selector as "+ webElement +" is enabled");
			return true;
		}
		else{
			Log.error(webElement.getText() + " web element with selector as "+ webElement +" is not enabled");
			return false;
		}
	}

	/**
	 * To check whether Element is enabled or not
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean isElementEnabled_Driver(By selector) throws InterruptedException {
		waitForPageToLoad();

		//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
		if(driver.findElement(selector).isEnabled()) {
			Log.info(driver.findElement(selector).getText() + " web element with selector as "+ selector +" is enabled");
			return true;
		}
		else{
			Log.error(driver.findElement(selector).getText() + " web element with selector as "+ selector +" is not enabled");
			return false;
		}
	}

	/**
	 * Return text of the WebeElement
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */															 				
	public String getText(By selector) throws InterruptedException {
		try {
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			Log.info(rootEle().findElement(selector).getText() + " web element with selector as "+ selector + " is found");
			return rootEle().findElement(selector).getText();
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ selector + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ selector + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Return text of the WebeElement
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */															 				
	public String getText(WebElement webElement) throws InterruptedException {
		try {
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			Log.info(webElement.getText() + " web element with selector as "+ webElement + " is found");
			return webElement.getText();
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ webElement + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ webElement + " is not found");
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * To get the CSS Value of a WebElement
	 * 
	 * @param webElement
	 * @param cssProperty
	 * @return
	 * @throws InterruptedException
	 */
	public String getCssValue(WebElement webElement, String cssProperty) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			Log.info(webElement.getText() + " web element with selector as "+ webElement + " is found");
			return webElement.getCssValue(cssProperty);
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ webElement + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ webElement + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * To get the CSS Value of a WebElement
	 * 
	 * @param selector
	 * @param cssProperty
	 * @return
	 * @throws InterruptedException
	 */
	public String getCssValue(By selector, String cssProperty) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			Log.info(rootEle().findElement(selector).getText() + " web element with selector as "+ selector + " is found");
			return rootEle().findElement(selector).getCssValue(cssProperty);
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ selector + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ selector + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * To get the Attribute value of a WebElement
	 * 
	 * @param selector
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public String getAttributeValue(By selector, String attribute) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			Log.info(rootEle().findElement(selector).getText() + " web element with selector as "+ selector + " is found");
			return rootEle().findElement(selector).getAttribute(attribute);
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ selector + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ selector + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * To get the Attribute value of a WebElement
	 * 
	 * @param webElement
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public String getAttributeValue(WebElement webElement, String attribute) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			Log.info(webElement.getText() + " web element with selector as "+ webElement + " is found");
			return webElement.getAttribute(attribute);
		}
		catch(NoSuchElementException e) {
			Log.error("Web element with selector as "+ webElement + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Web element with selector as "+ webElement + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * To get the value of a WebElement
	 * 
	 * @param selector
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public String getFieldValue(By selector) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is found");
			return rootEle().findElement(selector).getAttribute("value");
		}
		catch(NoSuchElementException e) {
			Log.error("Field with selector as "+ selector + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Field with selector as "+ selector + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * To get the value of a WebElement
	 * 
	 * @param webElement
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public String getFieldValue(WebElement webElement) throws InterruptedException {
		try{
			//waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement + " is found");
			return webElement.getAttribute("value");
		}
		catch(NoSuchElementException e) {
			Log.error("Field with selector as "+ webElement + " is not found in DOM");
			return null;
		}
		catch(Exception e) {
			Log.error("Field with selector as "+ webElement + " is not found");
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Return Text Alignment
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getTextAlignment(By selector) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("text-align");
			}	
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Field with selector as "+ selector + "is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Text Alignment
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getTextAlignment(WebElement webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement + " is displayed");
				return webElement.getCssValue("text-align");
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Field with selector as "+ webElement + " is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Cursor Style
	 * 
	 * @param selector
	 * @return
	 */
	public String getCursorStyle(By selector){
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(rootEle().findElement(selector)));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as "+ selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("cursor");
			}
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as "+ selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Web element with selector as "+ selector + " is not present in DOM");
			return null;
		}

	}

	/**
	 * Return Cursor Style
	 * 
	 * @param webElement
	 * @return
	 */
	public String getCursorStyle(WebElement webElement){
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as "+ webElement + " is displayed");
				return webElement.getCssValue("cursor");
			}
			else {
				Log.error(webElement.getText() + " web element with selector as "+ webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Web element with selector as "+ webElement + " is not present in DOM");
			return null;
		}
	}



	/**
	 * Return Font Size
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontSize(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("font-size");
			}
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Size
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontSize(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("font-size");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Weight
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontWeight(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("font-weight");
			}
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Weight
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontWeight(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("font-weight");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Type
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontType(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("font-family");
			}
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Type
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontType(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("font-family");
			}
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Color
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontColor(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("color");
			}	
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Color
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontColor(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("color");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Decoration Line
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationLine(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("text-decoration-line");
			}	
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Font Decoration Line
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationLine(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("text-decoration-line");
				//return webElement.getCssValue("text-decoration");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Text Decoration Style
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationStyle(By selector) throws InterruptedException {
		try{
			WebElement webElement = rootEle().findElement(selector);
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("text-decoration-style");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Text Decoration Style
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationStyle(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("text-decoration-style");
			}
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Text Decoration Color
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationColor(By selector) throws InterruptedException {
		try{
			WebElement webElement = rootEle().findElement(selector);
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("text-decoration-color");
			}
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Text Decoration Color
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getFontDecorationColor(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("text-decoration-color");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Background color
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getBackgroundColor(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				Log.info(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return rootEle().findElement(selector).getCssValue("background-color");
			}	
			else {
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Background color
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public String getBackgroundColor(WebElement webElement) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				Log.info(webElement.getText() + " web element with selector as " + webElement + " is displayed");
				return webElement.getCssValue("background-color");
			}	
			else {
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Return Background color
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public String getBackgroundColor_Driver(By selector) throws InterruptedException {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(driver.findElement(selector).isDisplayed()) {
				Log.info(driver.findElement(selector).getText() + " web element with selector as " + selector + " is displayed");
				return driver.findElement(selector).getCssValue("background-color");
			}	
			else {
				Log.error(driver.findElement(selector).getText() + " web element with selector as " + selector + " is not displayed");
				return null;
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector + " web element is not present in DOM");
			return null;
		}
	}

	/**
	 * Mouse Hover and Click on Webelement
	 * 
	 * @param selector
	 * @return 
	 * @throws InterruptedException
	 */
	public void mouseClick(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (rootEle().findElement(selector).isDisplayed()) {
				ACTION.moveToElement(rootEle().findElement(selector)).click().build().perform();
				Log.info("Mouse hovered and clicked on WebElement: " + selector);
			} else
				Log.error("WebElement: " + selector + "not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}
	}

	/**
	 * Mouse Hover and Click on Web element
	 * 
	 * @param webElement
	 * @throws InterruptedException
	 */
	public void mouseClick(WebElement webElement) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if (webElement.isDisplayed()) {
				ACTION.moveToElement(webElement).click().build().perform();
				Log.info("Mouse hovered and clicked on WebElement: " + webElement.getText());
			} else
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}
	}

	/**
	 * Mouse Hover and Click on Webelement
	 * 
	 * @param selector
	 * @throws InterruptedException
	 */
	public void mouseClick_Driver(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (driver.findElement(selector).isDisplayed()) {
				ACTION.moveToElement(driver.findElement(selector)).click().build().perform();
				Log.info("Mouse hovered and clicked on WebElement: " + selector);
			} else
				Log.error("WebElement: " + selector + "not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}
	}

	/**
	 * Perform MouseHover
	 * 
	 * @param selector
	 * @throws InterruptedException
	 */
	public void mouseHover(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (rootEle().findElement(selector).isDisplayed()) {
				ACTION.moveToElement(rootEle().findElement(selector)).build().perform();
				Log.info("Mouse hovered on WebElement: " + rootEle().findElement(selector).getText());
			} else
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector
						+ " is not displayed");
		} catch (NoSuchElementException e) {
			Log.error("Web element with selector as " + selector + " is not present in DOM");
		}
	}

	/**
	 * Perform MouseHover
	 * 
	 * @param webElement
	 * @throws InterruptedException
	 */
	public void mouseHover(WebElement webElement) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if (webElement.isDisplayed()) {
				ACTION.moveToElement(webElement).build().perform();
				Log.info("Mouse hovered on WebElement: " + webElement.getText());
			} else
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
		} catch (NoSuchElementException e) {
			Log.error(webElement.getText() + " web element with selector as " + webElement + " is not present in DOM");
		}
	}

	/**
	 * Perform MouseHover
	 * 
	 * @param selector
	 * @throws InterruptedException
	 */
	public void mouseHover_Driver(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (driver.findElement(selector).isDisplayed()) {
				ACTION.moveToElement(driver.findElement(selector)).build().perform();
				Log.info("Mouse hovered on WebElement: " + driver.findElement(selector).getText());
			} else
				Log.error(driver.findElement(selector).getText() + " web element with selector as " + selector
						+ " is not displayed");
		} catch (NoSuchElementException e) {
			Log.error("Web element with selector as " + selector + " is not present in DOM");
		}
	}

	/**
	 * Perform MouseHover Away from the Working area
	 * 
	 * @throws InterruptedException
	 */
	public void mouseHoverAway() throws InterruptedException {
		WebElement webElement = null;
		try {
			webElement = driver.findElement(image_Optum);
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if (webElement.isDisplayed()) {
				ACTION.moveToElement(webElement).build().perform();
				Log.info("Mouse hovered on WebElement: " + webElement.getText());
			} else
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
		} catch (NoSuchElementException e) {
			Log.error(webElement.getText() + " web element with selector as " + webElement + " is not present in DOM");
		}
	}

	/**
	 * Mouse Hover and Click on Web element
	 * 
	 * @param selector
	 * @throws InterruptedException
	 */
	public void mouseDoubleClick(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (rootEle().findElement(selector).isDisplayed()) {
				ACTION.moveToElement(rootEle().findElement(selector)).doubleClick().build().perform();
				Log.info(
						"Mouse hovered and Double clicked on WebElement: " + rootEle().findElement(selector).getText());
			} else
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector
						+ " is not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}

	}

	/**
	 * Mouse Hover and Click on Web element
	 * 
	 * @param webElement
	 * @throws InterruptedException
	 */
	public void mouseDoubleClick(WebElement webElement) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if (webElement.isDisplayed()) {
				ACTION.moveToElement(webElement).doubleClick().build().perform();
				Log.info("Mouse hovered and Double clicked on WebElement: " + webElement.getText());
			} else
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}
	}

	/**
	 * Mouse Hover and Right Click on Selector
	 * 
	 * @param selector
	 * @throws InterruptedException
	 */
	public void mouseRightClick(By selector) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if (rootEle().findElement(selector).isDisplayed()) {
				ACTION.moveToElement(rootEle().findElement(selector)).contextClick().build().perform();
				Log.info(
						"Mouse hovered and Right clicked on WebElement: " + rootEle().findElement(selector).getText());
			} else
				Log.error(rootEle().findElement(selector).getText() + " web element with selector as " + selector
						+ " is not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}

	}

	/**
	 * Mouse Hover and Right Click on Web element
	 * 
	 * @param webElement
	 * @throws InterruptedException
	 */
	public void mouseRightClick(WebElement webElement) throws InterruptedException {
		try {
			// windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if (webElement.isDisplayed()) {
				ACTION.moveToElement(webElement).contextClick().build().perform();
				Log.info("Mouse hovered and Right clicked on WebElement: " + webElement.getText());
			} else
				Log.error(webElement.getText() + " web element with selector as " + webElement + " is not found");
		} catch (NoSuchElementException e) {
			Log.error("Element is not present in DOM");
		}
	}

	/**
	 * Verify that all the Command buttons has font as bolded on a page
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifyCommandButtonsFontWeight() throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> buttonsList = rootEle().findElements(By.xpath(".//button[@class='custBtn']"));
		for (int i=0;i<buttonsList.size();i++) {
			if (!(buttonsList.get(i).getCssValue("font-weight").equalsIgnoreCase("bold"))) {
				Log.error(buttonsList.get(i).getText() + " button font is not bold");
				return false;
			}
		}

		Log.info("All the buttons font weight are validated");
		return true;
	}

	/**
	 * Verify that F3F4 is present
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean verifyF3F4Present() throws InterruptedException {
		waitForPageToLoad();

		try {
			if(rootEle().findElement(By.xpath(".//textarea[contains(text(),'F3F4')]")).isDisplayed()) {
				if(rootEle().findElement(By.xpath(".//textarea[contains(text(),'F3F4')]")).getCssValue("border-style").equalsIgnoreCase("groove")) {
					Log.info("Border is available around F3 F4");
					return true;
				}
				else {
					Log.error("Border is not available around F3 F4");
					return false;
				}
			}
			else {
				Log.info(" F3F4 web element is available");
				return false;
			}
		}
		catch(NoSuchElementException e){
			Log.error("F3F4 web element is not present in DOM");
			return false;
		}	
	}

	/**
	 * Verify that Command Button is enabled
	 * 
	 * @param buttonName
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateButtonEnabled(String buttonName) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> buttonList = rootEle().findElements(By.xpath("//button"));
		for(WebElement webElement:buttonList) {
			if(webElement.getText().trim().equalsIgnoreCase(buttonName)) {
				if(isElementEnabled(webElement)) {
					Log.info(buttonName+" button is enabled");
					return true;
				}
				else {
					Log.error(buttonName+" button is not enabled");
					return false;
				}
			}
		}
		Log.error("Button with "+buttonName+" is not found");
		return false;
	}

	/**
	 * Verify that Command Button is enabled
	 * 
	 * @param selector
	 * @return
	 */
	public boolean verifyButtonEnabled(By selector) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					Log.info(rootEle().findElement(selector).getText() + " Button is enabled");
					return true;
				}
				else{
					Log.error(rootEle().findElement(selector).getText() + " Button is disabled");
					return false;
				}	
			}
			else{
				Log.error(rootEle().findElement(selector).getText() + " Button is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Button with selector as " + selector + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Verify that Command Button is enabled
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean verifyButtonEnabled(WebElement webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(webElement.isEnabled()) {
					Log.info(webElement.getText() + " Button is enabled");
					return true;
				}
				else{
					Log.error(webElement.getText() + " Button is disabled");
					return false;
				}	
			}
			else{
				Log.error(webElement.getText() + " Button is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Button with selector as " + webElement + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Return the Input Field Web element with label
	 * 
	 * @param labelName
	 * @param inputFieldIndex
	 * @return
	 * @throws InterruptedException 
	 */
	public WebElement getLabelInputElement(String labelName, int inputFieldIndex) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> labelList = driver.findElements(By.xpath(".//label"));
		for (WebElement listElement : labelList) {
			if (listElement.getText().equalsIgnoreCase(labelName)){

				//------
				//======
				//------
			}
		}
		return null;
	}

	/**
	 * Return the background color of the CPA Portal
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public String getBackgroundColor() throws InterruptedException {
		waitForPageToLoad();

		return driver.findElement(By.xpath(".//body")).getCssValue("background-color");
	}

	/**
	 * Validate that the Input Field is Convex field
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateConvexTextField(By selector) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(! rootEle().findElement(selector).isEnabled()) {
					String backgroundColor = rootEle().findElement(selector).getCssValue("background-color");
					String border = rootEle().findElement(selector).getCssValue("border-style");
					String expectedBackgroundColor = getBackgroundColor();
					if(border.contains("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("bg color:" + expectedBackgroundColor);
						return true;
					}
					else{
						Log.error("Not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not disabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Input Field is Convex field
	 * 
	 * @param selector
	 * @param expectedBackgroundColor
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateConvexTextField(By selector, String expectedBackgroundColor) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(! rootEle().findElement(selector).isEnabled()) {
					String backgroundColor = rootEle().findElement(selector).getCssValue("background-color");
					String border = rootEle().findElement(selector).getCssValue("border-style");
					if (expectedBackgroundColor == "")
						expectedBackgroundColor = getBackgroundColor();
					if(border.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("bg color:" + expectedBackgroundColor);
						return true;
					}
					else{
						Log.error("Not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not disabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Input field is Convex field
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateConvexTextField(WebElement webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(! webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					String border = webElement.getCssValue("border-style");
					String expectedBackgroundColor = getBackgroundColor();
					if(border.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("bg color:" + expectedBackgroundColor);
						return true;
					}
					else{
						Log.error("Not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Input field is Convex field
	 * 
	 * @param webElement
	 * @param expectedBackgroundColor
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateConvexTextField(WebElement webElement, String expectedBackgroundColor) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(! webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					String border = webElement.getCssValue("border-style");
					if (expectedBackgroundColor == "")
						expectedBackgroundColor = getBackgroundColor();
					if(border.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("bg color:" + expectedBackgroundColor);
						return true;
					}
					else{
						Log.error("Not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Input field is Concave field 
	 * 
	 * @param selector
	 * @return
	 */
	public boolean validateConcaveTextField(By selector) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					String backgroundColor = rootEle().findElement(selector).getCssValue("background-color");
					
					String border = rootEle().findElement(selector).getCssValue("border-style");
					System.out.println("Border Style:"+ " "+ border);
					if(border.equalsIgnoreCase("inset") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info("bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error("Not a Concave field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Input field is Concave field 
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateConcaveTextField(WebElement webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					String border = webElement.getCssValue("border-style");
					if(border.equalsIgnoreCase("inset") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info("bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error("Not a Concave field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Area is Convex
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateConvexArea(By selector) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				String backgroundColor = rootEle().findElement(selector).getCssValue("background-color");
				String border = rootEle().findElement(selector).getCssValue("border-style");
				String expectedBackgroundColor = getBackgroundColor();
				if(border.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
					Log.info("bg color:" + expectedBackgroundColor);
					return true;
				}
				else{
					Log.error("Not a Convex area");
					return false;
				}	

			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Area is Convex
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateConvexArea(WebElement webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				String backgroundColor = webElement.getCssValue("background-color");
				String border = webElement.getCssValue("border-style");
				String expectedBackgroundColor = getBackgroundColor();
				if(border.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
					Log.info("bg color:" + expectedBackgroundColor);
					return true;
				}
				else{
					Log.error("Not a Convex area");
					return false;
				}	

			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that Input field is Highlighted with Black border
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateHighligtedTextField_Old(By selector) throws InterruptedException {
		waitForPageToLoad();

		try{	
			//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					String backgroundColor = rootEle().findElement(selector).getCssValue("background-color");
					//String bordercolor = rootEle().findElement(selector).getCssValue("border-color");
					String borderTopColor = rootEle().findElement(selector).getCssValue("border-top-color");
					String borderBottomColor = rootEle().findElement(selector).getCssValue("border-bottom-color");
					String borderLeftColor = rootEle().findElement(selector).getCssValue("border-left-color");
					String borderRightColor = rootEle().findElement(selector).getCssValue("border-right-color");

					//String borderTopWidth = rootEle().findElement(selector).getCssValue("border-top-width");
					//String outlineOffset = rootEle().findElement(selector).getCssValue("outline-offset");

					//System.out.println("outlineOffset ="+outlineOffset);
					//System.out.println("borderTopWidth ="+borderTopWidth);
					/*System.out.println("borderTopColor ="+borderTopColor);
					System.out.println("borderBottomColor ="+borderBottomColor);
					System.out.println("borderLeftColor ="+borderLeftColor);
					System.out.println("borderRightColor of"+selector+"  ="+borderRightColor);*/

					if(borderTopColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderBottomColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderLeftColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderRightColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() +" field with selector as " + selector + " is highlighted with black border and bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not a Editable/Enabled field OR Field not highlighted with black border");
						return false;
					}	
				}
				else{
					Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector +" selector is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that Input field is Highlighted with Black border
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateHighligtedTextField_Old(WebElement webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					//String bordercolor = webElement.getCssValue("border-color");
					String borderTopColor = webElement.getCssValue("border-top-color");
					String borderBottomColor = webElement.getCssValue("border-bottom-color");
					String borderLeftColor = webElement.getCssValue("border-left-color");
					String borderRightColor = webElement.getCssValue("border-right-color");	

					if(borderTopColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderBottomColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderLeftColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && borderRightColor.equalsIgnoreCase("rgba(0, 0, 0, 1)") && backgroundColor.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.info(webElement.getText()+" field with selector as " + webElement + " is highlighted with black border and bg color:" + backgroundColor);
						return true;
					}
					else{
						Log.error(webElement.getText()+" field with selector as " + webElement + " is not highlihgted with black border");
						return false;
					}	
				}
				else{
					Log.error(webElement.getText()+" field with selector as " + webElement +  " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(webElement.getText()+" field with selector as " + webElement + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that Input field is Highlighted with Activated
	 * 
	 * @param selector
	 * @return
	 */
	public boolean validateHighligtedTextField (By selector) throws InterruptedException {
		waitForPageToLoad();

		try{
			//MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					if(	!rootEle().findElement(selector).equals(driver.switchTo().activeElement()))				{
						Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not highlighted ");
						return false;
					}
					else{
						Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() +" field with selector as " + selector + " is highlighted ");
						return true;
					}	
				}
				else{
					Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector +" selector is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that Input field is Highlighted and Activated
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateHighligtedTextField(WebElement webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(webElement.isEnabled()) {
					if(!webElement.equals(driver.switchTo().activeElement()))				{
						Log.error(webElement.getText()+" field with selector as " + webElement + " is not highlihgted ");
						return false;
					}
					else{
						Log.info(webElement.getText()+" field with selector as " + webElement + " is highlighted ");						
						return true;
					}	
				}
				else{
					Log.error(webElement.getText()+" field with selector as " + webElement +  " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(webElement.getText()+" field with selector as " + webElement + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Command button is highlighted with black border
	 * 
	 * @param buttonName
	 * @return
	 */
	public boolean validateButtonHighlighted(String buttonName) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> buttonList = rootEle().findElements(By.xpath("//button"));
		for(WebElement webElement:buttonList) {
			if(webElement.getText().trim().equalsIgnoreCase(buttonName)) {
				if(isElementEnabled(webElement)) {
					String borderStyle = webElement.getCssValue("border-style");
					String bordercolor = webElement.getCssValue("border-color");
					if(bordercolor.equalsIgnoreCase("rgb(0, 0, 0)") && borderStyle.equalsIgnoreCase("solid")) {
						Log.info(buttonName+" button is highlighted with black border");
						return true;
					}
					else{
						Log.error(buttonName+" button is highlighted with black border");
						return false;
					}	
				}
				else {
					Log.error(buttonName+" button is not enabled");
					return false;
				}
			}
		}
		Log.info("Button with "+buttonName+" is not found");
		return false;
	}

	/**
	 * Validate that the Command button is highlighted with black border
	 * 
	 * @param selector
	 * @return
	 */
	public boolean validateButtonHighlighted(By selector) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					String borderStyle = rootEle().findElement(selector).getCssValue("border-style");
					String bordercolor = rootEle().findElement(selector).getCssValue("border-color");
					if(bordercolor.equalsIgnoreCase("rgb(0, 0, 0)") && borderStyle.equalsIgnoreCase("solid")) {
						Log.info(rootEle().findElement(selector).getText()+" button with selector as " + selector + " is a highlighted with black border");
						return true;
					}
					else{
						Log.error(rootEle().findElement(selector).getText()+" button with selector as " + selector + " is not highlighted with black border");
						return false;
					}	
				}
				else{
					Log.error(rootEle().findElement(selector).getText()+" button with selector as " + selector +  " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(rootEle().findElement(selector).getText()+" button with selector as " + selector + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Command button is highlighted with black border
	 * 
	 * @param webElement
	 * @return
	 */
	public boolean validateButtonHighlighted(WebElement webElement) {
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(webElement.isEnabled()) {
					String borderStyle = webElement.getCssValue("border-style");
					String bordercolor = webElement.getCssValue("border-color");
					if(bordercolor.equalsIgnoreCase("rgb(0, 0, 0)") && borderStyle.equalsIgnoreCase("solid")) {
						Log.info(webElement.getText()+" button with selector as " + webElement + " is highlighted with black border");
						return true;
					}
					else{
						Log.error(webElement.getText()+" button with selector as " + webElement + " is not highlighted with black border");
						return false;
					}	
				}
				else{
					Log.error(webElement.getText()+" button with selector as " + webElement +  " is not enabled");
					return false;	
				}
			}
			else {
				Log.error(webElement.getText()+" button with selector as " + webElement + " is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error(webElement + " is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Radio button is highlighted with black border
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateRadioButtonHiglighted(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(rootEle().findElement(selector).isSelected())
			return true;
		else
			return false;
	}

	/**
	 * Validate the Highlighted Tab(Physician or Highlighted)
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateTabHighligted(By selector) throws InterruptedException {
		waitForPageToLoad();

		try {
			String borderTopColor = rootEle().findElement(selector).getCssValue("border-top-color");
			String borderLeftColor = rootEle().findElement(selector).getCssValue("border-left-color");
			String borderRightColor = rootEle().findElement(selector).getCssValue("border-right-color");
			if(borderTopColor.equalsIgnoreCase("rgba(194, 86, 8, 1)") && borderLeftColor.equalsIgnoreCase("rgba(221, 221, 221, 1)") && borderRightColor.equalsIgnoreCase("rgba(221, 221, 221, 1)")) {
				Log.info(rootEle().findElement(selector).getText()+" tab with selector as " + selector + " is highligted");
				return true;
			}
			else{
				Log.error(rootEle().findElement(selector).getText()+" tab with selector as " + selector + " is not highligted");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error(selector + " Tab is not found in DOM");
			return false;
		}
	}

	/**
	 * Validate the Highlighted Tab By Name(Physician or Hospital)
	 * 
	 * @param tabName
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateTabHighligted(String tabName) throws InterruptedException {
		waitForPageToLoad();

		try{
			WebElement webElement = rootEle().findElement(By.xpath(".//ul[@class='nav nav-tabs']//a[contains(text(),'"+tabName+"')]"));
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
			String borderTopColor =webElement.getCssValue("border-top-color");
			String borderLeftColor = webElement.getCssValue("border-left-color");
			String borderRightColor = webElement.getCssValue("border-right-color");
			if(borderTopColor.equalsIgnoreCase("rgba(194, 86, 8, 1)") && borderLeftColor.equalsIgnoreCase("rgba(221, 221, 221, 1)") && borderRightColor.equalsIgnoreCase("rgba(221, 221, 221, 1)")) {
				Log.info(webElement.getText()+" tab with selector as " + webElement + " is highligted");
				return true;
			}
			else{
				Log.error(webElement.getText()+" tab with selector as " + webElement + " is not highligted");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error(tabName + " Tab is not found in DOM");
			return false;
		}
	}

	/**
	 * Click on the Tab(Physician or Hospital)
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean clickOnTab(By selector) throws InterruptedException {
		waitForPageToLoad();

		try{
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(rootEle().findElement(selector)));
			rootEle().findElement(selector).click();
			waitForPageToLoad();
			String borderTopColor =rootEle().findElement(selector).getCssValue("border-top-color");
			String borderLeftColor = rootEle().findElement(selector).getCssValue("border-left-color");
			String borderRightColor = rootEle().findElement(selector).getCssValue("border-right-color");
			if(borderTopColor.equalsIgnoreCase("rgba(194, 86, 8, 1)") && borderLeftColor.equalsIgnoreCase("rgba(221, 221, 221, 1)") && borderRightColor.equalsIgnoreCase("rgba(221, 221, 221, 1)")) {
				Log.info(rootEle().findElement(selector).getText()+" tab with selector as " + selector + " is clicked and highligted");
				return true;
			}
			else{
				Log.error(rootEle().findElement(selector).getText()+" tab with selector as " + selector + " is not clicked/highligted");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error(selector + " Tab is not found in DOM");
			return false;
		}		
	}

	/**
	 * Click on the Tab By Name(Physician or Hospital)
	 * 
	 * @param tabName
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean clickOnTab(String tabName) throws InterruptedException {
		waitForPageToLoad();

		try{
			WebElement webElement = rootEle().findElement(By.xpath(".//ul[@class='nav nav-tabs']//a[contains(text(),'"+tabName+"')]"));
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
			webElement.click();
			waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
			//Thread.sleep(5000);
			String borderTopColor =webElement.getCssValue("border-top-color");
			String borderLeftColor = webElement.getCssValue("border-left-color");
			String borderRightColor = webElement.getCssValue("border-right-color");
			if(borderTopColor.equalsIgnoreCase("rgba(194, 86, 8, 1)") && borderLeftColor.equalsIgnoreCase("rgba(221, 221, 221, 1)") && borderRightColor.equalsIgnoreCase("rgba(221, 221, 221, 1)")) {
				Log.info(webElement.getText()+" tab with selector as " + webElement + " is clicked and highligted");
				return true;
			}
			else {
				Log.error(webElement.getText()+" tab with selector as " + webElement + " is not clicked/highligted");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error(tabName + " Tab is not found in DOM");
			return false;
		}		
	}

	/**
	 * Clicks on the tab available on page i.e. Physician or Hospital
	 * 
	 * @param tabName
	 * @return
	 */
	public boolean clickOnTabOnPage(String tabName) {
		try{
			WebElement webElement = rootEle().findElement(By.xpath(".//a[@data-toggle='tab' and contains(text(),'"+tabName+"')]"));
			if(isElementEnabled(webElement)){
				mouseClick(webElement);
				Log.info(webElement.getText()+" tab with selector as " + webElement + " is clicked");
				return true;
			}
			else {
				Log.error(webElement.getText()+" tab with selector as " + webElement +" is not enabled");
				return true;
			}
		}
		catch(NoSuchElementException e) {
			Log.error(tabName+" Tab is not found in DOM");
			e.printStackTrace();
			return false;
		}
		catch(Exception e) {
			Log.error(tabName+" Tab is not found");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Validate the Command button Standards
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateButtonStandard(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(selector).equalsIgnoreCase("bold"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" button with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate the Command button Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateButtonStandard(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equals("700"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		Log.info(webElement.getText()+" button with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate Enabled Input field Standards
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateEnabledTextFieldStandard(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(selector).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConcaveTextField(selector))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" Concave field with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Enabled Input field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateEnabledTextFieldStandard(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConcaveTextField(webElement))
			return false;

		Log.info(webElement.getText()+" Concave field with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandard(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false; 

		if(!getFontWeight(selector).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(selector))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param selector
	 * @param fontSize
	 * @param fontWeight
	 * @param fontColor
	 * @param fontType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandard(By selector, String fontSize, String fontWeight, String fontColor, String fontType, String fieldBackgroundColor) throws InterruptedException {
		waitForPageToLoad();

		if (fontSize=="")
			fontSize = "10px";
		if (fontWeight =="")
			fontWeight="400";
		if (fontColor == "")
			fontColor="rgba(0, 0, 0, 1)";
		if( fontType=="")
			fontType = "Verdana";

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(selector).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(selector, fieldBackgroundColor))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandard(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(webElement))
			return false;

		Log.info(webElement.getText()+" Convex field with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param webElement
	 * @param fontSize
	 * @param fontWeight
	 * @param fontColor
	 * @param fontType
	 * @param fieldBackgroundColor
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandard(WebElement webElement, String fontSize, String fontWeight, String fontColor, String fontType, String fieldBackgroundColor) throws InterruptedException {
		waitForPageToLoad();

		if (fontSize=="")
			fontSize = "10px";
		if (fontWeight =="")
			fontWeight="400";
		if (fontColor == "")
			fontColor="rgba(0, 0, 0, 1)";
		if( fontType=="")
			fontType = "Verdana";

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(webElement, fieldBackgroundColor))
			return false;

		Log.info(webElement.getText()+" Convex field with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedDisabledTextFieldStandard(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(selector).equalsIgnoreCase("700"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(selector))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input field Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedDisabledTextFieldStandard(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("700"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexTextField(webElement))
			return false;

		Log.info(webElement.getText()+" Convex field with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Text field Standards
	 * 
	 * @param selector
	 * @param noOFelement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledTextFieldStandardByList(By selector, int noOFelement) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> ele_DisabedText = rootEle().findElements(selector);
		//System.out.println("total number of element:"+ " "+ ele_DisabedText.size());
		Assert.assertTrue(ele_DisabedText.size()==noOFelement);
		System.out.println("Number of disabled elements are equal.");
		for(WebElement e:ele_DisabedText){
			if(!getFontSize(e).equalsIgnoreCase("10px"))
				return false;

			if(!getFontWeight(e).equalsIgnoreCase("400"))
				return false;

			//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
			//	return false;

			if(!getFontType(e).equalsIgnoreCase("verdana"))
				return false;

			if(!validateConvexTextField(e))
				return false;
		}

		Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input Area Standards
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledAreaStandard(By selector) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(selector).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(selector).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(selector).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(selector).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexArea(selector))
			return false;

		Log.info(rootEle().findElement(selector).getText()+" Convex area with selector as " + selector + " is validated");
		return true;
	}

	/**
	 * Validate Disabled Input Area Standards
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledAreaStandard(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		if(!getFontSize(webElement).equalsIgnoreCase("10px"))
			return false;

		if(!getFontWeight(webElement).equalsIgnoreCase("400"))
			return false;

		if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"))
			return false;

		if(!getFontType(webElement).equalsIgnoreCase("verdana"))
			return false;

		if(!validateConvexArea(webElement))
			return false;

		Log.info(webElement.getText()+" Convex area with selector as " + webElement + " is validated");
		return true;
	}

	/**
	 * Validate that the Message Error field is Convex field
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateMsgErrorConvexTextField(WebElement webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(! webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					String border_left_Style = webElement.getCssValue("border-left-style");
					String border_top_Style = webElement.getCssValue("border-top-style");
					String border_bottom_Style = webElement.getCssValue("border-bottom-style");
					String border_right_Style = webElement.getCssValue("border-right-style");
					String expectedBackgroundColor = getBackgroundColor();
					if(border_left_Style.equalsIgnoreCase("outset") && border_top_Style.equalsIgnoreCase("outset") && border_bottom_Style.equalsIgnoreCase("outset") && border_right_Style.equalsIgnoreCase("none") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("Error message bar bg color:" + expectedBackgroundColor);
						Log.info("Error msg bar a Convex field");
						return true;
					}
					else{
						Log.error("Error msg bar not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate that the Total Message field is Convex field
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateTotalMsgConvexTextField(WebElement webElement) throws InterruptedException {
		try{
			//windowRootWebElement.click();
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(webElement));
			if(webElement.isDisplayed()) {
				if(! webElement.isEnabled()) {
					String backgroundColor = webElement.getCssValue("background-color");
					String border_left_Style = webElement.getCssValue("border-left-style");
					String border_top_Style = webElement.getCssValue("border-top-style");
					String border_bottom_Style = webElement.getCssValue("border-bottom-style");
					String border_right_Style = webElement.getCssValue("border-right-style");
					String expectedBackgroundColor = getBackgroundColor();
					if(border_left_Style.equalsIgnoreCase("none") && border_top_Style.equalsIgnoreCase("outset") && border_bottom_Style.equalsIgnoreCase("outset") && border_right_Style.equalsIgnoreCase("outset") && backgroundColor.equalsIgnoreCase(expectedBackgroundColor)) {
						Log.info("Error message bar bg color:" + expectedBackgroundColor);
						Log.info("Total message a Convex field");
						return true;
					}
					else{
						Log.error("Total message not a Convex field");
						return false;
					}	
				}
				else{
					Log.error("Webelement is not enabled");
					return false;	
				}
			}
			else {
				Log.error("Webelement is not displayed");
				return false;	
			}
		}
		catch(NoSuchElementException e){
			Log.error("Element not found in DOM");
			return false;
		}
	}

	/**
	 * Validate Error Msg bar Text field Standards
	 * 
	 * @param selector
	 * @param noOFelement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateMessageBarTextFieldStandardByList(By selector, int noOFelement) throws InterruptedException {
		waitForPageToLoad();

		try {
			List<WebElement> ele_MsgErrorDisabedText = rootEle().findElements(selector);
			//System.out.println("total number of element:"+ " "+ ele_DisabedText.size());
			Assert.assertTrue(ele_MsgErrorDisabedText.size()==noOFelement);
			System.out.println("Number of disabled Msg Error elements are equal.");
			for(WebElement e:ele_MsgErrorDisabedText){
				if(!getFontSize(e).equalsIgnoreCase("10px"))
					return false;

				if(!getFontWeight(e).equalsIgnoreCase("400"))
					return false;

				//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
				//	return false;

				if(!getFontType(e).equalsIgnoreCase("verdana"))
					return false;

				if(!validateMsgErrorConvexTextField(e))
					return false;
			}

			Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * Validate Error Msg bar Text field Standards
	 * 
	 * @param selector
	 * @param noOFelement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateTotalMsgTextFieldStandardByList(By selector, int noOFelement) throws InterruptedException {
		waitForPageToLoad();

		try {
			List<WebElement> ele_MsgErrorDisabedText = rootEle().findElements(selector);
			//System.out.println("total number of element:"+ " "+ ele_DisabedText.size());
			Assert.assertTrue(ele_MsgErrorDisabedText.size()==noOFelement);
			System.out.println("Number of disabled Msg Error elements are equal.");
			for(WebElement e:ele_MsgErrorDisabedText){
				if(!getFontSize(e).equalsIgnoreCase("10px"))
					return false;

				if(!getFontWeight(e).equalsIgnoreCase("400"))
					return false;

				//if(!getFontColor(webElement).equalsIgnoreCase("10px"))
				//	return false;

				if(!getFontType(e).equalsIgnoreCase("verdana"))
					return false;

				if(!validateTotalMsgConvexTextField(e))
					return false;
			}

			Log.info(rootEle().findElement(selector).getText()+" Convex field with selector as " + selector + " is validated");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * Return Input WebElement based on Label Name
	 * 
	 * @param strLabel
	 * @return
	 * @throws InterruptedException 
	 */
	public WebElement getInputFieldByLabelName(String strLabel) throws InterruptedException {		
		waitForPageToLoad();

		try{
			MIDDRIVERWAIT.until(ExpectedConditions.visibilityOf(rootEle().findElement(By.xpath(".//textarea[contains(text(), '"+ strLabel +"')]//following-sibling::input"))));
			Log.info("Field with Label "+strLabel+ " is visible");
			return rootEle().findElement(By.xpath(".//textarea[contains(text(), '"+ strLabel +"')]//following-sibling::input"));
		}
		catch(NoSuchElementException e) {
			Log.error("Field with Label "+strLabel+ " is not found in DOM");
			return null;
		}
	}

	/**
	 * Validate that all the labels have colon at the end
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateColonInAllLabels() throws InterruptedException {	
		waitForPageToLoad();

		List<WebElement> listLabel =  rootEle().findElements(By.xpath(".//label"));
		for(WebElement label:listLabel){
			if(!label.getText().equalsIgnoreCase("")) {
				if(label.getText().charAt(label.getText().length()-1) != ':') {
					Log.info("Colon is not present for label " + label.getText());
					return false;
				}
			}
		}
		Log.info("Colons are present in all labels");
		return true;
	}

	/**
	 * Get the Web Element location i.e. x,y or height or width
	 * 
	 * @param selector
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public int getWebElementLocationAttribute(By selector, String attribute) throws InterruptedException {
		waitForPageToLoad();

		WebElement webElement = driver.findElement(selector);
		Point point_WebElement = webElement.getLocation();
		if(attribute.equalsIgnoreCase("x"))
			return point_WebElement.getX();
		else if(attribute.equalsIgnoreCase("y"))
			return point_WebElement.getY();
		else if(attribute.equalsIgnoreCase("height"))
			return webElement.getSize().getHeight();
		else if(attribute.equalsIgnoreCase("width"))
			return webElement.getSize().getWidth();
		else {
			Log.error("Please select valid attribute i.e. x,y,height or width");
			return 0;
		}
	}

	/**
	 * Get the Web Element location(x,y), height or width
	 * 
	 * @param webElement
	 * @param attribute
	 * @return
	 * @throws InterruptedException
	 */
	public int getWebElementLocationAttribute(WebElement webElement, String attribute) throws InterruptedException {
		waitForPageToLoad();

		Point point_WebElement = webElement.getLocation();
		if(attribute.equalsIgnoreCase("x"))
			return point_WebElement.getX();
		else if(attribute.equalsIgnoreCase("y"))
			return point_WebElement.getY();
		else if(attribute.equalsIgnoreCase("height"))
			return webElement.getSize().getHeight();
		else if(attribute.equalsIgnoreCase("width"))
			return webElement.getSize().getWidth();
		else {
			Log.error("Please select valid attribute i.e. x,y,height or width");
			return 0;
		}
	}

	/**
	 * Validate the location of one element w.r.t. each other (Left Right relationship)
	 * 
	 * @param leftElement
	 * @param rightElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateLocation(By leftElement, By rightElement) throws InterruptedException {
		waitForPageToLoad();

		int xcord_leftWebElement = getWebElementLocationAttribute(leftElement, "x");
		int ycord_leftWebElement = getWebElementLocationAttribute(leftElement, "y");
		int width_leftWebElement = getWebElementLocationAttribute(leftElement, "width");

		int xcord_rightWebElement = getWebElementLocationAttribute(rightElement, "x");
		int ycord_rightWebElement = getWebElementLocationAttribute(rightElement, "y");

		if(ycord_leftWebElement+3>=ycord_rightWebElement && ycord_leftWebElement-3<=ycord_rightWebElement && xcord_leftWebElement+width_leftWebElement <= xcord_rightWebElement ) {
			Log.info(rootEle().findElement(leftElement).getText() + " web element with selector as " + leftElement  +" is on the left to " + rootEle().findElement(rightElement).getText() + " web element with selector as " + rightElement);
			return true;
		}
		else {
			Log.error(rootEle().findElement(leftElement).getText() + " web element with selector as " + leftElement  +" is not on the left to " + rootEle().findElement(rightElement).getText() + " web element with selector as " + rightElement);
			return false;
		}
	}

	/**
	 * Validate the location of one element w.r.t. each other (Left Right relationship)
	 * 
	 * @param leftElement
	 * @param rightElement
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateLocation(WebElement leftWebElement, WebElement rightWebElement) throws InterruptedException {
		waitForPageToLoad();

		int xcord_leftWebElement = getWebElementLocationAttribute(leftWebElement, "x");
		int ycord_leftWebElement = getWebElementLocationAttribute(leftWebElement, "y");
		int width_leftWebElement = getWebElementLocationAttribute(leftWebElement, "width");

		int xcord_rightWebElement = getWebElementLocationAttribute(rightWebElement, "x");
		int ycord_rightWebElement = getWebElementLocationAttribute(rightWebElement, "y");

		if(ycord_leftWebElement+3>=ycord_rightWebElement && ycord_leftWebElement-3<=ycord_rightWebElement && xcord_leftWebElement+width_leftWebElement <= xcord_rightWebElement ) {
			Log.info(leftWebElement.getText() + " web element with selector as " + leftWebElement  +" is on the left to " + rightWebElement.getText() + " web element with selector as " + rightWebElement);
			return true;
		}
		else {
			Log.error(leftWebElement.getText() + " web element with selector as " + leftWebElement  +" is not on the left to " + rightWebElement.getText() + " web element with selector as " + rightWebElement);
			return false;
		}
	}

	/**
	 * Validate Command buttons UI Standard
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateAllButtonStandardsOnPage() throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(".//button"));
		for(WebElement webelement: listWebElements) {
			if(!validateButtonStandard(webelement)) {
				Log.error(webelement.getText()+" button with selector as " + webelement + " is not validated");
				return false;
			}
		}

		Log.info("All the buttons standards are validated");
		return true;
	}

	/**
	 * Validate Command buttons UI Standard
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean validateAllButtonHighlightOnMouseHover() throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(".//button"));
		for(WebElement webelement: listWebElements) {
			if(webelement.isEnabled()) {
				mouseHover(webelement);
				if(!validateButtonHighlighted(webelement)) {
					Log.error(webelement.getText()+" button with selector as " + webelement + " is not highlighted");
					return false;
				}
			}
		}

		Log.info("All the buttons are highligted on Mouse Hover");
		return true;
	}

	/**
	 * Validate the label names on the page sent in String Parameter(Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsOnPage_Old(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(".//*"));
		//Create List of all Actual labels
		List<String> list_ActualLabels = new ArrayList<String>();
		for(WebElement webElement:listWebElements) {
			if(!webElement.getText().equalsIgnoreCase("")){
				list_ActualLabels.add(webElement.getText().trim());
			}
		}

		//Create List out of Expected Labels 
		List<String> list_ExpectedLabels = new ArrayList<String>();
		String arrLabels[] = labels.split("\\|\\|");
		for(int i=0;i<arrLabels.length;i++)
			list_ExpectedLabels.add(arrLabels[i]);

		/*System.out.println("____________________");
		System.out.println  ("________Actual______");
		System.out.println("____________________");
		for(int i=0;i<list_ActualLabels.size();i++)
			System.out.println(list_ActualLabels.get(i));

		System.out.println("____________________");
		System.out.println("______Expected______");
		System.out.println("____________________");

		for(int i=0;i<list_ExpectedLabels.size();i++)
			System.out.println(list_ExpectedLabels.get(i));*/

		//return list_ActualLabels.containsAll(list_ExpectedLabels);

		list_ActualLabels.retainAll(list_ExpectedLabels);

		if(list_ActualLabels.size()==list_ExpectedLabels.size()) {
			Collections.sort(list_ActualLabels); 
			Collections.sort(list_ExpectedLabels); 
			for(int i=0;i<list_ExpectedLabels.size();i++) {
				if(!list_ExpectedLabels.get(i).equals(list_ActualLabels.get(i))){
					Log.error("Value didn't matched. Expected value: "+list_ExpectedLabels.get(i)+" and Actual value: "+list_ActualLabels.get(i));
					return false;
				}
			}
			Log.info("All the values matched");
			return true;
		}
		else {
			Log.error("Count didn't matched. Expected Count: "+list_ExpectedLabels.size()+" and Actual Count: "+list_ActualLabels.size());
			return false;
		}
	}

	/**
	 * Validate the label names on the page sent in String Parameter(Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

	List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));
		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Void Check Inventory")){
			listWebElements_Label = rootEle().findElements(By.xpath(".//div[@id='voidCheckInventoryHeader' or @id= 'voidCheckInventoryDetailHeading']//label"));
			listWebElements_Span = rootEle().findElements(By.xpath(".//div[@id='voidCheckInventoryHeader' or @id= 'voidCheckInventoryDetailHeading']//span"));		
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician ATG Main Menu")){
			listWebElements_Span = rootEle().findElements(By.tagName("h1"));
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hosp ATG Add Batch") || Constants.FEATURENAME.equalsIgnoreCase("Hosp ATG View Batch")){
			listWebElements_Span = rootEle().findElements(By.xpath(".//div"));
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Condensed Claim")) {
			listWebElements_Label = rootEle().findElements(By.tagName("label"));
			listWebElements_Span = rootEle().findElements(By.tagName("span"));
			List<WebElement> listWebElements_tableRows = rootEle().findElements(By.xpath(".//table[@id='PhyscianfullclaimFMDetails']//td"));
			listWebElements_Label.addAll(listWebElements_Span);
			listWebElements_Label.addAll(listWebElements_tableRows);
		}
		else {
			listWebElements_Label.addAll(listWebElements_Span);
		}

		//Create List of all Actual labels
		List<String> list_ActualLabels = new ArrayList<String>();
		for(WebElement webElement:listWebElements_Label) {
			if(!webElement.getText().equalsIgnoreCase("")){
				list_ActualLabels.add(webElement.getText().trim());
			}
		}

		//Create List out of Expected Labels 
		List<String> list_ExpectedLabels = new ArrayList<String>();
		String arrLabels[] = labels.split("\\|\\|");
		for(int i=0;i<arrLabels.length;i++)
			list_ExpectedLabels.add(arrLabels[i]);

		/*System.out.println("____________________");
		System.out.println  ("________Actual______");
		System.out.println("____________________");
		for(int i=0;i<list_ActualLabels.size();i++)
			System.out.println(list_ActualLabels.get(i));

		System.out.println("____________________");
		System.out.println("______Expected______");
		System.out.println("____________________");

		for(int i=0;i<list_ExpectedLabels.size();i++)
			System.out.println(list_ExpectedLabels.get(i));
		 */

		//return list_ActualLabels.containsAll(list_ExpectedLabels);
		System.out.println("Expected Labels:"+ " "+ list_ExpectedLabels);
		System.out.println("Actual Labels:"+ " "+ list_ActualLabels);
		list_ActualLabels.retainAll(list_ExpectedLabels);

		if(list_ActualLabels.size()==list_ExpectedLabels.size()) {
			Collections.sort(list_ActualLabels); 
			Collections.sort(list_ExpectedLabels); 
			for(int i=0;i<list_ExpectedLabels.size();i++) {
				if(!list_ExpectedLabels.get(i).equals(list_ActualLabels.get(i))){
					Log.error("Value didn't matched. Expected value: "+list_ExpectedLabels.get(i)+" and Actual value: "+list_ActualLabels.get(i));
					return false;
				}
			}
			Log.info("All the values matched");
			return true;
		}
		else {
			Log.error("Count didn't matched. Expected Count: "+list_ExpectedLabels.size()+" and Actual Count: "+list_ActualLabels.size());
			return false;
		}
	}

	/**
	 * Validate the label names on the page sent in String Parameter(Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Label = rootEle().findElements(locator);

		//Create List of all Actual labels
		List<String> list_ActualLabels = new ArrayList<String>();
		for(WebElement webElement:listWebElements_Label) {
			if(!webElement.getText().equalsIgnoreCase("")){
				list_ActualLabels.add(webElement.getText().trim());
			}
		}

		//Create List out of Expected Labels 
		List<String> list_ExpectedLabels = new ArrayList<String>();
		String arrLabels[] = labels.split("\\|\\|");
		for(int i=0;i<arrLabels.length;i++)
			list_ExpectedLabels.add(arrLabels[i]);

		/*System.out.println("____________________");
		System.out.println  ("________Actual______");
		System.out.println("____________________");
		for(int i=0;i<list_ActualLabels.size();i++)
			System.out.println(list_ActualLabels.get(i));

		System.out.println("____________________");
		System.out.println("______Expected______");
		System.out.println("____________________");

		for(int i=0;i<list_ExpectedLabels.size();i++)
			System.out.println(list_ExpectedLabels.get(i));
		 */

		//return list_ActualLabels.containsAll(list_ExpectedLabels);

		list_ActualLabels.retainAll(list_ExpectedLabels);

		if(list_ActualLabels.size()==list_ExpectedLabels.size()) {
			Collections.sort(list_ActualLabels); 
			Collections.sort(list_ExpectedLabels); 
			for(int i=0;i<list_ExpectedLabels.size();i++) {
				if(!list_ExpectedLabels.get(i).equals(list_ActualLabels.get(i))){
					Log.error("Value didn't matched. Expected value: "+list_ExpectedLabels.get(i)+" and Actual value: "+list_ActualLabels.get(i));
					return false;
				}
			}
			Log.info("All the values matched");
			return true;
		}
		else {
			Log.error("Count didn't matched. Expected Count: "+list_ExpectedLabels.size()+" and Actual Count: "+list_ActualLabels.size());
			return false;
		}
	}

	/**
	 * Validate the Column headers names on the page sent in String Parameter(Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateColumnHeadersOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//table//tr[1]//td"));
		List<WebElement> listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath(".//table//tr[2]//td"));
		List<WebElement> listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath(".//table//thead//tr//th"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Manual Entry")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//div[@class='nospace']/span"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Entry") || Constants.FEATURENAME.equalsIgnoreCase("Medical Record Information") || Constants.FEATURENAME.equalsIgnoreCase("RTS Search")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.tagName("span"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Review")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.tagName("label"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.tagName("span"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("OOPS Deductible")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.tagName("label"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath(".//table//thead//tr//td"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Multiple Copay Inquiry") || Constants.FEATURENAME.equalsIgnoreCase("Void Check Criteria")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//table//thead//tr//td"));
		}
		else if (Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//table//thead//tr//th"));
		}
		else {
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}	

		//Create List of all Actual labels
		List<String> list_ActualLabels = new ArrayList<String>();
		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider")) {
				if(!webElement.getAttribute("innerText").equalsIgnoreCase("")){					
					list_ActualLabels.add(webElement.getAttribute("innerText").trim());
				}				
			}
			else
			{
				if(!webElement.getText().equalsIgnoreCase("")){
					list_ActualLabels.add(webElement.getText().trim());
				}
			}
		}

		//Create List out of Expected Labels
		List<String> list_ExpectedLabels = new ArrayList<String>();
		String arrLabels[] = labels.split("\\|\\|");
		for(int i=0;i<arrLabels.length;i++)
			list_ExpectedLabels.add(arrLabels[i]);

		/*System.out.println("____________________");
		System.out.println  ("________Actual______");
		System.out.println("____________________");
		for(int i=0;i<list_ActualLabels.size();i++)
			System.out.println(list_ActualLabels.get(i));

		System.out.println("____________________");
		System.out.println("______Expected______");
		System.out.println("____________________");

		for(int i=0;i<list_ExpectedLabels.size();i++)
			System.out.println(list_ExpectedLabels.get(i));
		 */
		//return list_ActualLabels.containsAll(list_ExpectedLabels);

		list_ActualLabels.retainAll(list_ExpectedLabels);
		if(list_ActualLabels.size()==list_ExpectedLabels.size()) {
			Collections.sort(list_ActualLabels); 
			Collections.sort(list_ExpectedLabels); 
			for(int i=0;i<list_ExpectedLabels.size();i++) {
				if(!list_ExpectedLabels.get(i).equals(list_ActualLabels.get(i))){
					Log.error("Value didn't matched. Expected value: "+list_ExpectedLabels.get(i)+" and Actual value: "+list_ActualLabels.get(i));
					return false;
				}
			}
			Log.info("All the values matched");
			return true;
		}
		else {
			Log.error("Count didn't matched. Expected Count: "+list_ExpectedLabels.size()+" and Actual Count: "+list_ActualLabels.size());
			return false;
		}
	}

	/**
	 * Validate the Column headers names on the page sent in String Parameter(Labels should be separated by || operator)
	 * 
	 * @param Locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateColumnHeadersOnPage(By Locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(Locator);

		//Create List of all Actual labels
		List<String> list_ActualLabels = new ArrayList<String>();
		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(!webElement.getText().equalsIgnoreCase(""))
				list_ActualLabels.add(webElement.getText().trim());
		}

		//Create List out of Expected Labels
		List<String> list_ExpectedLabels = new ArrayList<String>();
		String arrLabels[] = labels.split("\\|\\|");
		for(int i=0;i<arrLabels.length;i++)
			list_ExpectedLabels.add(arrLabels[i]);

		/*System.out.println("____________________");
		System.out.println  ("________Actual______");
		System.out.println("____________________");
		for(int i=0;i<list_ActualLabels.size();i++)
			System.out.println(list_ActualLabels.get(i));

		System.out.println("____________________");
		System.out.println("______Expected______");
		System.out.println("____________________");

		for(int i=0;i<list_ExpectedLabels.size();i++)
			System.out.println(list_ExpectedLabels.get(i));
		 */
		//return list_ActualLabels.containsAll(list_ExpectedLabels);
		System.out.println("Actual labels:"+ " "+list_ActualLabels);
		System.out.println("Exp labels:"+ " "+list_ExpectedLabels);
		list_ActualLabels.retainAll(list_ExpectedLabels);

		if(list_ActualLabels.size()==list_ExpectedLabels.size()) {
			Collections.sort(list_ActualLabels); 
			
			Collections.sort(list_ExpectedLabels); 
			
			for(int i=0;i<list_ExpectedLabels.size();i++) {
				if(!list_ExpectedLabels.get(i).equals(list_ActualLabels.get(i))){
					Log.error("Value didn't matched. Expected value: "+list_ExpectedLabels.get(i)+" and Actual value: "+list_ActualLabels.get(i));
					return false;
				}
			}
			Log.info("All the values matched");
			return true;
		}
		else {
			Log.error("Count didn't matched. Expected Count: "+list_ExpectedLabels.size()+" and Actual Count: "+list_ActualLabels.size());
			return false;
		}
	}

	/**
	 * Validate Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPage_Old(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(".//*"));
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("Labels validated");
			return true;
		}
		else {
			Log.error("Labels validated");
			return false;
		}
	}

	/**
	 * Validate Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();	

		List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));
		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Void Check Inventory")){
			listWebElements_Label = rootEle().findElements(By.xpath(".//div[@id='voidCheckInventoryHeader' or @id= 'voidCheckInventoryDetailHeading']//label"));
			listWebElements_Span = rootEle().findElements(By.xpath(".//div[@id='voidCheckInventoryHeader' or @id= 'voidCheckInventoryDetailHeading']//span"));		
			listWebElements_Label.addAll(listWebElements_Span);

		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician ATG Main Menu")){
			listWebElements_Span = rootEle().findElements(By.tagName("h1"));
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hosp ATG Add Batch") || Constants.FEATURENAME.equalsIgnoreCase("Hosp ATG View Batch")){
			listWebElements_Span = rootEle().findElements(By.xpath(".//div"));
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Condensed Claim")) {
			listWebElements_Label = rootEle().findElements(By.tagName("label"));
			listWebElements_Span = rootEle().findElements(By.tagName("span"));
			List<WebElement> listWebElements_tableRows = rootEle().findElements(By.xpath(".//table[@id='PhyscianfullclaimFMDetails']//td"));
			listWebElements_Label.addAll(listWebElements_Span);
			listWebElements_Label.addAll(listWebElements_tableRows);
		}
		else {
			listWebElements_Label.addAll(listWebElements_Span);
		}

		/*if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Manual Entry")){
			listWebElements_Label = rootEle().findElements(By.tagName("label"));
		}
		else{
			listWebElements_Label.addAll(listWebElements_Span);
		}*/

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();	

		List<WebElement> listWebElements_Label = rootEle().findElements(locator);

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * To validate the UI Stadard labels 
	 * 
	 * @author sgupt228
	 * @param locator
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPage_ByLocator(String locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(locator));
		System.out.println("Number of Element from UI:" + " " + listWebElements.size() );

		String arrLabels[] = labels.split("\\|\\|");
		System.out.println("Number of elements from Excel"+ " " + arrLabels.length);

		for(WebElement webElement:listWebElements) {
			if(webElement.getText().trim().equals(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")){
						Log.error(webElement.getText() + " webelement's text is bolded");
						return false;
					}
					break;
				}
			}
		}
		Log.info("All the labels standards are validated");
		return true;
	}

	/**
	 * Validate While colored Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateWhiteLabelsStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));
		List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));
		listWebElements_Label.addAll(listWebElements_Span);

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate While colored Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateWhiteLabelsStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Label = rootEle().findElements(locator);
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * White Label Standard
	 * 
	 * @param locator
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateWhiteLabelsStandardsOnPage_ByLocator(String locator) throws InterruptedException {
		waitForPageToLoad();

		try{
			List<WebElement> listWebElements = rootEle().findElements(By.xpath(locator));

			for(WebElement webElement:listWebElements) {
				Assert.assertTrue(getFontColor(webElement).equalsIgnoreCase("rgba(255, 255, 255, 1)"));
				Log.info(webElement.getText()+" "+ "text is white");
				Assert.assertTrue(getFontSize(webElement).equalsIgnoreCase("10px"));
				Log.info(webElement.getText()+" "+ "text size is 10px");
				Assert.assertTrue(getFontType(webElement).equalsIgnoreCase("Verdana"));
				Log.info(webElement.getText()+" "+ "text font is Verdana");
				Assert.assertTrue(getFontWeight(webElement).equalsIgnoreCase("400"));
				Log.info(webElement.getText()+" "+ "text is non bolded");
			}
		}
		catch(Exception e){
			e.printStackTrace();
			Assert.fail();
		}
		return true;
	}

	/**
	 * Validate Bolded Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedLabelsStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));
		List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Physician Review")) {
			listWebElements_Label = rootEle().findElements(By.tagName("b"));
		} 
		else{
			listWebElements_Label.addAll(listWebElements_Span);
		}

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("700")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Bolded Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedLabelsStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Label = rootEle().findElements(locator);
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("700")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Underlined Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateUnderlinedLabelsStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Span = rootEle().findElements(By.xpath(".//span//u"));
		List<WebElement> listWebElements_Label = rootEle().findElements(By.xpath(".//label//u"));
		listWebElements_Label.addAll(listWebElements_Span);

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Underlined Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateUnderlinedLabelsStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Label = rootEle().findElements(locator);
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @param fontColor
	 * @param fontSize
	 * @param fontType
	 * @param fontWeight
	 * @param fontDecoritionLine
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPage(String labels, String fontColor, String fontSize, String fontType, String fontWeight, String fontDecoritionLine) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));
		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Physician ATG Main Menu")){
			listWebElements_Span = rootEle().findElements(By.tagName("h1"));
			listWebElements_Label.addAll(listWebElements_Span);
		}
		else {
			listWebElements_Label.addAll(listWebElements_Span);
		}

		/*if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Manual Entry")){
			listWebElements_Label = rootEle().findElements(By.tagName("label"));
		}
		else{
			listWebElements_Label.addAll(listWebElements_Span);
		}*/

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		if (fontColor == "")
			fontColor="rgba(0, 0, 0, 1)";
		if (fontSize=="")
			fontSize = "10px";
		if( fontType=="")
			fontType = "Verdana";
		if (fontWeight =="")
			fontWeight="400";

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase(fontColor)) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase(fontSize)) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase(fontType)) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase(fontWeight)) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(fontDecoritionLine.equalsIgnoreCase("underline")) {
						if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
							Log.error(webElement.getText()+" webelement's Font is not Underlined hence doesn't pass the UI Validations");
							return false;
						}
					}
					else {
						if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
							Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
							return false;
						}
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}

	/**
	 * Validate Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateColumnHeadersStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td"));
		List<WebElement> listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td"));
		List<WebElement> listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//tr[1]//th"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Manual Entry")){
			List<WebElement> listWebElements_ColumnHeaders_3 = rootEle().findElements(By.xpath("//div[@id='hospManualEntryDetailSectionContainer']//span"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_3);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Entry") || Constants.FEATURENAME.equalsIgnoreCase("Medical Record Information")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.tagName("span"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Manual Entry")){
			List<WebElement> listWebElements_ColumnHeaders_4 = rootEle().findElements(By.xpath("//table//tr[2]//th"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_4);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Multiple Copay Inquiry") || Constants.FEATURENAME.equalsIgnoreCase("Void Check Criteria")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//thead//tr//td"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider"))
		{
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table/thead/tr/th"));			
		}
		else{
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}	

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().equalsIgnoreCase("")){
				new Actions(driver).moveToElement(listWebElements_ColumnHeaders.get(listWebElements_ColumnHeaders.size()-1)).perform();
			}
			if(webElement.getText().equalsIgnoreCase("")){
				continue;
			}

			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(count==1 && Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider"))
						break;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}

		if(Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider"))
		{
			count = count+1;
		}

		if(arrLabels.length==count) {
			Log.info("All Columns Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateColumnHeadersStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(locator);
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().equalsIgnoreCase("")){
				new Actions(driver).moveToElement(listWebElements_ColumnHeaders.get(listWebElements_ColumnHeaders.size()-1)).perform();
			}
			if(webElement.getText().equalsIgnoreCase("")){
				continue;
			}

			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}

		if(Constants.FEATURENAME.equalsIgnoreCase("Negative Payments By Provider"))
		{
			count = count+1;
		}

		if(arrLabels.length==count) {
			Log.info("All Columns Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Bolded but not underline Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedColumnHeadersStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//tr[1]//th//u"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Physician Review")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath(".//label"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Archival")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td"));
			listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//thead//tr//th"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("RTS Search")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("OOPS Deductible")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//thead//tr//td"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Member Search") || Constants.FEATURENAME.equalsIgnoreCase("Void Check Inventory")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//thead//tr//th"));
		}		
		else {
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("700")) {
						System.out.println("getFontWeight(webElement) ="+getFontWeight(webElement));
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Column Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Bolded but not underline Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBoldedColumnHeadersStandardsOnPage(By locator, String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(locator);
		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("700")) {
						System.out.println("getFontWeight(webElement) ="+getFontWeight(webElement));
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Column Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Underlined Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateUnderlinedColumnHeadersStandardsOnPage(String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//tr[1]//th//u"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Physician Review")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath(".//label"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Archival")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td"));
			listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//thead//tr//th"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("RTS Search")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("OOPS Deductible")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//thead//tr//td"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Member Search")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//thead//tr//th"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Physician Condensed Claim")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table[@id='physcianfullclaimdatatables' or@id='detailsTableFirst']//tbody//tr[1]//td"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tbody//tr//td//u"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("DME By Member Cataory Search"))
		{
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//table//tr[1]//td[@class='underlineDMEI']"));
		}
		else {
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;
		List<String> act_Values = new ArrayList();
		System.out.println("Expected values"+ " "+ Arrays.toString(arrLabels));
		for(WebElement e:listWebElements_ColumnHeaders)
		{
			act_Values.add(e.getText());
		}
		System.out.println("Actual values:"+ " "+ act_Values);

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is not Underlined hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Column Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Underlined Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param locator
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateUnderlinedColumnHeadersStandardsOnPage(By locator,String labels) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(locator);

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
						Log.error(webElement.getText()+" webelement's Font is not Underlined hence doesn't pass the UI Validations");
						return false;
					}

					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Column Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate Column Headers Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @param fontColor
	 * @param fontSize
	 * @param fontType
	 * @param fontWeight
	 * @param fontDecoritionLine
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateColumnHeadersStandardsOnPage(String labels, String fontColor, String fontSize, String fontType, String fontWeight, String fontDecoritionLine) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td//u"));
		List<WebElement> listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//tr[1]//th//u"));

		if(Constants.FEATURENAME.equalsIgnoreCase("Physician Review")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath(".//label"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("Hospital Archival")) {
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath("//table//tr[1]//td"));
			listWebElements_ColumnHeaders_1 = rootEle().findElements(By.xpath("//table//tr[2]//td"));
			listWebElements_ColumnHeaders_2 = rootEle().findElements(By.xpath("//table//thead//tr//th"));
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("RTS Search")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.xpath(".//span//u"));
		}
		else if(Constants.FEATURENAME.equalsIgnoreCase("OOPS Deductible")){
			listWebElements_ColumnHeaders = rootEle().findElements(By.tagName("label"));
		}
		else {
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_1);
			listWebElements_ColumnHeaders.addAll(listWebElements_ColumnHeaders_2);
		}

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		if (fontColor == "")
			fontColor="rgba(0, 0, 0, 1)";
		if (fontSize=="")
			fontSize = "10px";
		if( fontType=="")
			fontType = "Verdana";
		if (fontWeight =="")
			fontWeight="400";

		for(WebElement webElement:listWebElements_ColumnHeaders) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase(fontColor)) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase(fontSize)) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase(fontType)) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase(fontWeight)) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					if(fontDecoritionLine.equalsIgnoreCase("underline")) {
						if(!getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
							Log.error(webElement.getText()+" webelement's Font is not Underlined hence doesn't pass the UI Validations");
							return false;
						}
					}
					else {
						if(getFontDecorationLine(webElement).equalsIgnoreCase("underline")) {
							Log.error(webElement.getText()+" webelement's Font is Underlined hence doesn't pass the UI Validations");
							return false;
						}
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("All Column Headers validated");
			return true;
		}
		else {
			Log.error("All Column Headers not validated");
			return false;
		}
	}

	/**
	 * Validate that field is a Hammered field
	 * 
	 * @param field
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateHammeredField(By field) throws InterruptedException{
		waitForPageToLoad();

		String bgColor = rootEle().findElement(field).getCssValue("background-color");				
		String border =  rootEle().findElement(field).getCssValue("border-style");
		String fontWeight =  rootEle().findElement(field).getCssValue("font-weight");
		if(bgColor.equalsIgnoreCase("rgba(171, 171, 171, 1)") && border.equalsIgnoreCase("inset") && fontWeight.equalsIgnoreCase("400")) {		
			Log.info(rootEle().findElement(field).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + field + " is a Hammered Field");
			return true;
		}
		else {
			Log.error(rootEle().findElement(field).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + field + " is not a Hammered Field");
			return false;
		}
	}

	/**
	 * To Hammer a Input field
	 * 
	 * @param hammerIcon
	 * @param field
	 * @return
	 * @throws InterruptedException
	 * @throws IOException 
	 * @throws ScriptException 
	 * @throws NoSuchMethodException 
	 */
	public boolean hammerField(By hammerIcon, By field) throws InterruptedException, ScriptException, IOException, NoSuchMethodException {
		waitForPageToLoad();

		/*
		int xcord_HammerIcon = getWebElementLocationAttribute(hammerIcon, "x");
		int ycord_HammerIcon = getWebElementLocationAttribute(hammerIcon, "y");
		int height_HammerIcon =getWebElementLocationAttribute(hammerIcon, "height");
		int width_HammerIcon = getWebElementLocationAttribute(hammerIcon, "width");

		int dragX_HammerIcon = xcord_HammerIcon + width_HammerIcon/2;
		int dragY_HammerIcon = ycord_HammerIcon + height_HammerIcon/2;

		int xcord_Field = getWebElementLocationAttribute(field, "x");
		int ycord_Field = getWebElementLocationAttribute(field, "y");
		int height_Field =getWebElementLocationAttribute(field, "height");
		int width_Field = getWebElementLocationAttribute(field, "width");

		int dragX_Field = xcord_Field + width_Field/2;
		int dragY_Field = ycord_Field + height_Field/2;

		WebElement webElement_HammerIcon = rootEle().findElement(hammerIcon);
		WebElement webElement_Field = rootEle().findElement(field);

		//ACTION.dragAndDrop(webElement_HammerIcon, webElement_Field).build().perform();
		//ACTION.dragAndDropBy(rootEle().findElement(hammerIcon), dragX_Field, dragY_Field).build().perform();
		//ACTION.moveToElement(webElement_HammerIcon).clickAndHold(webElement_HammerIcon).moveToElement(webElement_Field).release(webElement_Field).build().perform();
		//ACTION.moveToElement(webElement_HammerIcon).dragAndDrop(webElement_HammerIcon, webElement_Field).moveToElement(webElement_Field).release(webElement_Field).build().perform();
		//ACTION.clickAndHold(webElement_HammerIcon).moveByOffset(-1, -1).moveToElement(webElement_Field, dragX_Field, dragY_Field).release(webElement_Field).build().perform();

		ACTION.clickAndHold(webElement_HammerIcon).build().perform();
		Thread.sleep(1000);
		ACTION.moveToElement(webElement_Field).build().perform();
		Thread.sleep(1000);
		ACTION.moveByOffset(-1, -1).build().perform();
		Thread.sleep(1000);
		ACTION.release().build().perform();

		 */

		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
		engine.eval(Files.newBufferedReader(Paths.get("src\\test\\java\\com\\optum\\cpacosmosatdd\\ui\\utilities\\dragAndDropHTML5.js"), StandardCharsets.UTF_8));

		File file = new File("src\\test\\java\\com\\optum\\cpacosmosatdd\\ui\\utilities\\dragAndDrop.js");
		FileInputStream fileReader = new FileInputStream(file);
		byte[] arr = new byte[(int)file.length()];
		fileReader.read(arr);
		String script = new String(arr);

		fileReader.close();
		//Invocable inv = (Invocable) engine;

		//dnd_javascript = File.read(Dir.pwd + "/src/test/java/com/optum/cpacosmosatdd/ui/utilities/dragAndDrop.js");
		//@driver.execute_script(dnd_javascript+"$('#column-a').simulateDragDrop({ dropTarget: '#column-b'});")

		// call function from script file
		//inv.invokeFunction("simulateDragDrop", "");


		System.out.println(script);
		JAVASCRIPTEXECUTOR.executeScript(script, "#phyEntryContainer > div > div.DivNoPadding.col-xs-6 > div:nth-child(1) > imgx", "#physicianEntryAuditNumber" );

		//Thread.sleep(10000);
		waitForPageToLoad();
		return validateHammeredField(field);
	}

	/**
	 * To UnHammer a Input field
	 * 
	 * @param hammerIcon
	 * @param field
	 * @return
	 * @throws InterruptedException
	 */
	public boolean UnhammerField(By hammerIcon, By field) throws InterruptedException {
		waitForPageToLoad();
		//UnHammer Field
		ACTION.clickAndHold(rootEle().findElement(hammerIcon)).moveToElement(rootEle().findElement(field)).release().build().perform();	
		waitForPageToLoad();
		//Validate whether field is Concave
		return validateConcaveTextField(field);
	}

	/**
	 * To verify that Spell Check is disabled
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifySpellCheck() throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> textfieldsList = rootEle().findElements(By.xpath("//input[@type='text']"));
		for(WebElement webElement : textfieldsList) {
			if(isElementEnabled(webElement)) {
				String spellCheck = getAttributeValue(webElement, "spellcheck");
				if(!spellCheck.equalsIgnoreCase("false")) {
					Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + webElement + " has enabled Spell Check");
					return false;
				}
			}
		}
		Log.info("All the field's Spell Check is disabled");
		return true;
	}

	/**
	 * To verify that Spell Check is disabled
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifySpellCheck(By selector) throws InterruptedException {
		waitForPageToLoad();

		String spellCheck = rootEle().findElement(selector).getAttribute("spellcheck");
		if(spellCheck.equalsIgnoreCase("false")) {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " has disabled Spell Check");
			return true;
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " has enabled Spell Check");
			return false;
		}
	}

	/**
	 * To verify that Spell Check is disabled
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifySpellCheck(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();

		String spellCheck = webElement.getAttribute("spellcheck");
		if(spellCheck.equalsIgnoreCase("false")) {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + webElement + " has disabled Spell Check");
			return true;
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + webElement + " has enabled Spell Check");
			return false;
		}
	}

	/**
	 * To validate whether Resize icon is displayed or not
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifyResizeIcon() throws InterruptedException {
		waitForPageToLoad();

		try{
			if(rootEle().findElement(button_ResizeIcon).isDisplayed()) {
				Log.info("Resize Icon is displayed");
				return true;
			}	
		}
		catch(NoSuchElementException e) {
			Log.info("Resize Icon is not displayed");
			return false;
		}
		catch(Exception e) {
			Log.error("Resize Icon is not displayed");
			return false;
		}

		Log.error("Resize icon is not there");
		return false;
	}

	/**
	 * Validate the Cursor Style changes to Dual Arrow icon
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateCursorStyle() throws InterruptedException {
		waitForPageToLoad();
		mouseHover(button_ResizeIcon);
		waitForPageToLoad();
		if(getCursorStyle(button_ResizeIcon).equals("se-resize")){
			Log.info("Cursor Pointer changed to Dual Arrow icon");
			return true;
		}
		else{
			Log.error("Cursor Pointer not changed to Dual Arrow icon");
			return false;
		}
	}

	/**
	 * Validate the Cursor Style changes to Dual Arrow icon
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateCursorStyle(By selector) throws InterruptedException {
		waitForPageToLoad();
		mouseHover(selector);
		waitForPageToLoad();
		if(getCursorStyle(selector).equals("se-resize")){
			Log.info("Cursor Pointer changed to Dual Arrow icon");
			return true;
		}
		else {
			Log.error("Cursor Pointer not changed to Dual Arrow icon");
			return false;
		}
	}

	/**
	 * Validate the Cursor Style changes to Dual Arrow icon
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateCursorStyle(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();
		mouseHover(webElement);
		waitForPageToLoad();
		if(getCursorStyle(webElement).equals("se-resize")){
			Log.info("Cursor Pointer changed to Dual Arrow icon");
			return true;
		}
		else {
			Log.error("Cursor Pointer not changed to Dual Arrow icon");
			return false;
		}
	}

	/**
	 * To get the Max field length of the input field
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public int getInputFieldMaxLength(By selector) throws InterruptedException {
		waitForPageToLoad();
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + selector + " is found");
			return Integer.parseInt(rootEle().findElement(selector).getAttribute("maxlength"))-getInputFieldPlaceHolderLength(selector);
		}
		catch(NoSuchElementException e){
			Log.error("Field with selector as " + selector + "is not found on page");
			return 0;
		}
	}

	/**
	 * To get the Max field length of the input field
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public int getInputFieldMaxLength(WebElement webElement) throws InterruptedException {
		waitForPageToLoad();
		try{
			MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is found");
			return Integer.parseInt(webElement.getAttribute("maxlength"))-getInputFieldPlaceHolderLength(webElement);
		}
		catch(NoSuchElementException e){
			Log.error("Field with selector as " + webElement + "is not found on page");
			return 0;
		}
	}

	/**
	 * This function return the placeholder length
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public int getInputFieldPlaceHolderLength(By selector) throws InterruptedException {
		String placeHolder = getAttributeValue(selector, "placeholder");
		if(placeHolder.length()>0)	{
			placeHolder = placeHolder.replaceAll("\\s", "");
			placeHolder = placeHolder.replaceAll("0", "");
		}
		return placeHolder.length();
	}

	/**
	 * This function return the placeholder length
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public int getInputFieldPlaceHolderLength(WebElement webElement) throws InterruptedException {
		String placeHolder = getAttributeValue(webElement, "placeholder");
		if(placeHolder.length()>0)	{
			placeHolder = placeHolder.replaceAll("\\s", "");
			placeHolder = placeHolder.replaceAll("0", "");
		}
		return placeHolder.length();
	}

	/**
	 * Validate the Input Field Data Type (which all values it accepts)
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateInputFieldDataType(By selector, String fieldDataType) throws InterruptedException {		

		WebElement webElement = rootEle().findElement(selector);

		if(fieldDataType.equalsIgnoreCase("Numeric")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Numeric field");
				return false;
			}
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0 && getTextAlignment(selector).equalsIgnoreCase("Center")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric values only thus it is a Numeric field and is Center Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement +" is not accepting numeric values OR field value is not Center Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets")) {
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric value thus not a Alphabets field");
				return false;
			}
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0 && (getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start"))) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabetical values only thus it is a Alphabet field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting alphabetical values OR field value is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphanumeric")) {
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()<=0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting numeric value thus not a Alphanumeric field");
				return false;
			}
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()<=0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting alphabetical values thus not a Alphanumeric field");
				return false;
			}
			if(webElement.getAttribute("value").length()>0 && (getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start"))) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets and numeric values thus it is a Alphanumeric field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets and numeric values thus it is a Alphanumeric field but not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Date") ) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Date field");
				return false;
			}
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0 && getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric values only thus it is a Date field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting numeric values OR field value is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").equalsIgnoreCase("A")){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Decimal field");
				return false;
			}
			enterText(webElement, "1.0");
			System.out.println("field value"+ " "+ webElement.getAttribute("value") + " "+ getTextAlignment(selector));
			if(webElement.getAttribute("value").equalsIgnoreCase("1.00") && getTextAlignment(selector).equalsIgnoreCase("Right")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting Decimal values thus it is a Decimal field and is Right Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting Decimal values OR field value is not Right Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Units")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Decimal field");
				return false;
			}
			enterText(webElement, "1.0");
			if(webElement.getAttribute("value").equalsIgnoreCase("1.0") && getTextAlignment(selector).equalsIgnoreCase("Right")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting Decimal values thus it is a Decimal field and is Right Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting Decimal values OR field value is not Right Aligned");
				return false;
			}
		}
		else {
			Log.error("Please provide valid Field DataType value");
			return false;
		}	
	}

	/**
	 * Validate the Input Field Data Type (which all values it accepts)
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateInputFieldDataType(WebElement webElement, String fieldDataType) throws InterruptedException {		

		if(fieldDataType.equalsIgnoreCase("Numeric")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Numeric field");
				return false;
			}
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0 && getTextAlignment(webElement).equalsIgnoreCase("Center")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric values only thus it is a Numeric field and is Center Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting numeric values OR field value is not Center Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets")) {
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric value thus not a Alphabets field");
				return false;
			}
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0 && (getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start"))) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabetical values only thus it is a Alphabet field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting alphabetical values OR field value is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphanumeric")) {
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()<=0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting numeric value thus not a Alphanumeric field");
				return false;
			}
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()<=0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting alphabetical values thus not a Alphanumeric field");
				return false;
			}
			if(webElement.getAttribute("value").length()>0 && (getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start"))) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets and numeric values thus it is a Alphanumeric field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets and numeric values thus it is a Alphanumeric field but not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Date") ) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0) {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Date field");
				return false;
			}
			enterText(webElement, "1");
			if(webElement.getAttribute("value").length()>0 && getTextAlignment(webElement).equalsIgnoreCase("Left")|| getTextAlignment(webElement).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting numeric values only thus it is a Date field and is Left Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting numeric values OR field value is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Decimal field");
				return false;
			}
			enterText(webElement, "1.0");
			if(webElement.getAttribute("value").equalsIgnoreCase("1.00") && getTextAlignment(webElement).equalsIgnoreCase("Right")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting Decimal values thus it is a Decimal field and is Right Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting Decimal values OR field value is not Right Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Units")) {
			enterText(webElement, "a");
			if(webElement.getAttribute("value").length()>0){
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting alphabets thus not a Decimal field");
				return false;
			}
			enterText(webElement, "1.0");
			if(webElement.getAttribute("value").equalsIgnoreCase("1.0") && getTextAlignment(webElement).equalsIgnoreCase("Right")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is accepting Decimal values thus it is a Decimal field and is Right Aligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText()+" field with selector as " + webElement + " is not accepting Decimal values OR field value is not Right Aligned");
				return false;
			}
		}
		else {
			Log.error("Please provide valid Field DataType value");
			return false;
		}	
	}

	/**
	 * Validate the Flag Field Data Type (which all values it accepts)
	 * 
	 * @param selector
	 * @param validValue
	 * @param alignment
	 * @return boolean
	 * @throws InterruptedException
	 */
	public boolean validateFlagFieldDataType(By selector, String validValue, String alignment) throws InterruptedException {
		waitForPageToLoad();

		WebElement webElement = rootEle().findElement(selector);

		enterText(webElement, validValue);
		if(webElement.getAttribute("value").length()>0){
			Log.info(webElement + " Field is accepting valid value");
			if(getTextAlignment(webElement).equalsIgnoreCase(alignment)) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is accepting valid value and is "+alignment+" alligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not "+alignment+" alligned");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not accepting valid value");
			return false;
		}
	}

	/**
	 * Validate the Flag Field Data Type (which all values it accepts)
	 * 
	 * @param webElement
	 * @param validValue
	 * @param alignment
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateFlagFieldDataType(WebElement webElement, String validValue, String alignment) throws InterruptedException {
		waitForPageToLoad();

		enterText(webElement, validValue);
		if(webElement.getAttribute("value").length()>0){
			Log.info(webElement + " Field is accepting valid value");
			if(getTextAlignment(webElement).equalsIgnoreCase(alignment)) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is accepting valid value and is "+alignment+" alligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not "+alignment+" alligned");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not accepting valid value");
			return false;
		}
	}

	/**
	 * Validate the Flag Field Data Type (which all values it accepts)
	 * 
	 * @param selector
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDashFieldDataType(By selector, String validValue) throws InterruptedException {
		waitForPageToLoad();

		WebElement webElement = rootEle().findElement(selector);

		enterText(webElement, validValue);
		if(webElement.getAttribute("value").length()>0){
			Log.info(webElement + " Field is accepting valid value");
			if(getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is accepting valid value and is Left alligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not Left alligned");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not accepting valid value");
			return false;
		}

	}

	/**
	 * Validate the Flag Field Data Type (which all values it accepts)
	 * 
	 * @param webElement
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDashFieldDataType(WebElement webElement, String validValue) throws InterruptedException {
		waitForPageToLoad();

		enterText(webElement, validValue);
		if(webElement.getAttribute("value").length()>0){
			Log.info(webElement + " Field is accepting valid value");
			if(getTextAlignment(webElement).equalsIgnoreCase("Left")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is accepting valid value and is Left alligned");
				webElement.clear();
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not Left alligned");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " Field is not accepting valid value");
			return false;
		}

	}

	/**
	 * Validate that the Flag field accept the valid value(s)
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateFlagFieldValidValues(By selector, String fieldDataType,String validValue) throws InterruptedException {
		String[] listValues = validValue.split("\\|\\|");

		for(int i=0;i<listValues.length;i++) {
			if(!validateFlagFieldDataType(selector,fieldDataType,listValues[i])){
				Log.error(listValues[i]+" is not valid value for "+rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " input field");
				return false;
			}
		}

		Log.info(listValues+" are valid value(s) for "+rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " input field");
		return true;
	}

	/**
	 * Validate that the Flag field accept the valid value(s)
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateFlagFieldValidValues(WebElement webElement, String fieldDataType,String validValue) throws InterruptedException {
		String[] listValues = validValue.split("\\|\\|");

		for(int i=0;i<listValues.length;i++) {
			if(!validateFlagFieldDataType(webElement,fieldDataType,listValues[i])){
				Log.error(listValues[i]+" is not valid value for "+webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " input field");
				return false;
			}
		}

		Log.info(listValues+" are valid value(s) for "+webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " input field");
		return true;
	}

	/**
	 * Validate the Disabled Field Alignment
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledFieldDataType(By selector, String fieldDataType) throws InterruptedException {		

		if(fieldDataType.equalsIgnoreCase("Numeric")) {
			if(getTextAlignment(selector).equalsIgnoreCase("Center")) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Numeric field and is Center Aligned");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is not Center Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets")) {
			if(getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start")) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Alphabet field and is Left Aligned");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphanumeric")) {
			if(getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start")) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Alphanumeric field and is Left Aligned");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Alphanumeric field but not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Date") ) {
			if(getTextAlignment(selector).equalsIgnoreCase("Left") || getTextAlignment(selector).equalsIgnoreCase("Start")) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Date field and is Left Aligned");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			if( getTextAlignment(selector).equalsIgnoreCase("Right")) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is a Decimal field and is Right Aligned");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + selector + " is not Right Aligned");
				return false;
			}
		}
		else {
			Log.error("Please provide valid Field DataType value");
			return false;
		}	
	}

	/**
	 * Validate the Disabled Field Alignment
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDisabledFieldDataType(WebElement webElement, String fieldDataType) throws InterruptedException {		

		if(fieldDataType.equalsIgnoreCase("Numeric")) {
			if(getTextAlignment(webElement).equalsIgnoreCase("Center")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as " + webElement + " is a Numeric field and is Center Aligned");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is not Center Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets")) {
			if(getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is a Alphabet field and is Left Aligned");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Alphanumeric")) {
			if(getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is a Alphanumeric field and is Left Aligned");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is a Alphanumeric field but not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Date") ) {
			if(getTextAlignment(webElement).equalsIgnoreCase("Left") || getTextAlignment(webElement).equalsIgnoreCase("Start")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is a Date field and is Left Aligned");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is not Left Aligned");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			if( getTextAlignment(webElement).equalsIgnoreCase("Right")) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is a Decimal field and is Right Aligned");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " is not Right Aligned");
				return false;
			}
		}
		else {
			Log.error("Please provide valid Field DataType value");
			return false;
		}	
	}

	/**
	 * This function is to fill the Field to Max Length
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(By selector, String fieldDataType) throws InterruptedException{

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));
		String text;
		int maxLength = getInputFieldMaxLength(selector);

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") ||  fieldDataType.equalsIgnoreCase("Units") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}
		else if (fieldDataType.equalsIgnoreCase("Others")) {
			text = "B";
		}
		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		//Clear the Input field
		rootEle().findElement(selector).clear();
		KeyUtils.keyPressALT();
		mouseClick(selector);

		//Dismiss the Alert popup if displayed
		AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
		if(alertWindow.validateAlertPopupDisplayed()) {
			alertWindow.clickOnButton("Ok");
		}

		for(int i=0;i<maxLength;i++) {
			rootEle().findElement(selector).sendKeys(text);
		}
		if(getInputFieldPlaceHolderLength(selector)>0) {
			//rootEle().findElement(selector).sendKeys(text);
			maxLength = maxLength + getInputFieldPlaceHolderLength(selector);
		}

		if(rootEle().findElement(selector).getAttribute("value").length() == maxLength) {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is filled to MaxLength i.e. "+ maxLength);
			return true;
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not filled to MaxLength i.e. "+ maxLength);
			return false;
		}
	}

	/**
	 * This function is to fill the Field to Max Length
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(WebElement webElement, String fieldDataType) throws InterruptedException{

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		String text;
		int maxLength = getInputFieldMaxLength(webElement);

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") ||  fieldDataType.equalsIgnoreCase("Units") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}
		else if (fieldDataType.equalsIgnoreCase("Others")) {
			text = "B";
		}
		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		//Clear the Input field
		webElement.clear();
		KeyUtils.keyPressALT();
		mouseClick(webElement);

		//Dismiss the Alert popup if displayed
		AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
		if(alertWindow.validateAlertPopupDisplayed()) {
			alertWindow.clickOnButton("Ok");
		}

		for(int i=0;i<maxLength;i++) {
			webElement.sendKeys(text);
		}
		if(getInputFieldPlaceHolderLength(webElement)>0) {
			//rootEle().findElement(selector).sendKeys(text);
			maxLength = maxLength + getInputFieldPlaceHolderLength(webElement);
		}

		if(webElement.getAttribute("value").length() == maxLength) {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is filled to MaxLength i.e. "+ maxLength);
			return true;
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not filled to MaxLength i.e. "+ maxLength);
			return false;
		}
	}

	/**
	 * This function is to fill the Field to Max Length
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(By selector, String fieldDataType, String validValue) throws InterruptedException{

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));
		String text;
		int maxLength = getInputFieldMaxLength(selector);

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}
		else if (fieldDataType.equalsIgnoreCase("Others")) {
			text = validValue;
		}
		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		//Clear the Input field
		rootEle().findElement(selector).clear();
		KeyUtils.keyPressALT();
		mouseClick(selector);

		//Dismiss the Alert popup if displayed
		AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
		if(alertWindow.validateAlertPopupDisplayed()) {
			alertWindow.clickOnButton("Ok");
		}

		for(int i=0;i<maxLength;i++) {
			rootEle().findElement(selector).sendKeys(text);
		}

		if(getInputFieldPlaceHolderLength(selector)>0) {
			//rootEle().findElement(selector).sendKeys(text);
			maxLength = maxLength + getInputFieldPlaceHolderLength(selector);
		}

		if(rootEle().findElement(selector).getAttribute("value").length() == maxLength) {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is filled to MaxLength i.e. "+ maxLength);
			return true;
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not filled to MaxLength i.e. "+ maxLength);
			return false;
		}
	}

	/**
	 * This function is to fill the Field to Max Length
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(WebElement webElement, String fieldDataType, String validValue) throws InterruptedException{

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		String text;
		int maxLength = getInputFieldMaxLength(webElement);

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}
		else if (fieldDataType.equalsIgnoreCase("Others")) {
			text = validValue;
		}
		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		//Clear the Input field
		webElement.clear();
		KeyUtils.keyPressALT();
		mouseClick(webElement);

		//Dismiss the Alert popup if displayed
		AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
		if(alertWindow.validateAlertPopupDisplayed()) {
			alertWindow.clickOnButton("Ok");
		}

		for(int i=0;i<maxLength;i++) {
			webElement.sendKeys(text);
		}
		if(getInputFieldPlaceHolderLength(webElement)>0) {
			//rootEle().findElement(selector).sendKeys(text);
			maxLength = maxLength + getInputFieldPlaceHolderLength(webElement);
		}

		if(webElement.getAttribute("value").length() == maxLength) {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is filled to MaxLength i.e. "+ maxLength);
			return true;
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not filled to MaxLength i.e. "+ maxLength);
			return false;
		}
	}

	/** This function is to fill the Field to Max Length which is given
	 * 
	 * @param selector
	 * @param fieldChar
	 * @param length 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(By selector, String fieldDataType, int length) throws InterruptedException{
		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));
		String text;		

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}

		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));		
		if(rootEle().findElement(selector).isDisplayed()) {
			if(rootEle().findElement(selector).isEnabled()) {
				//Clear the Input field
				rootEle().findElement(selector).clear();
				KeyUtils.keyPressALT();
				mouseClick(selector);

				//Dismiss the Alert popup if displayed
				AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
				if(alertWindow.validateAlertPopupDisplayed()) {
					alertWindow.clickOnButton("Ok");
				}

				for(int i=0;i<length;i++) {
					rootEle().findElement(selector).sendKeys(text);
				}
				if(rootEle().findElement(selector).getText().length() == length) {
					Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field is filled to Max");
					return true;
				}
				else {
					Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not filled to Max");
					return false;
				}
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not enabled");
				return false;
			}
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not displayed");
			return false;
		}
	}

	/** This function is to fill the Field to Max Length which is given
	 * 
	 * @param webElement
	 * @param fieldChar
	 * @param length 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputFieldToMax(WebElement webElement, String fieldDataType, int length) throws InterruptedException{
		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		String text;		

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}

		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));		
		if(webElement.isDisplayed()) {
			if(webElement.isEnabled()) {
				//Clear the Input field
				webElement.clear();
				KeyUtils.keyPressALT();				
				mouseClick(webElement);

				//Dismiss the Alert popup if displayed
				AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
				if(alertWindow.validateAlertPopupDisplayed()) {
					alertWindow.clickOnButton("Ok");
				}

				for(int i=0;i<length;i++) {
					webElement.sendKeys(text);
				}
				if(webElement.getText().length() == length) {
					Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field is filled to Max");
					return true;
				}
				else {
					Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not filled to Max");
					return false;
				}
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not enabled");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field is not displayed");
			return false;
		}
	}

	/**
	 * This function is to fill the Field to Max Length which is given
	 * 
	 * @param selector
	 * @param fieldDataType
	 * @param length
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputField(By selector, String fieldDataType, int length) throws InterruptedException{
		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));
		String text;
		String data = "";

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}

		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(selector));		
		if(rootEle().findElement(selector).isDisplayed()) {
			if(rootEle().findElement(selector).isEnabled()) {
				rootEle().findElement(selector).clear();
				KeyUtils.keyPressALT();
				//Dismiss the Alert popup if displayed
				AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
				if(alertWindow.validateAlertPopupDisplayed()) {
					alertWindow.clickOnButton("Ok");
				}
				mouseClick(selector);
				for(int i=0;i<length;i++) {
					rootEle().findElement(selector).sendKeys(text);
					data = data + text;
				}
				Log.info("Field is filled with "+data);
				return true;
			}
			else {
				Log.error("Field is not enabled");
				return false;
			}
		}
		else {
			Log.error("Field is not displayed");
			return false;
		}
	}

	/**
	 * This function is to fill the Field to Max Length which is given
	 * 
	 * @param webElement
	 * @param fieldDataType
	 * @param length
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fillInputField(WebElement webElement, String fieldDataType, int length) throws InterruptedException{
		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		String text;
		String data = "";

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Decimal") || fieldDataType.equalsIgnoreCase("Date")) {
			text = "" + 1;
		}
		else if(fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("AlphaNumeric")) {
			text = "a";
		}
		else if(fieldDataType.equalsIgnoreCase("Flag")) {
			text = "Y";
		}

		else {
			Log.error("Please mention valid Field Type");
			return false;
		}

		MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));		
		if(webElement.isDisplayed()) {
			if(webElement.isEnabled()) {
				webElement.clear();
				KeyUtils.keyPressALT();
				//Dismiss the Alert popup if displayed
				AlertPopUpWindow  alertWindow= new AlertPopUpWindow();
				if(alertWindow.validateAlertPopupDisplayed()) {
					alertWindow.clickOnButton("Ok");
				}
				mouseClick(webElement);
				for(int i=0;i<length;i++) {
					webElement.sendKeys(text);
					data = data + text;
				}
				Log.info("Field is filled with "+data);
				return true;
			}
			else {
				Log.error("Field is not enabled");
				return false;
			}
		}
		else {
			Log.error("Field is not displayed");
			return false;
		}
	}

	/**
	 * Validate the Error message displayed on a page
	 * 
	 * @param selector
	 * @param errorMessage
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateErrorMessage(By selector, String errorMessage) throws InterruptedException {
		waitForPageToLoad();
		try {
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			String actualErrorMessage = rootEle().findElement(selector).getAttribute("value");
			if(actualErrorMessage.equals(errorMessage)) {
				Log.info("Error Message matched i.e. " + errorMessage);
				return true;
			}
			else {
				Log.error("Error Message not matched. Expected: " + errorMessage + ". Actual: "+actualErrorMessage);
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error("Error Message Bar is not displayed");
			return false;
		}
		catch (Exception e) {
			Log.error("Error Message Bar is not displayed");
			return false;
		}
	}

	/**
	 * Validate if Data is present in a Input Field
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDataPresentInInputField(By selector) throws InterruptedException {
		if(getAttributeValue(selector,"value").length()>0) {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is not blank");
			return true;
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is blank");
			return false;
		}
	}	

	/**
	 * Validate if Data is present in a Input Field
	 * 
	 * @param selector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDataPresentInInputFieldByFieldDataType(By selector, String fieldDataType) throws InterruptedException {

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("Alphanumeric") || fieldDataType.equalsIgnoreCase("Date") || fieldDataType.equalsIgnoreCase("Flag")) {
			if(getAttributeValue(selector,"value").length()>0) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is not blank");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is blank");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			if(getAttributeValue(selector,"value").length()>4) {
				Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is not blank");
				return true;
			}
			else {
				Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " is blank");
				return false;
			}
		}
		else {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector + " has Unknown Field Data Type "+fieldDataType );
			return false;
		}
	}

	/**
	 * Validate if Data is present in a Input Field
	 * 
	 * @param webElement
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateDataPresentInInputFieldByFieldDataType(WebElement webElement, String fieldDataType) throws InterruptedException {

		if(fieldDataType.equalsIgnoreCase("Numeric") || fieldDataType.equalsIgnoreCase("Alphabets") || fieldDataType.equalsIgnoreCase("Alphanumeric") || fieldDataType.equalsIgnoreCase("Date")) {
			if(getAttributeValue(webElement,"value").length()>0) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not blank");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement + " is blank");
				return false;
			}
		}
		else if(fieldDataType.equalsIgnoreCase("Decimal")) {
			if(getAttributeValue(webElement,"value").length()>4) {
				Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not blank");
				return true;
			}
			else {
				Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is blank");
				return false;
			}
		}
		else {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement + " has Unknown Field Data Type "+fieldDataType );
			return false;
		}
	}

	/**
	 * Click on button with Button name
	 * 
	 * @param buttonName
	 * @return
	 * @throws InterruptedException
	 */
	public boolean clickOnButton(String buttonName) throws InterruptedException {
		waitForPageToLoad();
		List<WebElement> buttonList = rootEle().findElements(By.xpath("//button"));
		for(WebElement webElement:buttonList) {
			if(webElement.getText().trim().equalsIgnoreCase(buttonName)) {
				if(isElementEnabled(webElement)) {
					webElement.click();
					Log.info("Clicked on "+buttonName+" button");
					return true; 
				}
				else {
					Log.error(buttonName+" button is not enabled");
					return false;
				}
			}
		}
		Log.error("Button with "+buttonName+" is not found");
		return false;
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue
	 * 														 				
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		KeyUtils.keyPressALT();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(selector);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(selector).substring(0, getInputFieldMaxLength(selector)+getInputFieldPlaceHolderLength(selector)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(selector).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;		
		}
	}
	
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBluePopUp(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		KeyUtils.keyPressTab();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(selector);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(selector).substring(0, getInputFieldMaxLength(selector)+getInputFieldPlaceHolderLength(selector)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(selector).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;		
		}
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue
	 * 													 				
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(WebElement webElement, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType);
		KeyUtils.keyPressALT();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(webElement);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(webElement).substring(0, getInputFieldMaxLength(webElement)+getInputFieldPlaceHolderLength(webElement)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(webElement).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;
		}
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue
	 * 													 				
	 * @param selector
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(By selector, String fieldDataType, String validValue) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType, validValue);
		KeyUtils.keyPressALT();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(selector);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(selector).substring(0, getInputFieldMaxLength(selector)+getInputFieldPlaceHolderLength(selector)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(selector).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;
		}	
	}	

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue
	 * 													 				
	 * @param webElement
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(WebElement webElement, String fieldDataType, String validValue) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType, validValue);
		KeyUtils.keyPressALT();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(webElement);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(webElement).substring(0, getInputFieldMaxLength(webElement)+getInputFieldPlaceHolderLength(webElement)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(webElement).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;
		}		
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue
	 * 													 				
	 * @param selector
	 * @param fieldDataType
	 * @param length
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(By selector, String fieldDataType, int length) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType, length);
		KeyUtils.keyPressALT();
		String expectedValue = null;
		String actualValue = null;
		mouseClick(selector);
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(selector).substring(0, getInputFieldMaxLength(selector)+getInputFieldPlaceHolderLength(selector)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(selector).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;
		}	
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue for Pop up
	 * 															 				
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlueForPopUp(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		String expectedValue = null;
		String actualValue = null;
		KeyUtils.keyPressTab();
		KeyUtils.keyPressShiftPlusTab();
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(selector).substring(0, getInputFieldMaxLength(selector)+getInputFieldPlaceHolderLength(selector)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(selector).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;		
		}
	}

	/**
	 * Validate Backspace Functionality when data is not Highlighted in Blue for Pop up
	 * 															 				
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlueForPopUp(WebElement webElement, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType);
		String expectedValue = null;
		String actualValue = null;
		KeyUtils.keyPressTab();
		KeyUtils.keyPressShiftPlusTab();
		KeyUtils.keyPressRightArrow();
		expectedValue = getFieldValue(webElement).substring(0, getInputFieldMaxLength(webElement)+getInputFieldPlaceHolderLength(webElement)-1);		
		KeyUtils.keyPressBackspace();
		actualValue = getFieldValue(webElement).replaceAll("0", "").trim();
		if(!actualValue.equals(expectedValue)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is not Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is not Highlighted in Blue");
			return true;		
		}
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue
	 * 															 				
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		KeyUtils.keyPressALT();
		mouseClick(selector);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(selector,fieldDataType)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}		
	}
	
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBluePopUp(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		KeyUtils.keyPressTab();
		mouseClick(selector);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(selector,fieldDataType)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}		
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue
	 * 															 				
	 * @param selector
	 * @param fieldDataType
	 * @param length
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue(By selector, String fieldDataType, int length) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType, length);
		KeyUtils.keyPressALT();
		mouseClick(selector);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(selector,fieldDataType)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}			
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue
	 * 														 				
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue(WebElement webElement, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType);
		KeyUtils.keyPressALT();
		mouseClick(webElement);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(webElement, fieldDataType)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue
	 * 													 				
	 * @param selector
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue(By selector, String fieldDataType, String validValue) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType, validValue);
		KeyUtils.keyPressALT();
		mouseClick(selector);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(selector, fieldDataType)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue
	 * 													 				
	 * @param webElement
	 * @param fieldDataType
	 * @param validValue
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue(WebElement webElement, String fieldDataType, String validValue) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType, validValue);
		KeyUtils.keyPressALT();
		mouseClick(webElement);
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(webElement, fieldDataType)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue for Pop up
	 * 															 				
	 * @param selector
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlueForPopUp(By selector, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(selector, fieldDataType);
		KeyUtils.keyPressTab();
		KeyUtils.keyPressShiftPlusTab();
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(selector,fieldDataType)) {
			Log.error(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(rootEle().findElement(selector).findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ selector +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}		
	}

	/**
	 * Validate Backspace Functionality when Data is Highlighted in Blue for Pop up
	 * 															 				
	 * @param webElement
	 * @param fieldDataType
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlueForPopUp(WebElement webElement, String fieldDataType) throws InterruptedException {
		fillInputFieldToMax(webElement, fieldDataType);
		KeyUtils.keyPressTab();
		KeyUtils.keyPressShiftPlusTab();
		KeyUtils.keyPressBackspace();
		if(validateDataPresentInInputFieldByFieldDataType(webElement,fieldDataType)) {
			Log.error(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is not validated for Backspace Functionality when data is Highlighted in Blue");
			return false;	
		}
		else {
			Log.info(webElement.findElement(By.xpath(".//preceding::label[1]")).getText() + " field with selector as "+ webElement +" is validated for Backspace Functionality when data is Highlighted in Blue");
			return true;
		}		
	}

	/**
	 * Validate the highlighted option(in blue) of a drop down
	 * 
	 * @param selector
	 * @param optionName
	 * @return
	 */
	public boolean validateHighlightedOption(By selector, String optionName){
		try {
			waitForPageToLoad();
			WebElement option = rootEle().findElement(selector).findElement(By.xpath(".//li//span[contains(text(),'"+optionName+"')]"));
			WebElement option_Anchor = rootEle().findElement(selector).findElement(By.xpath(".//li//span[contains(text(),'"+optionName+"')]//parent::a"));
			if(isElementDisplayed(option) && isElementDisplayed(option_Anchor)) {
				System.out.println(getBackgroundColor(option_Anchor));
				if(getBackgroundColor(option_Anchor).equalsIgnoreCase("rgba(30, 143, 255, 1)")) {
					Log.info("Option with text "+ optionName +" is highlighted in blue");
					return true;
				}
				else {
					Log.error("Option with text "+ optionName +" is not highlighted in blue");
					return false;
				}
			}
			else {
				Log.error("Option with text "+ optionName +" is not displayed");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error("Option with text "+ optionName +" not found");
			return false;
		}
		catch(Exception e) {
			Log.error("Exception found with "+ optionName +" option webelement");
			return false;
		}
	}

	/**
	 * Validate the highlighted option(in blue) of a drop down
	 * 
	 * @param webElement
	 * @param optionName
	 * @return
	 */
	public boolean validateHighlightedOption(WebElement webElement, String optionName){
		try {
			waitForPageToLoad();
			WebElement option = webElement.findElement(By.xpath(".//li//span[contains(text(),'"+optionName+"')]"));
			WebElement option_Anchor = webElement.findElement(By.xpath(".//li//span[contains(text(),'"+optionName+"')]//parent::a"));
			if(isElementDisplayed(option) && isElementDisplayed(option_Anchor)) {
				System.out.println(getBackgroundColor(option_Anchor));
				if(getBackgroundColor(option_Anchor).equalsIgnoreCase("rgba(30, 143, 255, 1)")) {
					Log.info("Option with text "+ optionName +" is highlighted in blue");
					return true;
				}
				else {
					Log.error("Option with text "+ optionName +" is not highlighted in blue");
					return false;
				}
			}
			else {
				Log.error("Option with text "+ optionName +" is not displayed");
				return false;
			}
		}
		catch(NoSuchElementException e) {
			Log.error("Option with text "+ optionName +" not found");
			return false;
		}
		catch(Exception e) {
			Log.error("Exception found with "+ optionName +" option webelement");
			return false;
		}
	}

	/**
	 * Return the List of WebElement
	 * 
	 * @param identifier
	 * @return
	 */
	public List<String> getWebElementList(String identifier){
		By labels = By.xpath(identifier);
		List<String> act_Values = new ArrayList<String>();
		try{
			List<WebElement> lst = rootEle().findElements(labels);

			for(WebElement ele:lst){
				if(ele.getText()!=null){
					act_Values.add(ele.getText().trim());
				}
			}
			Log.info("Actual Values are:" +" "+ act_Values);
			Log.info("Total number of values are:"+ " " + act_Values.size());
		}
		catch(Exception e){
			e.printStackTrace();
			Log.error(e + " error occurred in returnTheList function");
			Assert.fail();
		}
		return act_Values;
	}

	/**
	 * Return the List of WebElement
	 * 
	 * @param selector
	 * @return
	 */
	public List<String> getWebElementList(By selector){
		List<String> act_Values = new ArrayList<String>();
		try{
			List<WebElement> lst = rootEle().findElements(selector);

			for(WebElement ele:lst){
				if(ele.getText()!=null){
					act_Values.add(ele.getText().trim());
				}
			}
			Log.info("Actual Values are:" +" "+ act_Values);
			Log.info("Total number of values are:"+ " " + act_Values.size());
		}
		catch(Exception e){
			e.printStackTrace();
			Log.error(e + " error occurred in returnTheList function");
			Assert.fail();
		}
		return act_Values;
	}

	/**
	 * Click on element
	 * 
	 * @param selector
	 * @param Button_Name
	 */
	public void clickOnElement(By selector, String Button_Name){
		try{
			waitForPageToLoad();
			if(driver.findElement(selector).isEnabled()){
				driver.findElement(selector).click();
				System.out.println(Button_Name + " " + "is clicked");
				waitForPageToLoad();
			}
		}
		catch(Exception e){
			Log.error("Button not clicked due to element not found");
			e.printStackTrace();
			Assert.fail();
		}
	}

	/**
	 * Validate that table column underlined
	 * 
	 * @param field
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateTable_HeaderUnderlinedAndNotBolded_ByLocator(String locator, String labels) throws InterruptedException {

		waitForPageToLoad();

		List<WebElement> listWebElements = rootEle().findElements(By.xpath(locator));
		System.out.println("Number of Element from UI:" + " " + listWebElements.size() );

		String arrLabels[] = labels.split("\\|\\|");
		System.out.println("Number of elements from Excel"+ " " + arrLabels.length);

		for(WebElement webElement:listWebElements) {
			if(webElement.getText().trim().equals(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					Assert.assertTrue(getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)"));
					Log.info(webElement.getText()+" "+ "color is black");
					Assert.assertTrue(getFontSize(webElement).equalsIgnoreCase("10px"));
					Log.info(webElement.getText()+" "+ "Size is 10px");
					Assert.assertTrue(getFontType(webElement).equalsIgnoreCase("Verdana"));
					Log.info(webElement.getText()+" "+ "font is Verdana");
					Assert.assertTrue(getFontWeight(webElement).equalsIgnoreCase("400"));
					Log.info(webElement.getText()+" " +"Text is non bolded");
					Assert.assertTrue(getFontDecorationColor(webElement).equalsIgnoreCase("rgb(0, 0, 0)"));
					Log.info(webElement.getText()+" " +"Underline color is black");
					Assert.assertTrue(getFontDecorationLine(webElement).equalsIgnoreCase("underline"));
					Log.info(webElement.getText()+" " +"Text is underlined");
					Assert.assertTrue(getFontDecorationStyle(webElement).equalsIgnoreCase("solid"));
					Log.info(webElement.getText()+" " +"Underline text is Solid");

				}
			}
		}
		return true;

	}

	/**
	 * 
	 * 
	 * @param selector
	 * @param Field_Name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateHighligtedTextFieldByID (By selector,String Field_Name) throws InterruptedException {
		try{
			waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {
					String border_Color = rootEle().findElement(selector).getCssValue("border-color");
					Log.info("Border color is :"+ " " + border_Color);
					String Field_id = rootEle().findElement(selector).getAttribute("id");
					Log.info("Field name is :"+ " " + Field_id);
					if(border_Color.equalsIgnoreCase("rgb(0, 0, 0)") && Field_id.contains(Field_Name))
					{
						Log.info(Field_Name+ " "+ "text field"+ " "+ "is highlighted");
						return true;
					}
					else
					{
						Log.error(Field_Name+ " "+ "text field"+ " "+ "is not highlighted");
						Assert.fail();
					}
				}
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector +" selector is not found in DOM");
			return false;
		}
		return true;
	}

	/**
	 * 
	 * 
	 * @param selector
	 * @param Field_Name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateFocusedOnElement (By selector,String Field_Name) throws InterruptedException {
		try{
			waitForPageToLoad();
			MIDDRIVERWAIT.until(ExpectedConditions.presenceOfElementLocated(selector));
			if(rootEle().findElement(selector).isDisplayed()) {
				if(rootEle().findElement(selector).isEnabled()) {

					if(rootEle().findElement(selector).equals(driver.switchTo().activeElement()))
					{
						Log.info(Field_Name+ " "+ "text field"+ " "+ "is highlighted");
						return true;
					}
					else
					{
						Log.error(Field_Name+ " "+ "text field"+ " "+ "is not highlighted");
						Assert.fail();
					}
				}
			}
		}
		catch(NoSuchElementException e){
			Log.error(selector +" selector is not found in DOM");
			return false;
		}
		return true;
	}

	/**
	 * To Enter text in a Input Field
	 * 
	 * @param webElement
	 * @param text
	 * @throws InterruptedException 
	 */
	public void enterTextUsingLeftMovement(WebElement webElement, String text) throws InterruptedException {
		WebElement element = MIDDRIVERWAIT.until(ExpectedConditions.elementToBeClickable(webElement));
		element.clear();
		for(int i=0;i<4;i++)
			KeyUtils.keyPressLeftArrow();
		element.sendKeys(text);
	}

	/**
	 * This function is to verify Tabbing Order functionality
	 * 
	 * @param listSelectors
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateTabbingOrder_Selector(List<By> listSelectors) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		mouseClick(listSelectors.get(0));
		for(int i=0;i<listSelectors.size();i++) {
			if(!validateHighligtedTextField(listSelectors.get(i)))
				return false;
			else{
				count = count + 1;
				KeyUtils.keyPressTab();
			}
		}
		if(count==listSelectors.size()){
			Log.info("Tabbing Order fucntionality verified for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Tabbing Order fucntionality is not working fine for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * This function is to verify Tabbing Order functionality
	 * 
	 * @param listWebElements
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateTabbingOrder_WebElement(List<WebElement> listWebElements) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		mouseClick(listWebElements.get(0));
		for(int i=0;i<listWebElements.size();i++) {
			if(!validateHighligtedTextField(listWebElements.get(i)))
				return false;
			else{
				count = count + 1;
				KeyUtils.keyPressTab();
			}
		}
		if(count==listWebElements.size()){
			Log.info("Tabbing Order fucntionality verified for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Tabbing Order fucntionality is not working fine for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * This function is to verify Reverse Tabbing Order functionality
	 * 
	 * @param listSelectors
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateReverseTabbingOrder_Selector(List<By> listSelectors) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		mouseClick(listSelectors.get(listSelectors.size()-1));
		for(int i=listSelectors.size()-1;i>=0;i--) {
			if(!validateHighligtedTextField(listSelectors.get(i)))
				return false;
			else{
				count = count + 1;
				KeyUtils.keyPressShiftPlusTab();
			}
		}
		if(count==listSelectors.size()){
			Log.info("Reverse Tabbing Order fucntionality verified for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Reverse Tabbing Order fucntionality is not working fine for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * This function is to verify Reverse Tabbing Order functionality
	 * 
	 * @param listWebElements
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateReverseTabbingOrder_WebElement(List<WebElement> listWebElements) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		mouseClick(listWebElements.get(listWebElements.size()-1));
		for(int i=listWebElements.size()-1;i>=0;i--) {
			if(!validateHighligtedTextField(listWebElements.get(i)))
				return false;
			else{
				count = count + 1;
				KeyUtils.keyPressShiftPlusTab();
			}
		}
		if(count==listWebElements.size()){
			Log.info("Reverse Tabbing Order fucntionality verified for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Reverse Tabbing Order fucntionality is not working fine for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * This function is to verify Spell Check
	 * 
	 * @param listSelectors
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifySpellCheck_Selector(List<By> listSelectors) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		for(int i=0;i<listSelectors.size();i++) {
			if(!verifySpellCheck(listSelectors.get(i)))
				return false;
			else{
				count = count + 1;
			}
		}
		if(count==listSelectors.size()){
			Log.info("Spell Check is diabled for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Spell Check is not disabled for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * This function is to verify Spell Check
	 * 
	 * @param listWebElements
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifySpellCheck_WebElement(List<WebElement> listWebElements) throws InterruptedException{
		waitForPageToLoad();
		int count = 0;
		for(int i=0;i<listWebElements.size();i++) {
			if(!verifySpellCheck(listWebElements.get(i)))
				return false;
			else{
				count = count + 1;
			}
		}
		if(count==listWebElements.size()){
			Log.info("Spell Check is disabled for the mentioned list of web elements");
			return true;
		}
		else {
			Log.error("Spell Check is not disabled for the mentioned list of web elements");
			return false;
		}
	}

	/**
	 * Validate Arrow Key functionality in Drop Down
	 * 
	 * @param selectElementID
	 * @param buttonSelector
	 * @param listSelector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean ArrowKeyFunctionalityOnDropDown(By selectElementID, By buttonSelector, By listSelector) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> options = new Select(rootEle().findElement(selectElementID)).getOptions();
		//Check if Drop down has more than 1 option
		switch(options.size()) {
		case 0: 
			Log.info("There is no value in dropdown so cannot check arrow functionality");
			return true;
		case 1: 
			Log.info("There is only 1 value in dropdown so cannot check arrow functionality");
			return true;
		}

		//Select 1st option
		new Select(rootEle().findElement(selectElementID)).selectByVisibleText(options.get(0).getText());
		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(0).getText()))
			return false;

		mouseClick(buttonSelector);
		KeyUtils.keyPressDownArrow();
		if(!validateHighlightedOption(listSelector, options.get(1).getText()))
			return false;
		KeyUtils.keyPressUpArrow();
		if(!validateHighlightedOption(listSelector, options.get(0).getText()))
			return false;
		KeyUtils.keyPressDownArrow();
		KeyUtils.keyPressEnter();

		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(1).getText())) {
			Log.error("Arrow key functionality on Drop down is not working as expected");
			return false;
		}

		Log.info("Arrow key functionality on Drop down is working as expected");
		return true;
	}

	/**
	 * Validate Letter Functionality in Drop Down
	 * 
	 * @param selectElementID
	 * @param buttonSelector
	 * @param listSelector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLetterFunctionality(By selectElementID, By buttonSelector, By listSelector) throws InterruptedException {		
		waitForPageToLoad();

		List<WebElement> options = new Select(rootEle().findElement(selectElementID)).getOptions();
		//Check if Drop down has more than 1 option
		switch(options.size()) {
		case 0: 
			Log.info("There is no value in dropdown so cannot check Letter functionality");
			return true;
		case 1: 
			Log.info("There is only 1 value in dropdown so cannot check Letter functionality");
			return true;
		}

		//Select 1st option
		new Select(rootEle().findElement(selectElementID)).selectByVisibleText(options.get(0).getText());
		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(0).getText()))
			return false;

		mouseClick(buttonSelector);
		KeyUtils.keyPressAlone(options.get(1).getText().substring(0,1));
		if(!validateHighlightedOption(listSelector, options.get(1).getText()))
			return false;
		KeyUtils.keyPressAlone(options.get(0).getText().substring(0,1));
		if(!validateHighlightedOption(listSelector, options.get(0).getText()))
			return false;
		KeyUtils.keyPressAlone(options.get(1).getText().substring(0,1));
		if(!validateHighlightedOption(listSelector, options.get(1).getText()))
			return false;
		KeyUtils.keyPressEnter();
		waitForPageToLoad();

		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(1).getText())) {
			Log.error("Letter functionality on Drop down is not working as expected");
			return false;
		}

		Log.info("Letter functionality on Drop down is working as expected");
		return true;
	}

	/**
	 * Validate ALT plus Down Functionality in Drop Down
	 * 
	 * @param selectElementID
	 * @param buttonSelector
	 * @param listSelector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateAltPlusDownFunctionality(By selectElementID, By buttonSelector, By listSelector) throws InterruptedException {		
		waitForPageToLoad();

		List<WebElement> options = new Select(rootEle().findElement(selectElementID)).getOptions();
		//Check if Drop down has options or not
		if(options.size()<1) {
			Log.info("There is no value in dropdown so cannot check ALT plus Down functionality");
			return true;
		}

		//Select 1st option
		new Select(rootEle().findElement(selectElementID)).selectByVisibleText(options.get(0).getText());
		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(0).getText()))
			return false;

		mouseClick(buttonSelector);
		KeyUtils.keyPressEsc();
		KeyUtils.keyPressALTPlusDownArrow();
		if(!validateHighlightedOption(listSelector, options.get(0).getText())) {
			Log.error("ALT Plus Down functionality on Drop down is not working as expected");
			return false;
		}

		Log.info("ALT Plus Down functionality on Drop down is working as expected");
		return true;
	}

	/**
	 * Validate Arrow Key functionality in Drop Down
	 * 
	 * @param selectElementID
	 * @param buttonSelector
	 * @param listSelector
	 * @return
	 * @throws InterruptedException
	 */
	public boolean cycleThroughDropDown(By selectElementID, By buttonSelector, By listSelector) throws InterruptedException {
		waitForPageToLoad();

		List<WebElement> options = new Select(rootEle().findElement(selectElementID)).getOptions();
		//Check if Drop down has more than 1 option
		switch(options.size()) {
		case 0: 
			Log.info("There is no value in dropdown so cannot check cycle functionality");
			return true;
		case 1: 
			Log.info("There is only 1 value in dropdown so cannot check cycle functionality");
			return true;
		}

		//Select 1st option
		new Select(rootEle().findElement(selectElementID)).selectByVisibleText(options.get(0).getText());
		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(0).getText()))
			return false;

		mouseClick(buttonSelector);
		if(!validateHighlightedOption(listSelector, options.get(0).getText()))
			return false;
		KeyUtils.keyPressUpArrow();
		if(!validateHighlightedOption(listSelector, options.get(options.size()-1).getText()))
			return false;
		KeyUtils.keyPressDownArrow();
		if(!validateHighlightedOption(listSelector, options.get(0).getText()))
			return false;
		KeyUtils.keyPressUpArrow();
		KeyUtils.keyPressEnter();

		if(!getText(new Select(rootEle().findElement(selectElementID)).getFirstSelectedOption()).equalsIgnoreCase(options.get(options.size()-1).getText())) {
			Log.error("Cycle through Drop down functionality is not working as expected");
			return false;
		}

		Log.info("Cycle through Drop down functionality is working as expected");
		return true;
	}

	public boolean underlinedHeaderValidation(List<WebElement> ele)
	{
		try
		{
			for(WebElement e:ele)
			{
				Assert.assertTrue(e.getCssValue("font-weight").equals("400"), "Failed:"+" "+e.getText()+" "+ "Header font weight does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font weight follows the UI standard");
				Assert.assertTrue(e.getCssValue("font-size").equals("10px"), "Failed:"+" "+e.getText()+" "+ "Header font Size does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font size follows the UI standard");
				Assert.assertTrue(e.getCssValue("font-family").equals("verdana"), "Failed:"+" "+e.getText()+" "+ "Header font family does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font family follows the UI standard");
				Assert.assertTrue(e.getCssValue("text-decoration-line").equals("underline"), "Failed:"+" "+e.getText()+" "+ "Header font Decoration does not follow the UI standard");
				com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+e.getText()+" "+ "Header font decoration follows the UI standard");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean underlinedLabelsValidation(List<WebElement> Act_ValuesEle, List<String> Exp_Values)
	{
		int count =0;

		try
		{
			for(WebElement ele:Act_ValuesEle)
			{
				if(Exp_Values.contains(ele.getText()))
				{
					System.out.println("Actual label:"+ " "+ ele.getText());
					Assert.assertTrue(ele.getCssValue("font-weight").equals("400"), "Failed:"+" "+ele.getText()+" "+ "Header font weight does not follow the UI standard");
					com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+ele.getText()+" "+ "Header font weight follows the UI standard");
					Assert.assertTrue(ele.getCssValue("font-size").equals("10px"), "Failed:"+" "+ele.getText()+" "+ "Header font Size does not follow the UI standard");
					com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+ele.getText()+" "+ "Header font size follows the UI standard");
					Assert.assertTrue(ele.getCssValue("font-family").equals("verdana"), "Failed:"+" "+ele.getText()+" "+ "Header font family does not follow the UI standard");
					com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+ele.getText()+" "+ "Header font family follows the UI standard");
					Assert.assertTrue(ele.getCssValue("text-decoration-line").equals("underline"), "Failed:"+" "+ele.getText()+" "+ "Header font Decoration does not follow the UI standard");
					com.optum.mrcpcosmosatdd.reporting.Log.info("Passed:"+" "+ele.getText()+" "+ "Header font decoration follows the UI standard");	
					count++;

				}
			}
			Assert.assertTrue(count==Exp_Values.size(), "Failed: Underlined labels not matching");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;


	}

	/**
	 * Validate Labels Standards on the page sent in String Parameter (Labels should be separated by || operator)
	 * 
	 * @param labels
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateLabelsStandardsOnPageforCOB(String labels) throws InterruptedException {
		waitForPageToLoad();	

		List<WebElement> listWebElements_Label = rootEle().findElements(By.tagName("label"));
		List<WebElement> listWebElements_Span = rootEle().findElements(By.tagName("span"));		
		listWebElements_Label.addAll(listWebElements_Span);

		String arrLabels[] = labels.split("\\|\\|");
		int count = 0;

		for(WebElement webElement:listWebElements_Label) {
			if(webElement.getText().trim().equalsIgnoreCase(""))
				continue;
			for(int i=0;i<arrLabels.length;i++) {
				if(webElement.getText().trim().equals(arrLabels[i])) {
					count = count+1;
					if(!getFontColor(webElement).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
						Log.error(webElement.getText()+" webelement's Font Color doesn't pass the UI Validations");
						return false;
					}
					if(!getFontSize(webElement).equalsIgnoreCase("10px")) {
						Log.error(webElement.getText()+" webelement's Font Size doesn't pass the UI Validations");
						return false;
					}
					if(!getFontType(webElement).equalsIgnoreCase("Verdana")) {
						Log.error(webElement.getText()+" webelement's Font Type doesn't pass the UI Validations");
						return false;
					}
					if(!getFontWeight(webElement).equalsIgnoreCase("400")) {
						Log.error(webElement.getText()+" webelement's Font Weight doesn't pass the UI Validations");
						return false;
					}
					break;
				}
			}
		}
		if(arrLabels.length==count) {
			Log.info("Labels validated");
			return true;
		}
		else {
			Log.error("All Labels not validated");
			return false;
		}
	}


	/**
	 * Validate Buttons Standards on the page sent in String Parameter
	 * 
	 * @param Buttons
	 * @return
	 * @throws InterruptedException
	 */
	public boolean validateButtonStandards(String buttonName,By buttonlocator) throws InterruptedException {
		waitForPageToLoad();
		try
		{
			WebElement buttonEle = rootEle().findElement(buttonlocator);
			System.out.println("Actual Button name :"+" "+ buttonEle.getText());
			System.out.println("Exp Button name :"+" "+ buttonName);
			if(buttonEle.getText().trim().equals(buttonName))
			{
				
				if(!getFontColor(buttonEle).equalsIgnoreCase("rgba(0, 0, 0, 1)")) {
					Log.error(buttonEle.getText()+" webelement's Font Color doesn't pass the UI Validations");
					return false;
				}
				if(!getFontSize(buttonEle).equalsIgnoreCase("10px")) {
					Log.error(buttonEle.getText()+" webelement's Font Size doesn't pass the UI Validations");
					return false;
				}
				if(!getFontType(buttonEle).equalsIgnoreCase("Verdana")) {
					Log.error(buttonEle.getText()+" webelement's Font Type doesn't pass the UI Validations");
					return false;
				}
				if(!getFontWeight(buttonEle).equalsIgnoreCase("700")) {
					Log.error(buttonEle.getText()+" webelement's Font Weight doesn't pass the UI Validations");
					return false;
				}
				if(!getBackgroundColor(buttonEle).equalsIgnoreCase("rgba(240, 240, 240, 1)")) {
					Log.error(buttonEle.getText()+" webelement's Background Color doesn't pass the UI Validations");
					return false;
				}

			}
			else
			{
				Log.error("Failed:Button name not matching");
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:element not found");
			return false;
		}
		
		return true;
	}
	
	/**
	 * Expected response from DB through data sheet
	 * 
	 * @param 
	 * @return
	 * @throws 
	 */
	public List<String> ExpectedValuesFromDB(String expResponseDB) throws InterruptedException {
		waitForPageToLoad();
		List<String> expResponseDBList = new ArrayList();
		try
		{
			String expValuesArray [] = expResponseDB.split("\\|\\|");
			for(int i=0;i<expValuesArray.length;i++)
			{
				if(!(expValuesArray[i].equals("")||expValuesArray[i].equals("null")))
				expResponseDBList.add(expValuesArray[i]);
			}
			//Collections.sort(expResponseDBList);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}
		
		return expResponseDBList;
	}
	
	public List<String> ExpectedValuesFromDB2(String expResponseDB) throws InterruptedException {
		waitForPageToLoad();
		List<String> expResponseDBList = new ArrayList();
		try
		{
			String expValuesArray [] = expResponseDB.split("\\|\\|");
			for(int i=0;i<expValuesArray.length;i++)
			{
				expResponseDBList.add((expValuesArray[i]).trim());
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}
		
		return expResponseDBList;
	}
	
	public List<String> ExpectedValuesDB2(String expResponseDB) throws InterruptedException {
		waitForPageToLoad();
		List<String> expResponseDBList = new ArrayList();
		try
		{
			String expValuesArray [] = expResponseDB.split("\\|\\|");
			for(int i=0;i<expValuesArray.length;i++)
			{
				expResponseDBList.add((expValuesArray[i]));
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}
		
		return expResponseDBList;
	}
	
	
	
}