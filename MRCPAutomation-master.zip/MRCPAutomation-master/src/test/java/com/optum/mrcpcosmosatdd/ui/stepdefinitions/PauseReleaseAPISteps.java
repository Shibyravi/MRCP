package com.optum.mrcpcosmosatdd.ui.stepdefinitions;



import com.optum.mrcpcosmosatdd.services.rest.PauseReleaseAPIValidations;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;




import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cucumber.api.java.en.Then;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.services.rest.PhysicianCL601ClearReviewValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;
import cucumber.api.java.en.When;

public class PauseReleaseAPISteps extends MRCPTestBase{
   File JSON_pausestatus,
    JSON_Pause_alrdyreleased,
    JSON_Pause_invalidclmtype,
    JSON_Pause_invalidaudit,
    JSON_Pause_invalidsiteid,
    JSON_Pause_invaliduserid;


    @When("^I get the request body parameter from pause json file$")
    public void i_get_the_request_body_parameter_from_pause_json_file() throws Throwable {
        JSON_pausestatus=new File(PropertyReader.getInstance().readProperty("JSON_pausestatus"));
        JSON_Pause_alrdyreleased=new File(PropertyReader.getInstance().readProperty("JSON_Pause_alrdyreleased"));
        JSON_Pause_invalidclmtype=new File(PropertyReader.getInstance().readProperty("JSON_Pause_invalidclmtype"));
        JSON_Pause_invalidaudit=new File(PropertyReader.getInstance().readProperty("JSON_Pause_invalidaudit"));
        JSON_Pause_invalidsiteid=new File(PropertyReader.getInstance().readProperty("JSON_Pause_invalidsiteid"));
        JSON_Pause_invaliduserid=new File(PropertyReader.getInstance().readProperty("JSON_Pause_invaliduserid"));

    }

    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus(JSON_pausestatus);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage) , "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");


    }
    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim when it is released from pause status\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim_when_it_is_released_from_pause_status(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
        // response from sheet
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));
//response from service
        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus(JSON_Pause_alrdyreleased);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes and return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage) , "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");

    }



    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim when Claim type is invalid\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim_when_Claim_type_is_invalid(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus(JSON_Pause_invalidclmtype);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes and return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage) , "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");

    }
    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim when Auditnumber is invalid\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim_when_Auditnumber_is_invalid(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException{
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus(JSON_Pause_invalidaudit);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
       System.out.println(rtnmessage);
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes and return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");
    }
    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim when siteid is invalid\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim_when_siteid_is_invalid(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException{
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));
          System.out.println(rtnmessage);
        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus(JSON_Pause_invalidsiteid);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes and return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");
    }
    @Then("^Verify the Pause Return code as \"([^\"]*)\" and return message \"([^\"]*)\" of claim when userid is invalid\\.$")
    public void verify_the_Pause_Return_code_as_and_return_message_of_claim_when_userid_is_invalid(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
        if(rtncode.length()>0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if(rtnmessage.length()>0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String,String> response_ClaimsDetails = getPage(PauseReleaseAPIValidations.class).rtnStatus( JSON_Pause_invaliduserid);
        System.out.println("Return code from Response:"+" "+ response_ClaimsDetails.get("code")+" and "+"Return message from Response:"+response_ClaimsDetails.get("msg"));
        Assert.assertTrue(response_ClaimsDetails.get("code").equals(rtncode) , "Failed:Return codes and return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("msg").equals(rtnmessage) , "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");

    }





}

