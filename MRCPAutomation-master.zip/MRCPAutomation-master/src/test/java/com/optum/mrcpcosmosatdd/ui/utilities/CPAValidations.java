package com.optum.mrcpcosmosatdd.ui.utilities;

public class CPAValidations {

}
