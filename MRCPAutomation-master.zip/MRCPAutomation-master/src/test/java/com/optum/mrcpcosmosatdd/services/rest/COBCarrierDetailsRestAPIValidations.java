package com.optum.mrcpcosmosatdd.services.rest;
import static io.restassured.RestAssured.*;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.cedarsoftware.util.io.JsonObject;
import com.mongodb.util.JSON;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.common.JWTToken;
import com.optum.mrcpcosmosatdd.ui.pages.HomePage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
public class COBCarrierDetailsRestAPIValidations {

	HomePage homepage = new HomePage();
	public String getJsonResponseAsString(Map<String, String> requestParams) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException{
		//RestAssured.baseURI ="http://cobrestapis-unita1-mrcpdev.origin-ctc-core-nonprod.optum.com"; 
		RestAssured.baseURI ="https://gateway-stage-core.optum.com/api/uat/clm/mrcp/cobapis/v1";
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		Response response = request.params(requestParams).get("/cob-carrier");
		String jsonString = response.asString();
		return jsonString;
	}

	public JSONObject getJsonResponseAsJSONObject(Map<String, String> requestParams) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		//RestAssured.baseURI ="http://cobrestapis-unita1-mrcpdev.origin-ctc-core-nonprod.optum.com"; 
		RestAssured.baseURI ="https://gateway-stage-core.optum.com"; 
		List<String> authTokens =homepage.getAuthKeysFromCookies("oidc_auth_token" ,"oidc_id_token"); 
		Map<String,String> authMap = new HashMap();
		authMap.put("Authorization", "Bearer "+authTokens.get(0));
		authMap.put("id-token",authTokens.get(1));
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON).headers(authMap);
		Response response = request.params(requestParams).get("/app/dev/clm-mrcp-cobapis/v1/cob-carrier");
		return new JSONObject(response.asString());
	}


	public Response getJsonResponseAsJSONObjectforClaimsObject(Map<String, String> requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://droolsdataobj-master.origin-ctc-core.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		JSONObject requestParams = new JSONObject();
		requestParams.put("site", requestBody.get("Site"));
		requestParams.put("auditNbr", requestBody.get("AuditNbr"));
		requestParams.put("subAudit", requestBody.get("SubauditNbr"));
		requestParams.put("claimType", requestBody.get("ClaimType"));
		request.body(requestParams.toString());
		Response response = request.post("/claimObj");
		return response;
	}

	public JSONObject getJsonResponseAsJSONObjectforGateway(Map<String, String> requestParams) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException{
		String id_Token = "eyJhbGciOiJSUzI1NiIsImtpZCI6Im5RLTNTY2pPaVZpcFQ5NTl2dXJDbThyQURDYyJ9.eyJzdWIiOiJDTj1ia3VtYXI4MixDTj1Vc2VycyxEQz1tcyxEQz1kcyxEQz11aGMsREM9Y29tIiwiYXVkIjoiUmVnMURldl9DUEEiLCJqdGkiOiJtOTBmTk9JQVlmVEpjUVdBeE50SmxJIiwiaXNzIjoiaHR0cHM6Ly9hdXRoZ2F0ZXdheTEtZGV2LmVudGlhbS51aGcuY29tIiwiaWF0IjoxNTkzMDY1NzAyLCJleHAiOjE1OTMwNjYwMDIsImFjciI6IlIxX0FBTDFfTVMtQUQtUGFzc3dvcmQiLCJhdXRoX3RpbWUiOjE1OTMwNjU3MDIsIkNvc21vc0lEIjoiMDM3MzQiLCJJQU1fdXNlcm5hbWUiOiJia3VtYXI4MiIsIlVzZXJHcm91cHMiOiJDT1NNT1NfQ0lDU19URVNUIiwicGkuc3JpIjoidUYtVkZ3VWVja0hxUnNfV3JPWDdITThzcUlZLlVqRS45RURaIn0.LUd5GVRcX1gpkXrpGHifdjkj48guk7xjVpX7vKxFFHHirskbofxujwFNFpSK_LnMe14AlGfoxqDpJnwSpPigP1UF0Fyzf4q-ug00DZ8_5FT7oed-66w08AyGRhM0tv4XwAh21f4KyMzsFnKh9f3LnguGNQWtz5pOeTWAgayGir09uHob15dzLlI5-cFGFPUMOa8erZ-cugFzEO3P0uePcPm3oogTa1Hn0dgD0KhLT57vcWJh9Q4iU73gbMo-9wrZr35kwNBVb2Oyt00FafKHtuv6YjiTcfL_G07fsvbrEI_Ke4YETdkERrAXDnoVHZqLXJM7s_tPheVPg6gEGY097g";
		RestAssured.baseURI ="https://gateway-stage-core.optum.com";
		Map<String,String> headerAtt = new HashMap();
		//Setting JWT Token in Header i.e. Authorization
		headerAtt.put("Authorization", "Bearer "+ JWTToken.generateJWTToken(baseURI));
		System.out.println("JWT Token:"+ " "+ JWTToken.generateJWTToken(baseURI));
		headerAtt.put("id-token", id_Token);
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON).headers(headerAtt);
		Response response = request.params(requestParams).get("/api/uat/clm/mrcp/cobapis/v1/cob-carrier");

		return new JSONObject(response.asString());
	}

	//Return the Member details from response
	public List<String> memDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String memNbr = "";
		String site="";
		String asOfDate="";
		String gender="";
		String dob="";
		String auditNumber="";
		String middleName="";
		String firstName="";
		String lastName="";
		String memberName="";
		List<String> memDetails_Resp = new ArrayList();
		try
		{
			JSONObject jsonObj = getJsonResponseAsJSONObject(requestParams);
			memNbr = (String) jsonObj.getJSONObject("memberDetail").get("memberNumber");
			site = (String) jsonObj.getJSONObject("memberDetail").get("site");
			asOfDate = (String) jsonObj.getJSONObject("memberDetail").get("fromDate");
			gender = (String) jsonObj.getJSONObject("memberDetail").get("gender");
			dob = (String) jsonObj.getJSONObject("memberDetail").get("dob");
			auditNumber = String.valueOf(jsonObj.getJSONObject("memberDetail").get("auditNumber"));
			firstName = (String) jsonObj.getJSONObject("memberDetail").get("firstName");
			middleName = (String) jsonObj.getJSONObject("memberDetail").get("middleName");
			lastName = (String) jsonObj.getJSONObject("memberDetail").get("lastName");

			String val[] = {memNbr.trim(),site.trim(),asOfDate.trim(),gender.trim(),dob.trim(),auditNumber.trim(),firstName.trim(),middleName.trim(),lastName.trim()};
			for(String data:val)
			{
				if(!(data.equals("null")||data.equals(""))) 
				{
					memDetails_Resp.add(data);
				}
			}
			//memDetails_Resp.addAll(Arrays.asList(val));
			Collections.sort(memDetails_Resp);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return memDetails_Resp;
	}

	//Return the claims details from response
	public List<String> claimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String clmType = "";
		String clmSite="";
		String auditNbr= "";
		String auditSub="";
		String medicalFlag="";
		String hdrDenial="";
		String hdrSysDslwFlag="";
		String hdrCloseFlag="";
		String parStatus="";
		String ufeId="";
		String clmSrc = "";
		String cobEligible="";
		String vendorId="";
		String fromDate="";
		String thruDate="";
		String clmAccidentType="";
		String hospRemarks="";
		String devFlag ="";
		String closureFlag ="";
		String hdrContractAmt="";
		String clmAccidentDate="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			clmType = jsonPathEvaluator.get("clmType");
			clmSite = jsonPathEvaluator.get("clmSite");
			auditNbr = Integer.toString(jsonPathEvaluator.get("auditNbr"));
			auditSub = Integer.toString(jsonPathEvaluator.get("auditSub"));
			medicalFlag = jsonPathEvaluator.get("medicalFlag");
			hdrDenial = Integer.toString(jsonPathEvaluator.get("hdrDenial"));
			hdrSysDslwFlag = jsonPathEvaluator.get("hdrSysDslwFlag");
			hdrCloseFlag = jsonPathEvaluator.get("hdrCloseFlag");
			parStatus = jsonPathEvaluator.get("parStatus");
			ufeId = jsonPathEvaluator.get("ufeId");
			clmSrc = jsonPathEvaluator.get("clmSrc");
			vendorId = jsonPathEvaluator.get("vendorId"); 
			fromDate = jsonPathEvaluator.get("fromDate");
			thruDate = jsonPathEvaluator.get("thruDate");
			clmAccidentType = jsonPathEvaluator.get("clmAccidentType");
			hospRemarks = jsonPathEvaluator.get("hospRemarks");
			devFlag = jsonPathEvaluator.get("devFlag");
			closureFlag = jsonPathEvaluator.get("closureFlag");
			hdrContractAmt = Integer.toString(jsonPathEvaluator.get("hdrContractAmt"));
			clmAccidentDate = jsonPathEvaluator.get("clmAccidentDate");
			cobEligible = Float.toString(jsonPathEvaluator.get("cobEligible"));

			String val[] = {clmType.trim(),clmSite.trim(),auditNbr.trim(),auditSub.trim(),medicalFlag.trim(),hdrDenial.trim(),hdrSysDslwFlag.trim(),hdrCloseFlag.trim(),parStatus.trim(),ufeId.trim(),clmSrc.trim(),vendorId.trim(),fromDate.trim(),thruDate.trim(),clmAccidentType.trim(),hospRemarks.trim(),devFlag.trim(),closureFlag.trim(),hdrContractAmt.trim(),clmAccidentDate.trim(),cobEligible.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));

			//Collections.sort(claimDetails_Resp);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return claimDetails_Resp;
	}

	public List<String> HospclaimsAuditDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String clmType = "";
		String clmSite="";
		String auditNbr= "";
		String auditSub="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			clmType = jsonPathEvaluator.get("clmType");
			clmSite = jsonPathEvaluator.get("clmSite");
			auditNbr = Integer.toString(jsonPathEvaluator.get("auditNbr"));
			auditSub = Integer.toString(jsonPathEvaluator.get("auditSub"));

			String val[] = {clmType.trim(),clmSite.trim(),auditNbr.trim(),auditSub.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));

			//Collections.sort(claimDetails_Resp);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public Map<String,String> HospclaimsObjectResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String medicalFlag = "";
		String hdrDenial="";
		String hdrSysDslwFlag= "";
		String hdrCloseFlag="";
		String parStatus="";
		String ufeId= "";
		String clmSrc="";
		String vendorId="";
		String fromDate="";
		String thruDate= "";
		String clmAccidentType="";
		String hospRemarks="";
		String devFlag="";
		String closureFlag="";
		String hdrContractAmt= "";
		String clmAccidentDate="";
		String cobEligible="";
		String hdrCopayAmt="";
		String hdrDeductAmt="";
		String hdrLiabilityAmt="";
		String inpatientFlag= "";
		String origAuditNbr="";
		String origAuditSub="";
		String origHdrDenial="";
		String origUfeId="";
		String memGrp="";
		String memSub= "";
		String memDep="";
		String newDenialCode="";
		String newContractAmt="";
		String newClmPaidAmt="";
		String newCopayAmt="";
		String newDeductAmt="";
		String clmPaidAmt= "";
		String pos="";
		String tin="";
		String origSubmittedCharge="";

		Map<String,String> resp = new HashMap();

		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			medicalFlag = jsonPathEvaluator.get("medicalFlag");
			hdrDenial = Integer.toString(jsonPathEvaluator.get("hdrDenial"));
			hdrSysDslwFlag = jsonPathEvaluator.get("hdrSysDslwFlag");
			hdrCloseFlag = jsonPathEvaluator.get("hdrCloseFlag");
			parStatus = jsonPathEvaluator.get("parStatus");
			ufeId = jsonPathEvaluator.get("ufeId");
			clmSrc = jsonPathEvaluator.get("clmSrc");
			vendorId = jsonPathEvaluator.get("vendorId");
			fromDate = jsonPathEvaluator.get("fromDate");
			thruDate = jsonPathEvaluator.get("thruDate");
			clmAccidentType = jsonPathEvaluator.get("clmAccidentType");
			hospRemarks = jsonPathEvaluator.get("hospRemarks");
			devFlag = jsonPathEvaluator.get("devFlag");
			closureFlag = jsonPathEvaluator.get("closureFlag");
			hdrContractAmt = Float.toString(jsonPathEvaluator.get("hdrContractAmt"));
			clmAccidentDate = jsonPathEvaluator.get("clmAccidentDate");
			cobEligible = Float.toString(jsonPathEvaluator.get("cobEligible"));
			hdrCopayAmt = Float.toString(jsonPathEvaluator.get("hdrCopayAmt"));
			hdrDeductAmt = Float.toString(jsonPathEvaluator.get("hdrDeductAmt"));
			hdrLiabilityAmt = Integer.toString(jsonPathEvaluator.get("hdrLiabilityAmt"));
			inpatientFlag = jsonPathEvaluator.get("inpatientFlag");
			origAuditNbr = Integer.toString(jsonPathEvaluator.get("origAuditNbr"));
			origAuditSub = Integer.toString(jsonPathEvaluator.get("origAuditSub"));
			origHdrDenial = Integer.toString(jsonPathEvaluator.get("origHdrDenial"));
			origUfeId = jsonPathEvaluator.get("origUfeId");
			memGrp = Integer.toString(jsonPathEvaluator.get("memGrp"));
			memSub = Integer.toString(jsonPathEvaluator.get("memSub"));
			memDep = Integer.toString(jsonPathEvaluator.get("memDep"));
			newDenialCode = Integer.toString(jsonPathEvaluator.get("newDenialCode"));
			newContractAmt = Float.toString(jsonPathEvaluator.get("newContractAmt"));
			newClmPaidAmt = Float.toString(jsonPathEvaluator.get("newClmPaidAmt"));
			newCopayAmt = Float.toString(jsonPathEvaluator.get("newCopayAmt"));
			newDeductAmt = Float.toString(jsonPathEvaluator.get("newDeductAmt"));
			clmPaidAmt = Float.toString(jsonPathEvaluator.get("clmPaidAmt"));
			pos = Integer.toString(jsonPathEvaluator.get("pos"));
			tin = Integer.toString(jsonPathEvaluator.get("tin"));
			origSubmittedCharge = jsonPathEvaluator.get("origSubmittedCharge");

			//Add the values to map 
			resp.put("Medical flag", medicalFlag);
			resp.put("Header Denial", hdrDenial);
			resp.put("Header Sys Dilw flag", hdrSysDslwFlag);
			resp.put("Header Close Flag", hdrCloseFlag);
			resp.put("Par Status", parStatus);
			resp.put("Ufe Id", ufeId);
			resp.put("Claim Source", clmSrc);
			resp.put("Vendor id", vendorId);
			resp.put("From date", fromDate);
			resp.put("Thru date", thruDate);
			resp.put("clm accident type", clmAccidentType);
			resp.put("Hosp Remarks", hospRemarks);
			resp.put("Dev Flag", devFlag);
			resp.put("closure flag", closureFlag);
			resp.put("Hdr Contract amt", hdrContractAmt);
			resp.put("Clm Accident date", clmAccidentDate);
			resp.put("Cob eligible", cobEligible);
			resp.put("Hdr Copay amount", hdrCopayAmt);
			resp.put("Hdr Deduct Amt", hdrDeductAmt);
			resp.put("Hdr Liability amount", hdrLiabilityAmt);
			resp.put("Impatient flag", inpatientFlag);
			resp.put("Orig audit number", origAuditNbr);
			resp.put("Orig audit sub", origAuditSub);
			resp.put("Orig header denial", origHdrDenial);
			resp.put("Orig Ufe Id", origUfeId);
			resp.put("Mem group", memGrp);
			resp.put("Mem sub",memSub );
			resp.put("Mem Dep", memDep);
			resp.put("New Denial code", newDenialCode);
			resp.put("New Contract amt", newContractAmt);
			resp.put("New Clm paid amt", newClmPaidAmt);
			resp.put("New copay amount", newCopayAmt);
			resp.put("New deduct amt", newDeductAmt);
			resp.put("Clm paid amt", clmPaidAmt);
			resp.put("POS", pos);
			resp.put("Tin", tin);
			resp.put("Orig Submt Chrge Amt", origSubmittedCharge);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return resp;
	}

	public Map<String,String> PhyclaimsObjectResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		String pos="";
		String tin="";
		String origSubmittedCharge="";

		Map<String,String> resp = new HashMap();

		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			pos = Integer.toString(jsonPathEvaluator.get("pos"));
			tin = Integer.toString(jsonPathEvaluator.get("tin"));
			//origSubmittedCharge = Integer.toString(jsonPathEvaluator.get("origSubmittedCharge"));

			//Add the values to map 

			resp.put("POS", pos);
			resp.put("Tin", tin);
			resp.put("Orig Submt Chrge Amt", origSubmittedCharge);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return resp;
	}

	//Return the amount claims details from response
	public List<String> amountClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String cobEligible = "";
		String hdrCopayAmt="";
		String hdrDeductAmt= "";
		String hdrLiabilityAmt="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			hdrCopayAmt = Float.toString(jsonPathEvaluator.get("hdrCopayAmt"));
			hdrDeductAmt = Float.toString(jsonPathEvaluator.get("hdrDeductAmt"));
			cobEligible = Float.toString(jsonPathEvaluator.get("cobEligible"));
			hdrLiabilityAmt = Integer.toString(jsonPathEvaluator.get("hdrLiabilityAmt"));

			String val[] = {cobEligible.trim(),hdrCopayAmt.trim(),hdrDeductAmt.trim(),hdrLiabilityAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));

			//Collections.sort(claimDetails_Resp);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> origClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String inpatientFlag = "";
		String origAuditNbr="";
		String origAuditSub= "";
		String origHdrDenial="";
		String origUfeId = "";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			inpatientFlag = jsonPathEvaluator.get("inpatientFlag");
			origAuditNbr = Integer.toString(jsonPathEvaluator.get("origAuditNbr"));
			origAuditSub = Integer.toString(jsonPathEvaluator.get("origAuditSub"));
			origHdrDenial = Integer.toString(jsonPathEvaluator.get("origHdrDenial"));
			origUfeId = jsonPathEvaluator.get("origUfeId");

			String val[] = {inpatientFlag.trim(),origAuditNbr.trim(),origAuditSub.trim(),origUfeId.trim(),origHdrDenial.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));

			//Collections.sort(claimDetails_Resp);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> diagCodesClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		List<String> claimDetails_Resp = new ArrayList();
		try
		{

			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfcodes = jsonObj.getJSONArray("diagCodes").length();
			System.out.println("number of diag codes"+ " "+ noOfcodes);
			String [] diagCodes = new String[noOfcodes];
			for(int i=0;i<noOfcodes;i++)
			{
				diagCodes[i] = ((String) jsonObj.getJSONArray("diagCodes").get(i)).trim();
			}

			claimDetails_Resp.addAll(Arrays.asList(diagCodes));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> causeCodesClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfcodes = jsonObj.getJSONArray("causeCodes").length();
			System.out.println("number of cause codes"+ " "+ noOfcodes);
			String [] causeCodes = new String[noOfcodes];
			for(int i=0;i<noOfcodes;i++)
			{
				causeCodes[i] = ((String) jsonObj.getJSONArray("causeCodes").get(i)).trim();
			}

			claimDetails_Resp.addAll(Arrays.asList(causeCodes));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> occCodesClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfcodes = jsonObj.getJSONArray("occCodes").length();
			System.out.println("number of occ codes"+ " "+ noOfcodes);
			String [] occCodes = new String[noOfcodes];
			for(int i=0;i<noOfcodes;i++)
			{
				occCodes[i] = ((String) jsonObj.getJSONArray("occCodes").get(i)).trim();
			}

			claimDetails_Resp.addAll(Arrays.asList(occCodes));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> condCodesClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfcodes = jsonObj.getJSONArray("condCodes").length();
			System.out.println("number of cond codes"+ " "+ noOfcodes);
			String [] condCodes = new String[noOfcodes];
			for(int i=0;i<noOfcodes;i++)
			{
				condCodes[i] = ((String) jsonObj.getJSONArray("condCodes").get(i)).trim();
			}

			claimDetails_Resp.addAll(Arrays.asList(condCodes));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> eobObjectsClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfcodes = jsonObj.getJSONArray("eobObjects").length();
			System.out.println("number of cond codes"+ " "+ noOfcodes);
			String [] eobObj = new String[noOfcodes];
			for(int i=0;i<noOfcodes;i++)
			{
				eobObj[i] = ((String) jsonObj.getJSONArray("eobObjects").get(i)).trim();
			}

			claimDetails_Resp.addAll(Arrays.asList(eobObj));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> memDetailsClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String memGrp ="";
		String memSub ="";
		String memDep ="";
		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			memGrp = Integer.toString(jsonPathEvaluator.get("memGrp"));
			memSub = Integer.toString(jsonPathEvaluator.get("memSub"));
			memDep = Integer.toString(jsonPathEvaluator.get("memDep"));


			String val[] = {memGrp.trim(),memSub.trim(),memDep.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> newDenialCodeClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String newDenialCode ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			newDenialCode = Integer.toString(jsonPathEvaluator.get("newDenialCode"));

			String val[] = {newDenialCode.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> newconctamtClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String newContractAmt ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			newContractAmt = Float.toString(jsonPathEvaluator.get("newContractAmt"));

			String val[] = {newContractAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> newClmPaidAmtClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String newClmPaidAmt ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			newClmPaidAmt = Float.toString(jsonPathEvaluator.get("newClmPaidAmt"));

			String val[] = {newClmPaidAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}


	public List<String> newCopayAmtClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String newCopayAmt ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			newCopayAmt = Float.toString(jsonPathEvaluator.get("newCopayAmt"));

			String val[] = {newCopayAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> newDeductAmtClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String newDeductAmt ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			newDeductAmt = Float.toString(jsonPathEvaluator.get("newDeductAmt"));

			String val[] = {newDeductAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public List<String> clmPaidAmtClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		String clmPaidAmt ="";

		List<String> claimDetails_Resp = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			//Read JSON response and print
			JsonPath jsonPathEvaluator = jsonResponse.jsonPath();
			clmPaidAmt = Float.toString(jsonPathEvaluator.get("clmPaidAmt"));

			String val[] = {clmPaidAmt.trim()};
			claimDetails_Resp.addAll(Arrays.asList(val));
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return claimDetails_Resp;
	}

	public Map<String,List<String>> serviceLinesDetailsClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,List<String>> Service_Lines_Resp = new HashMap();
		List<String> dtlNbr = new ArrayList();
		List<String> dtlRsnCode = new ArrayList();
		List<String> denial_Flag = new ArrayList();
		List<String> dtlSysDslwFlag = new ArrayList();
		List<String> dtlCloseFlag = new ArrayList();
		List<String> overrideFlag = new ArrayList();
		List<String> svcCode = new ArrayList();
		List<String> dtlClaimedAmt = new ArrayList();
		List<String> dtlDisallowAmt = new ArrayList();
		List<String> dtlCopayAmt = new ArrayList();
		List<String> dtlDeductAmt = new ArrayList();
		List<String> dtlDiscountAmt = new ArrayList();
		List<String> dtlFeeMax = new ArrayList();
		List<String> dtlLiabilityAmt = new ArrayList();
		List<String> benTierNbr = new ArrayList();
		List<String> newDtlRsnCode = new ArrayList();
		List<String> dtlCobEligible = new ArrayList();
		List<String> dtlPaidAmt = new ArrayList();
		List<String> newDtlPaidAmt = new ArrayList();
		List<String> newDtlCopayAmt = new ArrayList();
		List<String> newDtlDeductAmt = new ArrayList();
		List<String> cptCode = new ArrayList();
		List<String> revenueCode = new ArrayList();
		List<String> newDtlContractAmt = new ArrayList();
		List<String> dtlContractAmt = new ArrayList();
		List<String> newDtlEligibleAmt = new ArrayList();
		List<String> dtlEligibleAmt = new ArrayList();
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfRows = jsonObj.getJSONArray("serviceLines").length();
			System.out.println("number of service lines"+ " "+ noOfRows);
			String [] detail_Nbr = new String[noOfRows];
			String [] detailRsnCode = new String[noOfRows];
			String [] detailFlag = new String[noOfRows];
			String [] details_SysDisFlag =new String[noOfRows];
			String [] detail_ClsFlag =new String[noOfRows];
			String [] override_Flag = new String[noOfRows];
			String [] svc_Code = new String[noOfRows];
			String [] detail_Clmd_Amt = new String[noOfRows];
			String [] detail_Disallwd_Amt = new String[noOfRows];
			String [] detail_copay_Amt = new String[noOfRows];
			String [] detail_Dedct_Amt = new String[noOfRows];
			String [] dtl_dict_Amt = new String[noOfRows];
			String [] dtl_Fee_Max = new String[noOfRows];
			String [] dtl_Liability_Amt = new String[noOfRows];
			String [] ben_Tier_Nbr = new String[noOfRows];
			String [] new_Dtl_RsnCode = new String[noOfRows];
			String [] new_Dtl_CobElgble = new String[noOfRows];
			String [] dtl_PaidAmt = new String[noOfRows];
			String [] new_Dtl_PaidAmt = new String[noOfRows];
			String [] new_Dtl_CopayAmt = new String[noOfRows];
			String [] new_Dtl_DeductAmt = new String[noOfRows];
			String [] cpt_Code = new String[noOfRows];
			String [] revenue_Code = new String[noOfRows];
			String [] new_Dtl_ContractAmt = new String[noOfRows];
			String [] dtl_ContractAmt = new String[noOfRows];
			String [] new_Dtl_EligibleAmt = new String[noOfRows];
			String [] dtl_EligibleAmt = new String[noOfRows];

			for(int i=0;i<noOfRows;i++)
			{
				JSONObject serviceLines = (JSONObject) (jsonObj.getJSONArray("serviceLines").get(i));
				detail_Nbr[i] = serviceLines.getString("dtlNbr");
				dtlNbr.add(detail_Nbr[i] );
				detailRsnCode[i] = serviceLines.getString("dtlRsnCode");
				dtlRsnCode.add(detailRsnCode[i]);
				detailFlag[i] = serviceLines.getString("denialFlag");
				denial_Flag.add(detailFlag[i]);
				details_SysDisFlag[i] = serviceLines.getString("dtlSysDslwFlag");
				dtlSysDslwFlag.add(details_SysDisFlag[i]);
				detail_ClsFlag[i] = serviceLines.getString("dtlCloseFlag");
				dtlCloseFlag.add(detail_ClsFlag[i]);
				override_Flag[i] = serviceLines.getString("overrideFlag");
				overrideFlag.add(override_Flag[i]);
				svc_Code[i] = serviceLines.getString("svcCode");
				svcCode.add(svc_Code[i]);
				detail_Clmd_Amt[i] = serviceLines.getString("dtlClaimedAmt");
				dtlClaimedAmt.add(detail_Clmd_Amt[i]);
				detail_Disallwd_Amt[i] = serviceLines.getString("dtlDisallowAmt");
				dtlDisallowAmt.add(detail_Disallwd_Amt[i]);
				detail_copay_Amt[i] = serviceLines.getString("dtlCopayAmt");
				dtlCopayAmt.add(detail_copay_Amt[i]);
				detail_Dedct_Amt[i] = serviceLines.getString("dtlDeductAmt");
				dtlDeductAmt.add(detail_Dedct_Amt[i]);
				dtl_dict_Amt[i] = serviceLines.getString("dtlDiscountAmt");
				dtlDiscountAmt.add(dtl_dict_Amt[i] );
				dtl_Fee_Max[i] = serviceLines.getString("dtlFeeMax");
				dtlFeeMax.add(dtl_Fee_Max[i]);
				dtl_Liability_Amt[i] = serviceLines.getString("dtlLiabilityAmt");
				dtlLiabilityAmt.add(dtl_Liability_Amt[i]);
				ben_Tier_Nbr[i] = serviceLines.getString("benTierNbr");
				benTierNbr.add(ben_Tier_Nbr[i]);
				new_Dtl_RsnCode[i] = serviceLines.getString("newDtlRsnCode");
				newDtlRsnCode.add(new_Dtl_RsnCode[i]);
				new_Dtl_CobElgble[i] = serviceLines.getString("dtlCobEligible");
				dtlCobEligible.add(new_Dtl_CobElgble[i]);
				dtl_PaidAmt[i] = serviceLines.getString("dtlPaidAmt");
				dtlPaidAmt.add(dtl_PaidAmt[i]);
				new_Dtl_PaidAmt[i] = serviceLines.getString("newDtlPaidAmt");
				newDtlPaidAmt.add(new_Dtl_PaidAmt[i]);
				new_Dtl_CopayAmt[i] = serviceLines.getString("newDtlCopayAmt");
				newDtlCopayAmt.add(new_Dtl_CopayAmt[i]);
				new_Dtl_DeductAmt[i] = serviceLines.getString("newDtlDeductAmt");
				newDtlDeductAmt.add(new_Dtl_DeductAmt[i]);
				cpt_Code[i] = serviceLines.getString("cptCode");
				cptCode.add(cpt_Code[i]);
				revenue_Code[i] = serviceLines.getString("revenueCode");
				revenueCode.add(revenue_Code[i]);
				new_Dtl_ContractAmt[i] = serviceLines.getString("newDtlContractAmt");
				newDtlContractAmt.add(new_Dtl_ContractAmt[i]);
				dtl_ContractAmt[i] = serviceLines.getString("dtlContractAmt");
				dtlContractAmt.add(dtl_ContractAmt[i]);
				new_Dtl_EligibleAmt[i] = serviceLines.getString("newDtlEligibleAmt");
				newDtlEligibleAmt.add(new_Dtl_EligibleAmt[i]);
				dtl_EligibleAmt[i] = serviceLines.getString("dtlEligibleAmt");
				dtlEligibleAmt.add(dtl_EligibleAmt[i]);
			}

			Service_Lines_Resp.put("Detail Number", dtlNbr);
			Service_Lines_Resp.put("Detail Reason Code", dtlRsnCode);
			Service_Lines_Resp.put("Denial Flag", denial_Flag);
			Service_Lines_Resp.put("dt sys Disallw Flag", dtlSysDslwFlag);
			Service_Lines_Resp.put("Dt Close Flag", dtlCloseFlag);
			Service_Lines_Resp.put("Override Flag", overrideFlag);
			Service_Lines_Resp.put("Svc Code", svcCode);
			Service_Lines_Resp.put("Dt Claimed Amount", dtlClaimedAmt);
			Service_Lines_Resp.put("Dt Disallow amount", dtlDisallowAmt);
			Service_Lines_Resp.put("Detail Copay Amount", dtlCopayAmt);
			Service_Lines_Resp.put("Detail Deduct Amt", dtlDeductAmt);
			Service_Lines_Resp.put("Dt Discount Amt", dtlDiscountAmt);
			Service_Lines_Resp.put("Dt Fee Max", dtlFeeMax);
			Service_Lines_Resp.put("Dt liability Amt", dtlLiabilityAmt);
			Service_Lines_Resp.put("Ben Tier Nbr", benTierNbr);
			Service_Lines_Resp.put("New Dt Rsn Code", newDtlRsnCode);
			Service_Lines_Resp.put("Dt Cob eligible", dtlCobEligible);
			Service_Lines_Resp.put("Dt Paid Amt", dtlPaidAmt);
			Service_Lines_Resp.put("New Dt Paid Amt", newDtlPaidAmt);
			Service_Lines_Resp.put("New Dt copay Amt", newDtlCopayAmt);
			Service_Lines_Resp.put("New Dt Deduct Amt", newDtlDeductAmt);
			Service_Lines_Resp.put("CPT Code", cptCode);
			Service_Lines_Resp.put("Revenue Code", revenueCode);
			Service_Lines_Resp.put("New Dtl Contract Amt", newDtlContractAmt);
			Service_Lines_Resp.put("Dtl Contract Amt", dtlContractAmt);
			Service_Lines_Resp.put("New Dtl Eligible Amt", newDtlEligibleAmt);
			Service_Lines_Resp.put("Dtl Eligible Amt", dtlEligibleAmt);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return Service_Lines_Resp;
	}

	public Map<String,List<String>> reviewsClaimsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,List<String>> Reviews_Resp = new HashMap();
		List<String> rvwCode = new ArrayList();
		List<String> rvwStatus = new ArrayList();
		List<String> rvwInitial = new ArrayList();
		List<String> rvwClrDate = new ArrayList();
		List<String> rvwUserCode = new ArrayList();

		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfRows = jsonObj.getJSONArray("reviews").length();
			System.out.println("number of Reviews details"+ " "+ noOfRows);
			String [] rvw_Code = new String[noOfRows];
			String [] rvw_Status = new String[noOfRows];
			String [] rvw_Initial = new String[noOfRows];
			String [] rvw_ClrDate =new String[noOfRows];
			String [] rvw_UserCode =new String[noOfRows];

			for(int i=0;i<noOfRows;i++)
			{
				JSONObject review = (JSONObject) (jsonObj.getJSONArray("reviews").get(i));
				rvw_Code[i] = review.getString("rvwCode");
				rvwCode.add(rvw_Code[i] );
				rvw_Status[i] = review.getString("rvwStatus");
				rvwStatus.add(rvw_Status[i]);
				rvw_Initial[i] = review.getString("rvwInitial");
				rvwInitial.add(rvw_Initial[i]);
				rvw_ClrDate[i] = review.getString("rvwClrDate");
				rvwClrDate.add(rvw_ClrDate[i]);
				rvw_UserCode[i] = review.getString("rvwUserCode");
				rvwUserCode.add(rvw_UserCode[i]);
			}


			Reviews_Resp.put("Review Code", rvwCode);
			Reviews_Resp.put("Review Status", rvwStatus);
			Reviews_Resp.put("Review Initial", rvwInitial);
			Reviews_Resp.put("Review Clr Date", rvwClrDate);
			Reviews_Resp.put("Review Usr Code", rvwUserCode);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return Reviews_Resp;
	}


	public Map<String,List<String>> eobObjectsDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,List<String>> eobObj_Resp = new HashMap();
		List<String> hdrPaidAmt = new ArrayList();
		List<String> hdrDiscAmt = new ArrayList();
		List<String> hdrDisallowAmt = new ArrayList();
		List<String> hdrAllowableAmt = new ArrayList();
		List<String> hdrDeductAmt = new ArrayList();
		List<String> hdrCopayAmt = new ArrayList();
		List<String> hdrClaimedAmt = new ArrayList();
		List<String> carrierName = new ArrayList();
		List<String> clmFilingInd = new ArrayList();
		List<String> mvaCarrierFlag = new ArrayList();
		List<String> excepCarrierFlag = new ArrayList();
		List<String> hdrPatRespAmt = new ArrayList();

		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			int noOfRows = jsonObj.getJSONArray("eobObjects").length();
			System.out.println("number of EOB details"+ " "+ noOfRows);
			String [] hdr_PaidAmt = new String[noOfRows];
			String [] hdr_DiscAmt = new String[noOfRows];
			String [] hdr_DisallowAmt = new String[noOfRows];
			String [] hdr_AllowableAmt =new String[noOfRows];
			String [] hdr_DeductAmt =new String[noOfRows];
			String [] hdr_CopayAmt = new String[noOfRows];
			String [] hdr_ClaimedAmt = new String[noOfRows];
			String [] carrier_Name = new String[noOfRows];
			String [] clm_FilingInd =new String[noOfRows];
			String [] mva_CarrierFlag =new String[noOfRows];
			String [] excep_CarrierFlag =new String[noOfRows];
			String [] hdr_PatRespAmt =new String[noOfRows];


			for(int i=0;i<noOfRows;i++)
			{
				JSONObject eob = (JSONObject) (jsonObj.getJSONArray("eobObjects").get(i));
				hdr_PaidAmt[i] = eob.getString("hdrPaidAmt");
				hdrPaidAmt.add(hdr_PaidAmt[i] );
				hdr_DiscAmt[i] = eob.getString("hdrDiscAmt");
				hdrDiscAmt.add(hdr_DiscAmt[i]);
				hdr_DisallowAmt[i] = eob.getString("hdrDisallowAmt");
				hdrDisallowAmt.add(hdr_DisallowAmt[i]);
				hdr_AllowableAmt[i] = eob.getString("hdrAllowableAmt");
				hdrAllowableAmt.add(hdr_AllowableAmt[i]);
				hdr_DeductAmt[i] = eob.getString("hdrDeductAmt");
				hdrDeductAmt.add(hdr_DeductAmt[i]);
				hdr_CopayAmt[i] = eob.getString("hdrCopayAmt");
				hdrCopayAmt.add(hdr_CopayAmt[i] );
				hdr_ClaimedAmt[i] = eob.getString("hdrClaimedAmt");
				hdrClaimedAmt.add(hdr_ClaimedAmt[i]);
				carrier_Name[i] = eob.getString("carrierName");
				carrierName.add(carrier_Name[i]);
				clm_FilingInd[i] = eob.getString("clmFilingInd");
				clmFilingInd.add(clm_FilingInd[i]);
				mva_CarrierFlag[i] = eob.getString("mvaCarrierFlag");
				mvaCarrierFlag.add(mva_CarrierFlag[i]);
				excep_CarrierFlag[i] = eob.getString("excepCarrierFlag");
				excepCarrierFlag.add(excep_CarrierFlag[i]);
				hdr_PatRespAmt[i] = eob.getString("hdrPatRespAmt");

			}

			eobObj_Resp.put("HDR Paid amount", hdrPaidAmt);
			eobObj_Resp.put("HDR discount amount", hdrDiscAmt);
			eobObj_Resp.put("HDR disallow amount", hdrDisallowAmt);
			eobObj_Resp.put("HDR allowable amount", hdrAllowableAmt);
			eobObj_Resp.put("HDR deduct amount", hdrDeductAmt);
			eobObj_Resp.put("HDR copay amount", hdrCopayAmt);
			eobObj_Resp.put("HDR claimed amount", hdrClaimedAmt);
			eobObj_Resp.put("Carrier name", carrierName);
			eobObj_Resp.put("Claim filling ind", clmFilingInd);
			eobObj_Resp.put("MVA Carrier Flag", mvaCarrierFlag);
			eobObj_Resp.put("Excep Carrier Flag", excepCarrierFlag);
			eobObj_Resp.put("HDR PatResp Amount", hdrPatRespAmt);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return eobObj_Resp;
	}

	public List<String> eobObjectsDtlNbrDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> lst = new ArrayList();
		int dtlnbr=0;
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			JSONArray eob_Array = jsonObj.getJSONArray("eobObjects");
			for(int i=0;i<eob_Array.length();i++)
			{
				JSONObject json = eob_Array.getJSONObject(i);

				for(int j=0;j<json.getJSONArray("dtlNbr").length();j++)
				{
					lst.add(json.getJSONArray("dtlNbr").getString(j));
				}

			}
			System.out.println("detail numbers are"+ " "+lst);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return lst;

	}

	public List<String> eobObjectsClmAdjRsnCdDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> lst = new ArrayList();
		int dtlnbr=0;
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			JSONArray eob_Array = jsonObj.getJSONArray("eobObjects");
			for(int i=0;i<eob_Array.length();i++)
			{
				JSONObject json = eob_Array.getJSONObject(i);
				System.out.println("clm adj rsn code"+ " "+ json.getJSONArray("clmAdjRsnCode").length());
				for(int j=0;j<json.getJSONArray("clmAdjRsnCode").length();j++)
				{
					lst.add(json.getJSONArray("clmAdjRsnCode").getString(j));
				}
				
			}
			
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return lst;

	}

	public List<String> eobObjectsDtlAdjRsnCdDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{
		List<String> lst = new ArrayList();
		int dtlnbr=0;
		try
		{
			Response jsonResponse = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
			JSONObject jsonObj =  new JSONObject(jsonResponse.asString());
			//Read JSON response and print
			JSONArray eob_Array = jsonObj.getJSONArray("eobObjects");
			for(int i=0;i<eob_Array.length();i++)
			{
				JSONObject json = eob_Array.getJSONObject(i);

				for(int j=0;j<json.getJSONArray("dtlAdjRsnCode").length();j++)
				{
					lst.add(json.getJSONArray("dtlAdjRsnCode").getString(j));
				}

			}
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}
		return lst;

	}

	public Map<String,List<String>> CarrierDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,List<String>> CarrierDetails_Resp = new HashMap();
		List<String> lstPrimacy = new ArrayList();
		List<String> lstCovType = new ArrayList();
		List<String> lstCarrierType = new ArrayList();
		List<String> lstCarrierNbr = new ArrayList();
		List<String> lstCarrierName = new ArrayList();
		List<String> lstEffDate = new ArrayList();
		List<String> lstExpDt = new ArrayList();
		List<String> lstPolicyNbr = new ArrayList();
		List<String> lstCommnRsn = new ArrayList();
		List<String> lstOthrUHCInfo = new ArrayList();
		List<String> lstFmUser = new ArrayList();
		List<String> lstFMDate = new ArrayList();
		List<String> lstFmTime = new ArrayList();
		try
		{
			JSONObject jsonObj = getJsonResponseAsJSONObject(requestParams);
			//get the size of the array
			int noOfRows = jsonObj.getJSONArray("carrierDetail").length();
			System.out.println("total number of rows from service"+ " "+ noOfRows);
			String [] primacy = new String[noOfRows];
			String [] cov_Type = new String[noOfRows];
			String [] carrier_Type=new String[noOfRows];
			String [] carrier_Number=new String[noOfRows];
			String [] carrier_Name = new String[noOfRows];
			String [] Eff_Date = new String[noOfRows];
			String [] Exp_Date = new String[noOfRows];
			String [] policyNumber = new String[noOfRows];
			String [] commnRsn = new String[noOfRows];
			String [] otherUHCPlan = new String[noOfRows];
			String [] fmUser = new String[noOfRows];
			String [] fmDt = new String[noOfRows];
			String [] fmTime = new String[noOfRows];
			for(int i=0;i<noOfRows;i++)
			{
				JSONObject carrierDetails = (JSONObject) (jsonObj.getJSONArray("carrierDetail").get(i));
				primacy[i] = carrierDetails.getString("primacy");
				lstPrimacy.add(primacy[i] );
				cov_Type[i] = carrierDetails.getString("covType");
				lstCovType.add(cov_Type[i]);
				carrier_Type[i] = carrierDetails.getString("carrierType");
				lstCarrierType.add(carrier_Type[i]);
				carrier_Number[i] = carrierDetails.getString("carrierNumber");
				lstCarrierNbr.add(carrier_Number[i]);
				carrier_Name[i] = carrierDetails.getString("carrierName");
				lstCarrierName.add(carrier_Name[i]);
				Eff_Date[i] = carrierDetails.getString("effDate");
				lstEffDate.add(Eff_Date[i]);
				Exp_Date[i] = carrierDetails.getString("expDate");
				lstExpDt.add(Exp_Date[i]);
				policyNumber[i] = carrierDetails.getString("policyNumber");
				lstPolicyNbr.add(policyNumber[i]);
				commnRsn[i] = carrierDetails.getString("commRsn");
				lstCommnRsn.add(commnRsn[i]);
				otherUHCPlan[i] = carrierDetails.getString("otherPlanInfo");
				lstOthrUHCInfo.add(otherUHCPlan[i]);
				fmUser[i] = carrierDetails.getString("userId");
				lstFmUser.add(fmUser[i]);
				fmDt[i] = carrierDetails.getString("fmDate");
				lstFMDate.add(fmDt[i] );
				fmTime[i] = carrierDetails.getString("fmTime");
				lstFmTime.add(fmTime[i]);
			}

			lstPrimacy.removeAll(Arrays.asList("", null));
			lstCovType.removeAll(Arrays.asList("", null));
			lstCarrierType.removeAll(Arrays.asList("", null));
			lstCarrierNbr.removeAll(Arrays.asList("", null));
			lstCarrierName.removeAll(Arrays.asList("", null));
			lstEffDate.removeAll(Arrays.asList("", null));
			lstExpDt.removeAll(Arrays.asList("", null));
			lstPolicyNbr.removeAll(Arrays.asList("", null));
			lstCommnRsn.removeAll(Arrays.asList("", null));
			lstOthrUHCInfo.removeAll(Arrays.asList("", null));
			lstFmUser.removeAll(Arrays.asList("", null));
			lstFMDate.removeAll(Arrays.asList("", null));
			lstFmTime.removeAll(Arrays.asList("", null));

			CarrierDetails_Resp.put("Primacy", lstPrimacy);
			CarrierDetails_Resp.put("CovType", lstCovType);
			CarrierDetails_Resp.put("CarrierType", lstCarrierType);
			CarrierDetails_Resp.put("CarrierNumber", lstCarrierNbr);
			CarrierDetails_Resp.put("CarrierName", lstCarrierName);
			CarrierDetails_Resp.put("EffDate", lstEffDate);
			CarrierDetails_Resp.put("ExpDate", lstExpDt);
			CarrierDetails_Resp.put("PolicyNumber", lstPolicyNbr);
			CarrierDetails_Resp.put("CommReason", lstCommnRsn);
			CarrierDetails_Resp.put("OthrUHCPlan", lstOthrUHCInfo);
			CarrierDetails_Resp.put("FMUser", lstFmUser);
			CarrierDetails_Resp.put("FMDate", lstFMDate);
			CarrierDetails_Resp.put("FMTime", lstFmTime);
			CarrierDetails_Resp.values().remove(null);
		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return CarrierDetails_Resp;
	}

	public Map<String,List<String>> recoveryDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,List<String>> recoveryDetails_Resp = new HashMap();
		List<String> lstIncidentDtRec = new ArrayList();
		List<String> lstCarrierTypeRec = new ArrayList();
		List<String> lstCarrierNbrRec = new ArrayList();
		List<String> lstCarrierNameRec = new ArrayList();
		List<String> lstEffDateRec = new ArrayList();
		List<String> lstExpDtRec = new ArrayList();
		List<String> lstPolicyNbrRec = new ArrayList();
		List<String> lstCommnRsnRec = new ArrayList();
		List<String> lstApportPectRec = new ArrayList();
		List<String> lstDiagDescRec = new ArrayList();
		List<String> lstICDANumRec = new ArrayList();
		List<String> lstICDA1Rec = new ArrayList();
		List<String> lstICDA2Rec = new ArrayList();
		List<String> lstICDA3Rec = new ArrayList();
		List<String> lstICDA4Rec = new ArrayList();
		List<String> lstICDA5Rec = new ArrayList();
		List<String> lstICDA6Rec = new ArrayList();
		List<String> lstICDA7Rec = new ArrayList();
		List<String> lstICDA8Rec = new ArrayList();
		List<String> lstICDA9Rec = new ArrayList();
		List<String> lstICDA10Rec = new ArrayList();
		List<String> lstFmUserRec = new ArrayList();
		List<String> lstFMDateRec = new ArrayList();
		List<String> lstFmTimeRec = new ArrayList();
		try
		{
			JSONObject jsonObj = getJsonResponseAsJSONObject(requestParams);
			//get the size of the array
			int noOfRows = jsonObj.getJSONArray("recoveryDetails").length();
			System.out.println("Total number of data:" + " "+ noOfRows);
			String [] incident_DtREC = new String[noOfRows];
			String [] carrier_Type_Rec=new String[noOfRows];
			String [] carrier_Number_Rec=new String[noOfRows];
			String [] carrier_Name_Rec = new String[noOfRows];
			String [] Eff_Date_Rec = new String[noOfRows];
			String [] Exp_Date_Rec = new String[noOfRows];
			String [] policyNumber_Rec = new String[noOfRows];
			String [] commnRsn_Rec = new String[noOfRows];
			String [] apport_Pect_Rec = new String[noOfRows];
			String [] diag_Desc_Rec = new String[noOfRows];
			String [] icda_Num_Rec = new String[noOfRows];
			String [] icda1_Rec = new String[noOfRows];
			String [] icda2_Rec = new String[noOfRows];
			String [] icda3_Rec = new String[noOfRows];
			String [] icda4_Rec = new String[noOfRows];
			String [] icda5_Rec = new String[noOfRows];
			String [] icda6_Rec = new String[noOfRows];
			String [] icda7_Rec = new String[noOfRows];
			String [] icda8_Rec = new String[noOfRows];
			String [] icda9_Rec = new String[noOfRows];
			String [] icda10_Rec = new String[noOfRows];
			String [] fmUser_Rec = new String[noOfRows];
			String [] fmDt_Rec = new String[noOfRows];
			String [] fmTime_Rec = new String[noOfRows];
			for(int i=0;i<noOfRows;i++)
			{
				JSONObject recoveryDetails = (JSONObject) (jsonObj.getJSONArray("recoveryDetails").get(i));
				incident_DtREC[i] = recoveryDetails.getString("incidentDate");
				lstIncidentDtRec.add(incident_DtREC[i] );

				carrier_Type_Rec[i] = recoveryDetails.getString("carrierType");
				lstCarrierTypeRec.add(carrier_Type_Rec[i]);

				carrier_Number_Rec[i] = recoveryDetails.getString("carrierNumber");
				lstCarrierNbrRec.add(carrier_Number_Rec[i]);

				carrier_Name_Rec[i] = recoveryDetails.getString("carrierName");
				lstCarrierNameRec.add(carrier_Name_Rec[i]);

				Eff_Date_Rec[i] = recoveryDetails.getString("effDate");
				lstEffDateRec.add(Eff_Date_Rec[i]);

				Exp_Date_Rec[i] = recoveryDetails.getString("expDate");
				lstExpDtRec.add(Exp_Date_Rec[i]);

				policyNumber_Rec[i] = recoveryDetails.getString("policyNumber");
				lstPolicyNbrRec.add(policyNumber_Rec[i]);

				commnRsn_Rec[i] = recoveryDetails.getString("commRsn");
				lstCommnRsnRec.add(commnRsn_Rec[i]);

				apport_Pect_Rec[i] = recoveryDetails.getString("appPercent");
				lstApportPectRec.add(apport_Pect_Rec[i]);

				diag_Desc_Rec[i] = recoveryDetails.getString("recoveryDes");
				lstDiagDescRec.add(diag_Desc_Rec[i]);

				icda_Num_Rec[i] = recoveryDetails.getString("icdaInd");
				lstICDANumRec.add(icda_Num_Rec[i]);

				icda1_Rec[i] = recoveryDetails.getString("icda1");
				lstICDA1Rec.add(icda1_Rec[i]);

				icda2_Rec[i] = recoveryDetails.getString("icda2");
				lstICDA2Rec.add(icda2_Rec[i]);

				icda3_Rec[i] = recoveryDetails.getString("icda3");
				lstICDA3Rec.add(icda3_Rec[i]);

				icda4_Rec[i] = recoveryDetails.getString("icda4");
				lstICDA4Rec.add(icda4_Rec[i]);

				icda5_Rec[i] = recoveryDetails.getString("icda5");
				lstICDA5Rec.add(icda5_Rec[i]);

				icda6_Rec[i] = recoveryDetails.getString("icda6");
				lstICDA6Rec.add(icda6_Rec[i]);

				icda7_Rec[i] = recoveryDetails.getString("icda7");
				lstICDA7Rec.add(icda7_Rec[i]);

				icda8_Rec[i] = recoveryDetails.getString("icda8");
				lstICDA8Rec.add(icda8_Rec[i]);

				icda9_Rec[i] = recoveryDetails.getString("icda9");
				lstICDA9Rec.add(icda9_Rec[i]);

				icda10_Rec[i] = recoveryDetails.getString("icda10");
				lstICDA10Rec.add(icda10_Rec[i]);

				fmUser_Rec[i] = recoveryDetails.getString("userId");
				lstFmUserRec.add(fmUser_Rec[i]);

				fmDt_Rec[i] = recoveryDetails.getString("fmDate");
				lstFMDateRec.add(fmDt_Rec[i] );

				fmTime_Rec[i] = recoveryDetails.getString("fmTime");
				lstFmTimeRec.add(fmTime_Rec[i]);
			}


			lstIncidentDtRec.removeAll(Arrays.asList("", null));
			lstCarrierTypeRec.removeAll(Arrays.asList("", null));
			lstCarrierNbrRec.removeAll(Arrays.asList("", null));
			lstCarrierNameRec.removeAll(Arrays.asList("", null));
			lstEffDateRec.removeAll(Arrays.asList("", null));
			lstExpDtRec.removeAll(Arrays.asList("", null));
			lstPolicyNbrRec.removeAll(Arrays.asList("", null));
			lstCommnRsnRec.removeAll(Arrays.asList("", null));
			lstApportPectRec.removeAll(Arrays.asList("", null));
			lstDiagDescRec.removeAll(Arrays.asList("", null));
			lstICDANumRec.removeAll(Arrays.asList("", null));
			lstICDA1Rec.removeAll(Arrays.asList("", null));
			lstICDA2Rec.removeAll(Arrays.asList("", null));
			lstICDA3Rec.removeAll(Arrays.asList("", null));
			lstICDA4Rec.removeAll(Arrays.asList("", null));
			lstICDA5Rec.removeAll(Arrays.asList("", null));
			lstICDA6Rec.removeAll(Arrays.asList("", null));
			lstICDA7Rec.removeAll(Arrays.asList("", null));
			lstICDA8Rec.removeAll(Arrays.asList("", null));
			lstICDA9Rec.removeAll(Arrays.asList("", null));
			lstICDA10Rec.removeAll(Arrays.asList("", null));
			lstFmUserRec.removeAll(Arrays.asList("", null));
			lstFMDateRec.removeAll(Arrays.asList("", null));
			lstFmTimeRec.removeAll(Arrays.asList("", null));


			recoveryDetails_Resp.put("IncidentDT", lstIncidentDtRec);
			recoveryDetails_Resp.put("CarrierTypeRec", lstCarrierTypeRec);
			recoveryDetails_Resp.put("CarrierNumberRec", lstCarrierNbrRec);
			recoveryDetails_Resp.put("CarrierNameRec", lstCarrierNameRec);
			recoveryDetails_Resp.put("Eff Date Rec", lstEffDateRec);
			recoveryDetails_Resp.put("Exp Date Rec", lstExpDtRec);
			recoveryDetails_Resp.put("Policy Number Rec", lstPolicyNbrRec);
			recoveryDetails_Resp.put("Communication Rsn Rec", lstCommnRsnRec);
			recoveryDetails_Resp.put("Apport Pect Rec", lstApportPectRec);
			recoveryDetails_Resp.put("Diag Desc Rec", lstDiagDescRec);
			recoveryDetails_Resp.put("ICDA Num Rec", lstICDANumRec);
			recoveryDetails_Resp.put("ICDA1 Rec", lstICDA1Rec);
			recoveryDetails_Resp.put("ICDA2 Rec", lstICDA2Rec);
			recoveryDetails_Resp.put("ICDA3 Rec", lstICDA3Rec);
			recoveryDetails_Resp.put("ICDA4 Rec", lstICDA4Rec);
			recoveryDetails_Resp.put("ICDA5 Rec", lstICDA5Rec);
			recoveryDetails_Resp.put("ICDA6 Rec", lstICDA6Rec);
			recoveryDetails_Resp.put("ICDA7 Rec", lstICDA7Rec);
			recoveryDetails_Resp.put("ICDA8 Rec", lstICDA8Rec);
			recoveryDetails_Resp.put("ICDA9 Rec", lstICDA9Rec);
			recoveryDetails_Resp.put("ICDA10 Rec", lstICDA10Rec);
			recoveryDetails_Resp.put("FM User Rec", lstFmUserRec);
			recoveryDetails_Resp.put("FM Date Rec", lstFMDateRec);
			recoveryDetails_Resp.put("FM Time Rec", lstFmTimeRec);

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}

		return recoveryDetails_Resp;
	}

	public Map<String,String> investigationDetailsResp(Map<String, String> requestParams) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException, ParseException
	{

		Map<String,String> investigationDetails_Resp = new HashMap();

		try
		{
			JSONObject jsonObj = getJsonResponseAsJSONObject(requestParams);

			investigationDetails_Resp.put("audit Number", (String) jsonObj.getJSONObject("investigationDetail").get("auditNumber")) ;
			investigationDetails_Resp.put("Claim Type",(String) jsonObj.getJSONObject("investigationDetail").get("type"));
			investigationDetails_Resp.put("Request Type",(String) jsonObj.getJSONObject("investigationDetail").get("requestType"));
			investigationDetails_Resp.put("Comment",(String) jsonObj.getJSONObject("investigationDetail").get("comment"));
			investigationDetails_Resp.put("SubmitterId",(String) jsonObj.getJSONObject("investigationDetail").get("ouserID"));
			investigationDetails_Resp.put("Request Status",(String) jsonObj.getJSONObject("investigationDetail").get("requestStatus"));
			investigationDetails_Resp.put("User Id",(String)jsonObj.getJSONObject("investigationDetail").get("userId"));
			investigationDetails_Resp.put("FM Date",(String) jsonObj.getJSONObject("investigationDetail").get("fmDate"));
			investigationDetails_Resp.put("FM Time",(String) jsonObj.getJSONObject("investigationDetail").get("fmTime"));

		}
		catch(Exception e)
		{  
			e.printStackTrace();
		}


		return investigationDetails_Resp;
	}
}