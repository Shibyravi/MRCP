package com.optum.mrcpcosmosatdd.services.common;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

public class JWTToken {

	private static String token = null;  

	/**
	 * Generate JWT Token
	 * 
	 * @return
	 * @throws IllegalArgumentException
	 * @throws UnsupportedEncodingException
	 * @throws JWTCreationException
	 * @throws JSONException
	 */
	public static String generateJWTToken(String baseURL) throws IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, JSONException {
		if (token == null || isExpired() || token.isEmpty()) {
			long nowMillis = System.currentTimeMillis();
			//Token expire every 1 hour
			long expMillis = nowMillis + 3600000;
			Date exp = new Date(expMillis);
  
			String secret = "" , key = "";
			switch(baseURL) {  
			case "http://cparest-cpasystest.ose-ctc-core.optum.com":
				secret= Constants.MRCP_TRANSACTION_SECRET;
				key = Constants.MRCP_TRANSACTION_KEY;
				break;
			case "https://gateway-stage-core.optum.com":
				secret= Constants.MRCPA_SECRET;
				key = Constants.MRCPA_KEY;
				break;
			}

			Algorithm algorithm = Algorithm.HMAC256(secret);
			return JWT.create().withIssuer(key).withExpiresAt(exp).sign(algorithm);
		}
		else {
			Log.info("Token can be re-used : " + token);
			return token;
		}
	}

	/**
	 * Check if the token is expired
	 * 
	 * @return
	 * @throws JSONException
	 */
	private static boolean isExpired() throws JSONException {
		String[] split_string = token.split("\\.");
		String base64EncodedBody = split_string[1];

		Base64 base64Url = new Base64(true);
		String body = new String(base64Url.decode(base64EncodedBody));
		JSONObject jsonObj = new JSONObject(body);

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);

		long expMillis = jsonObj.getLong("exp");
		Date Exp = new Date(expMillis*1000);

		if(Exp.before(now)) {
			Log.info("Token expired");
			return true;
		}
		else {
			Log.info("Token not expired");
			return false;
		}
	}

}