package com.optum.mrcpcosmosatdd.ui.stepdefinitions.search;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.search.COBCarrierDetailsWindow;
import com.optum.mrcpcosmosatdd.ui.pages.search.COBInvestigateIntakeFormWindow;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class COBVerificationIntakeFormSteps extends MRCPTestBase{

		@Then("^The \"([^\"]*)\" labels naming convention should be as per given on COB Verification Intake Form pop up$")
		public void The_Labels_Naming_Convention_Should_Be_As_Per_Given_On_COB_Verification_Intake_Form_PopUp(String strLabels) throws InvalidFormatException, IOException, InterruptedException {
			if (strLabels.substring(0, 1).equalsIgnoreCase("*"))		
				strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));
			
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateLabelsOnPage(strLabels), true);
		}
		
		@Then("^The \"([^\"]*)\" labels should be as per UI Standards on COB Verification Intake Form pop up$")
		public void The_Labels_Should_Be_As_Per_UI_Standards_On_COB_Verification_Intake_Form_PopUp(String strLabels) throws InvalidFormatException, IOException, InterruptedException {	
			if (strLabels.substring(0, 1).equalsIgnoreCase("*"))
				strLabels = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, strLabels, PropertyReader.getInstance().readProperty("Environment"));

			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateLabelsStandardsOnPageforCOB(strLabels), true);	
		}	
		
		@Then("^Validate \"([^\"]*)\" Buttons standards on COB Verification Intake Form pop up$")
		public void buttons_Should_Be_As_Per_UI_Standards_On_COB_Verification_Intake_Form_PopUp(String buttonName) throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateButtonStandards(buttonName), true);
		}
		
		@Then("^Error message field color should be the default application color or color selected by the user on COB Verification Intake Form pop up$")
		public void Error_message_field_color_should_be_the_default_application_color_or_color_selected_by_the_user_On_COB_Verification_Intake_Form_PopUp() throws InvalidFormatException, IOException, InterruptedException {

			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).ValidateErrorMsgBarStandard(), true);
		}
		
		@Then("^Error message field should be disabled and convex on COB Verification Intake Form pop up$")
		public void error_message_field_should_be_disabled_and_convex_On_COB_Verification_Intake_Form_PopUp() throws InvalidFormatException, IOException, InterruptedException {

			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).ValidateErrorMsgBar(), true);
		}
		
		@Then("^verify disabled fields standards on COB Verification Intake Form pop up$")
		public void verify_disabled_fields_standards_On_COB_Verification_Intake_Form_PopUp() throws InvalidFormatException, IOException, InterruptedException {

			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).ValidateDisabledFieldsStandard(), true);
		}
		
		@Then("^The Concave fields should be as per UI Standards on COB Verification Intake Form pop up$")
		public void The_Concave_Fields_Should_Be_As_Per_UI_Standards_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateConcaveFields(), true);
		}
		
		@Then("^Spellcheck will not be invoked on editable fields on COB Verification Intake Form pop up$")
		public void Spellcheck_Will_Not_Be_Invoked_On_Editable_Fields_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).verifySpellCheck(),true);
		}
		
		@Then("^Validate the tabbing through editable fields on COB Verification Intake Form pop up$")
		public void Validate_The_Tabbing_Through_Editable_Fields_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateTabbingOrder(),true);
		}
		
		@Then("^The Cursor should be positioned in the first position of the field based on the data alignment on COB Verification Intake Form pop up$")
		public void The_Cursor_Should_Be_Positioned_In_The_First_Position_Of_The_Field_Based_On_The_Data_Alignment_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateFieldsAlignment(), true);
		}
		
		@Then("^Validate that when field is filled to max then it will auto tab to next editable field on COB Verification Intake Form pop up$")
		public void Validate_That_When_Field_Is_Filled_To_Max_Then_It_Will_Auto_Tab_To_Next_Editable_Field_On_The_Data_Alignment_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateAutoTabAfterFieldFilledToMax(),true);
		}
		
		@Then("^I click on Left and Right Arrow Keys on a editable fields which had data on it on COB Verification Intake Form pop up$")
		public void User_Click_On_Left_And_Right_Arrow_Keys_On_A_Editable_Fields_Which_Had_Data_On_It_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).verifyArrowKeysFunctionality(),true);
		}
		
		@Then("^Verify the static values on COB Verification Intake Form pop up$")
		public void Verify_The_Static_Values_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateStaticValues(),true);
		}
		
		@Then("^Verify the \"([^\"]*)\" dropdown values on COB Verification Intake Form pop up$")
		public void Verify_The_dropdown_Values_On_COB_Verification_Intake_Form_PopUp(String dropdownName) throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateDropdownValues(dropdownName),true);
		}
		
		@Then("^Backspace key should delete the data when data is highlighted in blue on COB Verification Intake Form pop up$")
		public void Backspace_Key_Should_Delete_The_Data_When_Data_Is_Highlighted_In_Blue_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateBackspaceFunctionalityWhenDataHighlightedInBlue(), true);
		}
		
		@Then("^Backspace key should delete the one character to the left when data is not highlighted in blue on COB Verification Intake Form pop up$")
		public void Backspace_Key_Should_Delete_The_One_Character_To_The_Left_When_Data_Is_Not_Highlighted_In_Blue_On_COB_Verification_Intake_Form_PopUp() throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(), true);
		}
		
		@Then("^validate the request type and comment drop down values when review as \"([^\"]*)\"$")
		public void validate_The_Dropdown_Values_based_On_appliedReview_On_COB_Verification_Intake_Form_PopUp(String appliedReview) throws InterruptedException {
			Assert.assertEquals(getPage(COBInvestigateIntakeFormWindow.class).validateDropdownValuesBasedOnAppliedReview(appliedReview), true);
		}
		
		
		
		
}
