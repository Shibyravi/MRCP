package com.optum.mrcpcosmosatdd.services.rest;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.hamcrest.Matchers;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class HospitalReEntryClaimAPIValidation {

	public static Response getJsonResponseAsJSONObjectforRestrtClaim(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://hospital-transactions-unita1.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/hospital/reentry");
		return response;
	}
	
	//Return the response
		public Map<String,String> reviewCodeAndMsg(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
		{

			Map<String,String> restrtClaim_Resp = new HashMap();
			String rvwCode = "";
			String rvwMsg = "";
			
			Response response = getJsonResponseAsJSONObjectforRestrtClaim(requestParams);
			
			/*System.out.println("Response Time : " + response.timeIn(TimeUnit.MILLISECONDS));
			ValidatableResponse valRes = response.then();
			// Asserting response time is less than 2000 milliseconds
			// L just represent long. It is in millisecond by default.
			valRes.time(Matchers.lessThan(3000L),TimeUnit.MILLISECONDS);
			//valRes.time(Matchers.both(Matchers.greaterThanOrEqualTo(2000L)).and(Matchers.lessThanOrEqualTo(1000L)));
*/			 
			JSONObject jsonObj = new JSONObject(response.getBody().asString());
			rvwCode = jsonObj.getString("code");
			rvwMsg = jsonObj.getString("message");
			
			restrtClaim_Resp.put("Return Code", rvwCode);
			restrtClaim_Resp.put("Return Msg", rvwMsg);

			return restrtClaim_Resp;
		}
}
