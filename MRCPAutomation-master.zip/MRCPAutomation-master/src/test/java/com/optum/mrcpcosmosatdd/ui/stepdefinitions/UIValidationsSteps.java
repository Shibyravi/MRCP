package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.pages.HomePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class UIValidationsSteps extends MRCPTestBase {

	/*@Then("^The buttons should be as per UI Standards$")
	public void The_Buttons_Should_Be_As_Per_UI_Standards() throws InterruptedException {
		Assert.assertEquals(getPage(PageName.class).validateAllButtonStandardsOnPage(),true);
	}*/

	/*@Then("^The buttons should be highlighted on Mouse hover$")
	public void The_Buttons_Should_Be_Highlighted_On_Mouse_Hover() throws InterruptedException {
		Assert.assertEquals(getPage(PageName.class).validateAllButtonHighlightOnMouseHover(),true);
	}*/
	
	/*@Then("^The \"([^\"]*)\" labels should be as per UI Standards on $")
	public void The_Labels_Should_Be_As_Per_UI_Standards(String strLabels) {
		Assert.assertEquals(getPage(PageName.class).validateLabelsOnPage(strLabels),true);
	}*/
	
	@When("^User is able to change the Background Color$")
	public void User_Changes_The_Background_Color() throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).changeBackgroundColor(),true);
	}	
	
	@And("^Validate that \"([^\"]*)\" page is on the top$")
	public void Validate_That_Page_Is_On_The_Top(String pageName) throws InterruptedException {
		Assert.assertEquals(getPage(HomePage.class).validatePageDisplayedOnTop(pageName),true);
	}
}