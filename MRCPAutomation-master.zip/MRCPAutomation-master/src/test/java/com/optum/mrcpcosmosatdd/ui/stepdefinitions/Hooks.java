package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import com.cucumber.listener.Reporter;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.helpers.MRCPDriverFactory;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.GeneralFunctions;
import com.optum.mrcpcosmosatdd.ui.utilities.SauceUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 *
 */
public class Hooks {

	public static String jobName;
	protected WebDriver driver;
	private MRCPDriverFactory mrcpDriverFactory;

	/**
	 * Before Scenario
	 * 
	 * @param scenario
	 */
	@Before
	public void beforeScenario(Scenario scenario) {
		List<String> lst = new ArrayList();
		lst.addAll(scenario.getSourceTagNames());
		jobName = scenario.getName();
		//System.out.println(lst.get(0));
		if(!lst.get(0).endsWith("API"))
		{
		mrcpDriverFactory = new MRCPDriverFactory();
		//jobName = scenario.getName();
		//BUILD_NUMBER is coming from Jenkins
		driver = mrcpDriverFactory.getDriver();
		driver.manage().timeouts().implicitlyWait(Constants.IMPLICITWAIT, TimeUnit.SECONDS);
		MRCPTestBase.init();
		}
		Constants.SCENARIONAME = scenario.getName();
		//Constants.FEATURENAME = (scenario.getId().split(";"))[0].replaceAll("-", " ");
		Constants.FEATURENAME = StringUtils.capitalize(scenario.getId().split(";")[0].replaceAll("-", " "));
		Log.startTest(Constants.FEATURENAME, Constants.SCENARIONAME);
		//ExtentReport.startTest(scenario.getName());
	}


	/**
	 * After Scenario
	 * 
	 * @param scenario
	 * @throws IOException
	 * @throws JSONException
	 * @throws InterruptedException
	 */
	@After
	public void afterScenario(Scenario scenario) throws IOException, JSONException, InterruptedException {
		//Take Screen shots
		List<String> lst = new ArrayList();
		lst.addAll(scenario.getSourceTagNames());
		jobName = scenario.getName();
		if(!lst.get(0).contains("API"))
		{
		try{
			if (scenario.isFailed() && PropertyReader.getInstance().readProperty("platform").contains("Local")) {
				String screenshotName = GeneralFunctions.gettimeStamp()+".png";
				String destinationPath = "target/Cucumber-reports/Screenshots/";
				Reporter.addScreenCaptureFromPath(GeneralFunctions.getscreenshot(driver, destinationPath, screenshotName));
				InputStream screenshotStream = new FileInputStream(takeScreenShots(scenario.getName()));
				scenario.embed(IOUtils.toByteArray(screenshotStream), "image/png");
			}
			if (scenario.isFailed() && PropertyReader.getInstance().readProperty("platform").contains("API")) {
				String screenshotName = GeneralFunctions.gettimeStamp()+".png";
				String destinationPath = "target/Cucumber-reports/Screenshots/";
				Reporter.addScreenCaptureFromPath(GeneralFunctions.getscreenshot(driver, destinationPath, screenshotName));
				InputStream screenshotStream = new FileInputStream(takeScreenShots(scenario.getName()));
				scenario.embed(IOUtils.toByteArray(screenshotStream), "image/png");
			}
			if(!((PropertyReader.getInstance().readProperty("platform").contains("Local"))||(PropertyReader.getInstance().readProperty("platform").contains("API")))){
				SauceUtils.updateResults(PropertyReader.getInstance().readProperty("SAUCE_USERNAME"), PropertyReader.getInstance().readProperty("SAUCE_ACCESS_KEY"), !scenario.isFailed(), mrcpDriverFactory.getSessionID());		
				//System.out.println("this will run after scenario is finished, even if it failed");
				String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", mrcpDriverFactory.getSessionID().toString(), scenario.getId().split(";")[0].replace("-", " "));
				System.out.println(message);
			}
			mrcpDriverFactory.destroyDriver();
			Log.endTest();
			//ExtentReport.endTest();
		}
		catch(Exception e){
			mrcpDriverFactory.destroyDriver();
			Log.endTest();
			e.printStackTrace();
		}
		}
		else
		{
			if (scenario.isFailed() && PropertyReader.getInstance().readProperty("platform").contains("API")) {
				String screenshotName = GeneralFunctions.gettimeStamp()+".png";
				String destinationPath = "target/Cucumber-reports/Screenshots/";
				Reporter.addScreenCaptureFromPath(GeneralFunctions.getscreenshot(driver, destinationPath, screenshotName));
				//InputStream screenshotStream = new FileInputStream(takeScreenShots(scenario.getName()));
				//scenario.embed(IOUtils.toByteArray(screenshotStream), "image/png");
				
		}
			Log.endTest();
		}
	}

	private File takeScreenShots(String scenarioName) {
		try {
			File temp = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(temp, new File(System.getProperty("user.dir") + "//target//Cucumber-reports//Screenshots//" + scenarioName + ".png"));
			return temp;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}