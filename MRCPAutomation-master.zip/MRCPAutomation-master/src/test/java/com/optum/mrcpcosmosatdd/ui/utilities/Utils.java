package com.optum.mrcpcosmosatdd.ui.utilities;

import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.mrcpcosmosatdd.ui.pages.BasePage;

import java.io.InputStream;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Utils extends BasePage
{
	public static Properties prop;
	public static InputStream file;
	public static String value, data, filepath;
	public static String locvalue;
	public static String loctype;
	public static WebElement loct;
	public static Properties stbConfigRepository;
	public static Properties stbLocRepository;

	public static boolean verifyElementPresent(By locator){
		if(MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(locator)) != null)
			return true;
		else
			return false;
	}
	
	public static boolean waitTillElementExist(WebDriver driver, By locator) throws InterruptedException {
		for (int i = 0; i <= 100; i++) {
			Thread.sleep(4000);
			try {
				if (driver.findElement(locator).isDisplayed())
					return true;
			} catch (ElementNotVisibleException x) {}
		}
		return false;
	}

	public static boolean waitUntilElementDisplayed(WebDriver driver, String element) throws InterruptedException {
		for (int i = 0; i <= 100; i++) {
			Thread.sleep(4000);
			try {
				if (driver.findElement(By.cssSelector(element)).isDisplayed())
					return true;
			} catch (ElementNotVisibleException x) {}
		}
		return false;
	}
	
	
	
	
     public static WebElement getLocater(String key) {
            try {
            		//stbLocRepository = InitializeFiles.CPALocators;
                   locvalue = stbLocRepository.getProperty(key);

                   if (key.endsWith("_id")) {
                         loct = driver.findElement(By.id(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("_xpath")) {
                         loct = driver.findElement(By.xpath(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("_lnktxt")) {
                         loct = driver.findElement(By.linkText(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("_name")) {
                         loct = driver.findElement(By.name(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("_partlnktxt")) {
                         loct = driver.findElement(By.partialLinkText(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("css")) {
                         loct = driver.findElement(By.cssSelector(locvalue));
                         ElementHighlight(loct);
                   } else if (key.endsWith("tagname")) {
                         loct = driver.findElement(By.tagName(locvalue));
                         ElementHighlight(loct);
                   } else {
                         System.out.println("Locaters not matched");
                   }
            } catch (Exception e) {
                  // Reports.fail("Get Locator" ,e.toString());
                   e.printStackTrace();

            }
            return loct;

     }
     
     
     public static void ElementHighlight(WebElement element) {
 		((JavascriptExecutor) driver).executeScript(
 				"arguments[0].setAttribute('style', 'background:yellow; border:2px solid red;');", element);
 		try {
 			Thread.sleep(1000);
 		} catch (InterruptedException e) {
 			//Reports.fail("Element HighLight",e.toString());
 			e.printStackTrace();
 		}
 		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('style', 'border: solid 2px green ');",
 				element);
 	}

}