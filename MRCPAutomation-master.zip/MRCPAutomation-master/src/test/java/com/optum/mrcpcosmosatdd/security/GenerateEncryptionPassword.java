package com.optum.mrcpcosmosatdd.security;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import com.optum.mrcpcosmosatdd.ui.helpers.Constants;

public class GenerateEncryptionPassword {

	private static final String AES = "AES";

	private static String byteArrayToHexString(byte[] b) {
		StringBuffer sb = new StringBuffer(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			int v = b[i] & 0xff;
			if (v < 16) {
				sb.append('0');
			}
			sb.append(Integer.toHexString(v));
		}
		return sb.toString().toUpperCase();
	}

	private static byte[] hexStringToByteArray(String s) {
		byte[] b = new byte[s.length() / 2];
		for (int i = 0; i < b.length; i++) {
			int index = i * 2;
			int v = Integer.parseInt(s.substring(index, index + 2), 16);
			b[i] = (byte) v;
		}
		return b;
	}

	private static String generateEncryptedPassword(String strPassword) throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {

		String key = Constants.PRIVATEKEY;

		byte[] bytekey = hexStringToByteArray(key);
		SecretKeySpec sks = new SecretKeySpec(bytekey, GenerateEncryptionPassword.AES);
		Cipher cipher = Cipher.getInstance(GenerateEncryptionPassword.AES);
		cipher.init(Cipher.ENCRYPT_MODE, sks, cipher.getParameters());
		byte[] encrypted = cipher.doFinal(strPassword.getBytes());
		return byteArrayToHexString(encrypted);
	}

	public static void main(String args[]) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
		String password = "Tata@123";

		System.out.println("****************  Encrypted Password  ****************");
		System.out.println(generateEncryptedPassword(password));
		System.out.println("****************  Encrypted Password  ****************");
	}
}