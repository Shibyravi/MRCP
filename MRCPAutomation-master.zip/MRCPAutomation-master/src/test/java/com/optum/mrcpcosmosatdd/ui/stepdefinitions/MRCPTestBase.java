package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import org.openqa.selenium.WebDriver;

import com.optum.mrcpcosmosatdd.ui.helpers.MRCPDriverFactory;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */
public class MRCPTestBase {

	protected static WebDriver driver;
	private static List<Object> pages = new ArrayList<>();

	static {
		// One time initialization code
	}

	/**
	 * Initialize the objects. These will be called from Hooks
	 */
	public static void init() {
		driver = new MRCPDriverFactory().getDriver();
	}

	public static WebDriver getDriver() {
		return driver;
	}


	/**
	 * @param clazz
	 * @param <T>
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> T getPage(Class<T> clazz) {
		for (Object page : pages) {
			if (page.getClass() == clazz)
				return (T) page;
		}
		T page = null;
		try {
			page = clazz.newInstance();
		} catch (InstantiationException e) {
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		pages.add(page);
		return page;
	}


}
