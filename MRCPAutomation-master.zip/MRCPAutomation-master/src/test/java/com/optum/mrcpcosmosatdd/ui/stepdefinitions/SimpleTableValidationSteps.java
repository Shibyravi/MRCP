package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.SimpleTableAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class SimpleTableValidationSteps extends MRCPTestBase {
	
	File JSON_PHYSIMTABVALIDSUCCESS;
	File JSON_PHYSIMTABVALIDSUCCESSFALSE;
	File JSON_PHYSIMTABVALIDINVLDSITE;
	File JSON_PHYSIMTABVALIDINVLDAUDT;
	File JSON_PHYSIMTABVALIDINVLDSUBAUDT;
	File JSON_PHYSIMTABVALIDINVLDCLMTYPE;
	File JSON_PHYSIMTABVALIDBLANKSITE;
	File JSON_PHYSIMTABVALIDBLANKAUDIT;
	File JSON_PHYSIMTABVALIDSUBAUDITMISSING;
	File JSON_PHYSIMTABVALIDBLANKTYPE;
	
	
	// For Hospital
	File JSON_HOSPSIMTABVALIDSUCCESS;
	File JSON_HOSPSIMTABVALIDINVLDSITE;
	File JSON_HOSPSIMTABVALIDINVLDAUDT;
	File JSON_HOSPSIMTABVALIDMISSINGSUBAUDT;
	File JSON_HOSPSIMTABVALIDINVLDCLMTYPE;
	File JSON_HOSPSIMTABVALIDBLANKSITE;
	File JSON_HOSPSIMTABVALIDMISSINGAUDIT;
	File JSON_HOSPSIMTABVALIDBLANKTYPE;
	
	@When("^I get the request body parameter from payload json file for Physician simple table validation$")
	public void I_get_the_body_Params_From_Json_Payload_Phy()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_PHYSIMTABVALIDSUCCESS = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDSUCCESS"));
		JSON_PHYSIMTABVALIDSUCCESSFALSE = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDSUCCESSFALSE"));
		JSON_PHYSIMTABVALIDINVLDSITE = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDINVLDSITE"));
		JSON_PHYSIMTABVALIDINVLDAUDT = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDINVLDAUDT"));
		JSON_PHYSIMTABVALIDINVLDSUBAUDT = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDINVLDSUBAUDT"));
		JSON_PHYSIMTABVALIDINVLDCLMTYPE = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDINVLDCLMTYPE"));
		JSON_PHYSIMTABVALIDBLANKSITE = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDBLANKSITE"));
		JSON_PHYSIMTABVALIDBLANKAUDIT = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDBLANKAUDIT"));
		JSON_PHYSIMTABVALIDSUBAUDITMISSING = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDSUBAUDITMISSING"));
		JSON_PHYSIMTABVALIDBLANKTYPE = new File(PropertyReader.getInstance().readProperty("JSON_PHYSIMTABVALIDBLANKTYPE"));
		
		
	}
	
	@When("^I get the request body parameter from payload json file for Hospital simple table validation$")
	public void I_get_the_body_Params_From_Json_Payload_Hosp()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_HOSPSIMTABVALIDSUCCESS = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDSUCCESS"));
		JSON_HOSPSIMTABVALIDINVLDSITE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDINVLDSITE"));
	    JSON_HOSPSIMTABVALIDINVLDAUDT = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDINVLDAUDT"));
	    JSON_HOSPSIMTABVALIDMISSINGSUBAUDT =new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDMISSINGSUBAUDT"));
	    JSON_HOSPSIMTABVALIDINVLDCLMTYPE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDINVLDCLMTYPE"));
	    JSON_HOSPSIMTABVALIDBLANKSITE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDBLANKSITE"));
	    JSON_HOSPSIMTABVALIDMISSINGAUDIT = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDMISSINGAUDIT"));
	    JSON_HOSPSIMTABVALIDBLANKTYPE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPSIMTABVALIDBLANKTYPE"));
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when claim Successfully validated$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESS);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when claim Successfully validated$")
	public void verify_The_Return_CodeHosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDSUCCESS);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when site is invalid$")
	public void verify_The_Return_Code_Site_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when site is invalid$")
	public void verify_The_Return_Code_Site_Invalid_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when site is blank$")
	public void verify_The_Return_Code_Site_Blank(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when site is blank$")
	public void verify_The_Return_Code_Site_Blank_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when Audit is blank$")
	public void verify_The_Return_Code_Audit_Blank(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKAUDIT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when Audit is missing$")
	public void verify_The_Return_Code_Audit_Missing(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGAUDIT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when type is blank$")
	public void verify_The_Return_Code_Type_Blank(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKTYPE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when type is blank$")
	public void verify_The_Return_Code_Type_Blank_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKTYPE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when Sub Audit is missing$")
	public void verify_The_Return_Code_SubAudit_Missing(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUBAUDITMISSING);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when audit is invalid$")
	public void verify_The_Return_Code_Audit_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when audit is invalid$")
	public void verify_The_Return_Code_Audit_Invalid_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when sub audit is invalid$")
	public void verify_The_Return_Code_SubAudit_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSUBAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when sub audit is missing$")
	public void verify_The_Return_Code_SubAudit_Missing_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGSUBAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when claim type is invalid$")
	public void verify_The_Return_Code_ClmType_Invalid(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital simple table when claim type is invalid$")
	public void verify_The_Return_Code_ClmType_Invalid_Hosp(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Pysician simple table when claim Successfully validated but not eligible for negative payee$")
	public void verify_The_Return_Code_False(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESSFALSE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when claim Successfully validated$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESS);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when claim Successfully validated$")
	public void verify_The_Return_MsgHosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDSUCCESS);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when site is invalid$")
	public void verify_The_Return_Msg_Invalid_site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when site is invalid$")
	public void verify_The_Return_Msg_Invalid_site_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when site is blank$")
	public void verify_The_Return_Msg_Blank_site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when site is blank$")
	public void verify_The_Return_Msg_Blank_site_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when Audit is missing$")
	public void verify_The_Return_Msg_Missing_Audit(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGAUDIT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when type is blank$")
	public void verify_The_Return_Msg_Blank_Type(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKTYPE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when type is blank$")
	public void verify_The_Return_Msg_Blank_Type_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKTYPE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when Sub Audit is missing$")
	public void verify_The_Return_Msg_Sub_Audit_Missing(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUBAUDITMISSING);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when audit is invalid$")
	public void verify_The_Return_Msg_Invalid_Audit(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when audit is invalid$")
	public void verify_The_Return_Msg_Invalid_Audit_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when sub audit is invalid$")
	public void verify_The_Return_Msg_Invalid_SubAudit(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSUBAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when Audit is blank$")
	public void verify_The_Return_Msg_Blank_Audit(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKAUDIT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when sub audit is missing$")
	public void verify_The_Return_Msg_Missing_SubAudit_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGSUBAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when claim type is invalid$")
	public void verify_The_Return_Msg_Invalid_ClmType(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital simple table when claim type is invalid$")
	public void verify_The_Return_Msg_Invalid_ClmType_Hosp(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Pysician simple table when claim Successfully validated but not eligible for negative payee$")
	public void verify_The_Return_Msg_False(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESSFALSE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review code from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when claim Successfully validated$")
	public void verify_The_Balance_forward(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESS);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when claim Successfully validated$")
	public void verify_The_Balance_forwardHosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDSUCCESS);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when site is invalid$")
	public void verify_The_Balance_forward_Invld_Site(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSITE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when site is invalid$")
	public void verify_The_Balance_forward_Invld_Site_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDSITE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when site is blank$")
	public void verify_The_Balance_forward_Blank_Site(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKSITE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when site is blank$")
	public void verify_The_Balance_forward_Blank_Site_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKSITE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when Audit is blank$")
	public void verify_The_Balance_forward_Blank_Audit(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKAUDIT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when Audit is missing$")
	public void verify_The_Balance_forward_Missing_Audit(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGAUDIT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when type is blank$")
	public void verify_The_Balance_forward_Blank_Type(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDBLANKTYPE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when type is blank$")
	public void verify_The_Balance_forward_Blank_Type_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDBLANKTYPE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when Sub Audit is missing$")
	public void verify_The_Balance_forward_Sub_Audit_Missing(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUBAUDITMISSING);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when audit is invalid$")
	public void verify_The_Balance_forward_Invld_Audit(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDAUDT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when audit is invalid$")
	public void verify_The_Balance_forward_Invld_Audit_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDAUDT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when sub audit is invalid$")
	public void verify_The_Balance_forward_Invld_SubAudit(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDSUBAUDT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when sub audit is missing$")
	public void verify_The_Balance_forward_Missing_SubAudit_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDMISSINGSUBAUDT);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when claim type is invalid$")
	public void verify_The_Balance_forward_Invld_ClmType(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Hospital simple table when claim type is invalid$")
	public void verify_The_Balance_forward_Invld_ClmType_Hosp(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_HOSPSIMTABVALIDINVLDCLMTYPE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
	
	@When("^Verify the Balance forward as \"([^\"]*)\" of Pysician simple table when claim Successfully validated but not eligible for negative payee$")
	public void verify_The_Balance_forward_False(String balForwd)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (balForwd.length() >0 && balForwd.substring(0, 1).equalsIgnoreCase("*"))
			balForwd = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, balForwd, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(SimpleTableAPIValidation.class).simpleTableResponse(JSON_PHYSIMTABVALIDSUCCESSFALSE);
		System.out.println("Balance forward from Response:"+" "+ response_ClaimsDetails.get("Balance Forward"));
		System.out.println("Balance forward from Database:"+" "+balForwd);
		Assert.assertTrue(response_ClaimsDetails.get("Balance Forward").equals(balForwd), "Failed:Balance forward are not verified from response and Data base through data sheet.");
		Log.info("Verified:Balance forward are verified from Service response and Database.");
	}
}
