package com.optum.mrcpcosmosatdd.services.rest;

import static io.restassured.RestAssured.baseURI;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.services.common.JWTToken;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class HospitalHO626ClearReviewValidation {

	public static Response getJsonResponseAsJSONObjectforClaimsObject(File requestBody) throws JSONException, IllegalArgumentException, UnsupportedEncodingException, JWTCreationException, ParseException, InterruptedException{
		RestAssured.baseURI ="http://cobtransaction-unita1-hotfix.origin-ctc-core-nonprod.optum.com"; 
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.body(requestBody);
		Response response = request.post("/hospital/clear-review");
		return response;
	}

	//Return the response
	public Map<String,String> reviewCodeAndMsg(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		Map<String,String> clearReview_Resp = new HashMap();
		String rvwCode ="";
		String rvwMsg = "";
		
		Response response = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		
			rvwCode = jsonObj.getString("code");
			rvwMsg = jsonObj.getString("message");
		
		clearReview_Resp.put("Review Code", rvwCode);
		clearReview_Resp.put("Review Msg", rvwMsg);

		return clearReview_Resp;
	}
	
	public Map<String,List<String>> reviewStatus(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		Map<String,List<String>> clearReview_Resp = new HashMap();
		String rvwNbr ="";
		String rvwStatus = "";
		List<String> rvwNbrlst = new ArrayList();
		List<String> rvwStatuslst = new ArrayList();
		Response response = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		JSONArray jsonArray = jsonObj.getJSONArray("review");
		for(int i=0;i<jsonArray.length();i++)
		{
			rvwNbr = ((JSONObject)jsonArray.get(i)).getString("reviewNbr");
			rvwStatus = ((JSONObject)jsonArray.get(i)).getString("clear");
			rvwNbrlst.add(rvwNbr);
			rvwStatuslst.add(rvwStatus);
		}
		clearReview_Resp.put("Review Nbr", rvwNbrlst);
		clearReview_Resp.put("Review Status", rvwStatuslst);

		return clearReview_Resp;
	}
	
	public List<String> reviewStatusForClearingReview(File requestParams) throws IllegalArgumentException, JWTCreationException, JSONException, ParseException, InterruptedException, JsonParseException, JsonMappingException, IOException
	{

		String rvwCode ="";
		String rvwMsg ="";
		List<String> rvwNbr = new ArrayList();
		List<String> rvwClrStatus = new ArrayList();
		List<String> clearReview_Resp = new ArrayList();
		Response response = getJsonResponseAsJSONObjectforClaimsObject(requestParams);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		rvwCode = jsonObj.getString("code");
		rvwMsg= jsonObj.getString("message");
		JSONArray jsonArray = jsonObj.getJSONArray("review");
		for(int i=0;i<jsonArray.length();i++)
		{
			rvwNbr.add(jsonArray.getJSONObject(i).getString("reviewNbr"));
			rvwClrStatus.add(jsonArray.getJSONObject(i).getString("clear"));
		}
		
		clearReview_Resp.add(rvwCode);
		clearReview_Resp.add(rvwMsg);
		clearReview_Resp.addAll(rvwNbr);
		clearReview_Resp.addAll(rvwClrStatus);
	
		return clearReview_Resp;
	}
}
