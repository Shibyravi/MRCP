package com.optum.mrcpcosmosatdd.reporting;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriverException;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.GeneralFunctions;

/**
 * @author sgupt228
 *
 */
public class ExtentReport extends BasePage{

	private static ExtentReports extent;
	private static ExtentTest logger;

	private static String reportPath;
	private static String screenshotpath;

	private static String reportFolderPath;
	private static String reportParentFolderPath;
	private static String screenshotFolderPath;

	private static File reportParentFolder;
	private static File reportFolder;
	private static File screenshotFolder;


	/**
	 * This function is to start the Extent Report and initialize the reports and screenshot folder path
	 */
	public static void startReport(){
		//ExtentReports(String filePath,Boolean replaceExisting) 
		//filepath - path of the file, in .htm or .html format - path where your report needs to generate. 
		//replaceExisting - Setting to overwrite (TRUE) the existing file or append to it
		//True (default): the file will be replaced with brand new markup, and all existing data will be lost. Use this option to create a brand new report
		//False: existing data will remain, new tests will be appended to the existing report. If the the supplied path does not exist, a new file will be created.

		//Main Report Folder
		reportParentFolderPath = System.getProperty("user.dir") + "\\Reports";
		reportParentFolder = new File(reportParentFolderPath);
		// if the directory does not exist, create it
		if (!reportParentFolder.exists()) {
			reportParentFolder.mkdir();     
		}

		//Report Folder on the basis of Date
		reportFolderPath = reportParentFolderPath + "\\" + GeneralFunctions.gettimeStamp();
		reportFolder = new File(reportFolderPath);
		// if the directory does not exist, create it
		if (!reportFolder.exists()) {
			reportFolder.mkdir();     
		}

		//Screenshot Folder
		screenshotFolderPath = reportFolderPath + "\\Screenshots";
		screenshotFolder = new File(screenshotFolderPath);
		// if the directory does not exist, create it
		if (!screenshotFolder.exists()) {
			screenshotFolder.mkdir();     
		}

		//HTML Report Path
		reportPath = reportFolderPath +"\\MRCP_ExtentReport.html";
		extent = new ExtentReports (reportPath, true);
		//extent.addSystemInfo("Environment","Environment Name")
		extent
		.addSystemInfo("Host Name", "Optum")
		.addSystemInfo("Environment", "MRCP")
		.addSystemInfo("User Name", "Shashank Gupta");
		//loading the external xml file (i.e., extent-config.xml) which was placed under the base directory
		//You could find the xml file below. Create xml file in your project and copy paste the code mentioned below
		extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
	}

	/**
	 * This function is to start the individual Test
	 * 
	 * @param testName
	 */
	public static void startTest(String testName){
		//extent.startTest("TestCaseName", "Description")
		//TestCaseName – Name of the test
		//Description – Description of the test
		//Starting test
		logger = extent.startTest(testName);
	}

	/**
	 * This function is to Pass the individual Test without screenshot
	 * 
	 * @param strStepName
	 * @param strDescription
	 */
	public static void passTest(String strStepName, String strDescription) throws IOException{
		//Assert.assertTrue(true);
		//To generate the log when the test case is passed
		logger.log(LogStatus.PASS, strStepName, strDescription);
	}

	/**
	 * This function is to Pass the individual Test with screenshot
	 * 
	 * @param strDetails
	 */
	public static void passTestWithScreenshot(String strDetails) throws IOException, WebDriverException, InterruptedException{
		//Assert.assertTrue(true);
		//To generate the log when the test case is passed
		screenshotpath = GeneralFunctions.getscreenshot(driver, screenshotFolderPath,"");
		logger.log(LogStatus.PASS, strDetails, logger.addScreenCapture(screenshotpath));
	}
	
	/**
	 * This function is to Fail the individual Test without screenshot
	 * 
	 * @param strStepName
	 * @param strDescription
	 */
	public static void failTest(String strStepName, String strDescription) throws IOException{
		//Assert.assertTrue(false);
		//To generate the log when the test case is failed
		logger.log(LogStatus.FAIL, strStepName, strDescription);
		//logger.log(LogStatus.FAIL, message, logger.addScreenCapture(screenshotpath));
	}

	/**
	 * This function is to Fail the individual Test with screenshot
	 * 
	 * @param strDetails
	 */
	public static void failTestWithScreenshot(String strDetails) throws IOException, WebDriverException, InterruptedException{
		//Assert.assertTrue(false);
		//To generate the log when the test case is failed
		screenshotpath = GeneralFunctions.getscreenshot(driver, screenshotFolderPath,"");
		logger.log(LogStatus.FAIL, strDetails, logger.addScreenCapture(screenshotpath));
		//logger.log(LogStatus.FAIL, strDetails, logger.addScreenCapture(screenshotpath));
	}

	/**
	 * This function is to Fail the individual Test without screenshot
	 * 
	 * @param strStepName
	 * @param strDescription
	 */
	public static void skipTest(String strStepName, String strDescription) throws IOException{
		//To generate the log when the test case is skipped
		logger.log(LogStatus.SKIP, strStepName, strDescription);
	}

	/**
	 * This function is to Skip the individual Test with screenshot
	 * 
	 * @param strDetails
	 */
	public static void skipTestWithScreenshot(String strDetails) throws IOException, WebDriverException, InterruptedException{
		//To generate the log when the test case is skipped
		screenshotpath = GeneralFunctions.getscreenshot(driver, screenshotFolderPath,"");
		logger.log(LogStatus.SKIP, strDetails, logger.addScreenCapture(screenshotpath));
	}
	
	/**
	 * This function is to add a Information for the individual Test without screenshot
	 * 
	 * @param strStepname
	 * @param strDescription
	 */
	public static void infoTest(String strStepname,String strDescription) {
		//test.log(LogStatus.INFO, desc);
		logger.log(LogStatus.INFO, strStepname ,strDescription);
	}

	/**
	 * This function is to add a Warning for the individual Test without screenshot
	 * 
	 * @param strDescription
	 */
	public static void warningTest(String strDescription)
	{
		//test.log(LogStatus.WARNING, details,"p{font-size:20px;} .test{background-color:#000 !important;color:#fff !important;}");
		logger.log(LogStatus.INFO, "HTML", "This will be <span style='font-weight:bold;'>"+strDescription+"</span>");
	}
	
	/**
	 * This function is to end the running Test instance
	 */
	public static void endTest(){
		// ending test
		//endTest(logger) : It ends the current test and prepares to create HTML report
		extent.endTest(logger);
	}

	/**
	 * This function is to end the running Report instance
	 */
	public static void endReport(){

		// writing everything to document
		//flush() - to write or update test information to your report. 
		extent.flush();
		//Call close() at the very end of your session to clear all resources. 
		//If any of your test ended abruptly causing any side-affects (not all logs sent to ExtentReports, information missing), this method will ensure that the test is still appended to the report with a warning message.
		//You should call close() only once, at the very end (in @AfterSuite for example) as it closes the underlying stream. 
		//Once this method is called, calling any Extent method will throw an error.
		//close() - To close all the operation
		extent.close();
	}
}