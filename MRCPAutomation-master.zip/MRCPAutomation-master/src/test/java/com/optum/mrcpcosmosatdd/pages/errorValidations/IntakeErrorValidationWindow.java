package com.optum.mrcpcosmosatdd.pages.errorValidations;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;

public class IntakeErrorValidationWindow extends BasePage{
	
	private By windowRootEle = By.id("investigationoPup");

	//Input disable fields locators
	private By title_Input = By.id("inv_title");
	private By platform_Input = By.id("inv_claim_plateform");
	private By memFName_Input = By.id("inv_mem_fisrt_name");
	private By memLName_Input = By.id("inv_mem_last_name");
	private By grpNbr_Input = By.id("inv_grup_num");
	private By memID_Input = By.id("inv_mem_id");
	private By div_Input = By.id("inv_site");
	private By VerificationError_Input = By.id("IntakeFormErrorMsgBar");

	// Input enabled fields locators
	private By COBReview_Select = By.id("inv_cob_review");
	private By reqType_Select = By.id("inv_req_type");
	private By auditNbr_Input = By.id("inv_audit");
	private By asOfDate_Input = By.id("inv_as_of_date");
	private By comment_Select = By.id("inv_comment");
	private By othrInsurIndicator_Input = By.id("other_insurance_ind");

	//Radio buttons
	private By Phy_Radio = By.id("audit_phy_type");
	private By hosp_Radio = By.id("audit_hosp_type");

	//Buttons
	private By button_Submit = By.id("inv_submit");
	private By button_Close = By.id("inv_closeBtn");

	public By getWindowRoot() {
		return windowRootEle;
	}
	
	public String performSubmit(String cobReview, String requestType, String auditNumber, String asOfDate, String comment) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			//Select the Cob Review 
			selectDropDownBoxValue(COBReview_Select, cobReview);
			//Select the Request Type 
			selectDropDownBoxValue(reqType_Select, requestType);
			//Enter the audit number
			enterText(auditNbr_Input, auditNumber);
			//Enter as of date
			enterText(asOfDate_Input, asOfDate);
			//Select comment
			selectDropDownBoxValue(comment_Select, comment);
			
			//Click on Inquire Button
			mouseClick(button_Submit);
			Thread.sleep(15000);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(VerificationError_Input).getAttribute("value");
	}
	
	
	public boolean validateErrorMsg(String expErrorMsg , String actErroMsg) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			Assert.assertTrue(expErrorMsg.equals(actErroMsg), "Failed: Actual and Expected error msgs are not same");
			Log.info("Verified:Error message verified");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}


}
