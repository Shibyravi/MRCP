package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.services.rest.PhysicianCL601ClearReviewValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class PhysicianCL601ClearReviewSteps extends MRCPTestBase{

	File jsonClrRevwFile;
	File JSON_AlrdyCrdRvw;
	File JSON_ClrRvw;
	File JSON_PHYCLRRVW;

	@When("^I get the request body parameter from payload json file$")
	public void get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		jsonClrRevwFile = new File(PropertyReader.getInstance().readProperty("JSON_AUTHPAYLOAD"));
		JSON_AlrdyCrdRvw = new File(PropertyReader.getInstance().readProperty("JSON_AlrdyCrdRvw"));
		JSON_ClrRvw = new File(PropertyReader.getInstance().readProperty("JSON_clrRvw"));
		JSON_PHYCLRRVW = new File(PropertyReader.getInstance().readProperty("JSON_PHYCLRRVW"));
	}

	@When("^Verify the Review Return code as \"([^\"]*)\" of physician claim for all subaudits$")
	public void verify_The_Review_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwCode);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(jsonClrRevwFile);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(expRespDB), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}

	@When("^Verify the Review Return code as \"([^\"]*)\" of physician claim for all subaudits when Review already cleared$")
	public void verify_The_Review_Return_Code_For_alreadyclearedReview(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwCode);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(JSON_AlrdyCrdRvw);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(expRespDB), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Review Return code as \"([^\"]*)\" of physician claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Code_For_ClearingTheReview(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwCode);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(JSON_ClrRvw);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(expRespDB), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}

	@When("^Verify the Review Return Message as \"([^\"]*)\" of physician claim for all subaudits$")
	public void verify_The_Review_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwMsg);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(jsonClrRevwFile);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(expRespDB), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}

	@When("^Verify the Review Return Message as \"([^\"]*)\" of physician claim for all subaudits when Review already cleared$")
	public void verify_The_Review_Return_Msg_For_alreadyclearedReview(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwMsg);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(JSON_AlrdyCrdRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(expRespDB), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Review Return Message as \"([^\"]*)\" of physician claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Msg_For_clearingReview(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwMsg);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewCodeAndMsg(JSON_ClrRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(expRespDB), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}

	@When("^Verify the Return Review Number as \"([^\"]*)\" of physician claim for all subaudits$")
	public void verify_The_Review_Return_Nbr(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(jsonClrRevwFile);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Number"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Number").equals(expRespDB), "Failed:Review number are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review number are verified from Service response and Database.");
	}

	@When("^Verify the Return Review Number as \"([^\"]*)\" of physician claim for all subaudits when Review already cleared$")
	public void verify_The_Review_Return_Nbr_For_alreadyclearedReview(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(JSON_AlrdyCrdRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Number"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Number").equals(expRespDB), "Failed:Review number are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review number are verified from Service response and Database.");
	}
	
	@When("^Verify the Return Review Number as \"([^\"]*)\" of physician claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Nbr_For_clearingReview(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(JSON_ClrRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Number"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Number").equals(expRespDB), "Failed:Review number are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review number are verified from Service response and Database.");
	}

	@When("^Verify the Return Review Status as \"([^\"]*)\" of physician claim for all subaudits$")
	public void verify_The_Review_Return_Status(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(jsonClrRevwFile);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return Review Status as \"([^\"]*)\" of physician claim for all subaudits when Review already cleared$")
	public void verify_The_Review_Return_Status_For_alreadyclearedReview(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(JSON_AlrdyCrdRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return Review Status as \"([^\"]*)\" of physician claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Status_For_clearingReview(String rvwNbr)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwNbr.length() >0 && rvwNbr.substring(0, 1).equalsIgnoreCase("*"))
			rvwNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwNbr, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwNbr);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		Map<String,List<String>> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatus(JSON_ClrRvw);
		System.out.println("Review messages from Response:"+" "+ response_ClaimsDetails.get("Review Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Status").equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Review Return status as \"([^\"]*)\" of physician claim for all subaudits when Review is not clear$")
	public void verify_The_Review_Return_Status_For_ClearingTheReview(String rvwStatus)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwStatus.length() >0 && rvwStatus.substring(0, 1).equalsIgnoreCase("*"))
			rvwStatus = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwStatus, PropertyReader.getInstance().readProperty("Environment"));
		List<String> expRespDB =  getPage(COBCarrierDetailsRestAPIWindow.class).ExpectedValuesDB2(rvwStatus);
		System.out.println("Claims Details Expected Response from DB through DataSheet"+" "+expRespDB);

		//Response from Service
		List<String> response_ClaimsDetails = getPage(PhysicianCL601ClearReviewValidation.class).reviewStatusForClearingReview(JSON_PHYCLRRVW);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails);
		Assert.assertTrue(response_ClaimsDetails.equals(expRespDB), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}

}
