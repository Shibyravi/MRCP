package com.optum.mrcpcosmosatdd.ui.frameworkutils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;

public abstract class MRCPSeleniumUtils {

    public static By element(String elementKey) {

        MRCPPageElement elementData = new MRCPPageElement(elementKey);
        String element_value = MRCPPageJsonUtil.findPageElementValue(elementData);
        if (element_value == null)
            return null;

        By first = null;
        String[] values = element_value.split("\\|\\|");
        for (String retval : values) {
            elementData.parseResult(retval);
            if (elementData.elementValue == null)
                Assert.fail("ERROR - UI: element '" + elementKey + "' is not defined.");
            if (elementData.elementLocator == null)
                Assert.fail("ERROR - UI: element locator is not recognizable.");
            By el = findLocatorMethod(elementData.elementLocator, elementData.elementValue);
            if (values.length == 1)
                return el;

            if (first == null)
                first = el;
            try {
                if (findElement(el).isDisplayed())
                    return el;
            } catch (Exception e) {
                // try the next one (if it exists)
            }
        }
        return first;
    }


    /**
     * Retrieves the first element
     *
     * @param selector By selector to use
     * @return first element selected by el
     */
    public static WebElement findElement(By selector) {
        try {
            return MRCPTestBase.getDriver().findElement(selector);
        } catch (Exception ex) {
            Assert.fail("--> no element found with selector: " + selector);
        }
        return null;
    }

    private static By findLocatorMethod(String locator, String value) {
        switch (locator) {
            case "id":
                return By.id(value);
            case "linkText":
                return By.linkText(value);
            case "name":
                return By.name(value);
            case "partialLinkText":
                return By.partialLinkText(value);
            case "tagName":
                return By.tagName(value);
            case "xpath":
                return By.xpath(value);
            case "className":
                return By.className(value);
            case "cssSelector":
                return By.cssSelector(value);
            default:
                return null;
        }
    }


}
