package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.TotalReversalPhysicianAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class TotalReversalPhySubauditSteps extends MRCPTestBase {

	File JSON_TOTALREVRSLFAILURESUBADT;
	File JSON_TOTALREVRSLBLNKUSRIDSUBADT;
	File JSON_TOTALREVRSLBLNKSITESUBADT;
	File JSON_TOTALREVRSLBLNKCLMRVSLREASONSUBADT;
	File JSON_TOTALREVRSLBLNKCAUSECODESUBADT;
	File JSON_TOTALREVRSLBLNKBYPASSWAITSUBADT;
	File JSON_TOTALREVRSLBLNKREFUNDSUBADT;
	File JSON_TOTALREVRSLBLNKCLMCORRREQSUBADT;
	File JSON_TOTALREVRSLBLNKOTHRINFOSUBADT;
	
	@When("^I get the request body parameter from payload json file for Total Reversal Physician on sub audit$")
	public void I_get_the_body_Params_From_Json_Payload_File()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_TOTALREVRSLFAILURESUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLFAILURESUBADT"));
		JSON_TOTALREVRSLBLNKUSRIDSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKUSRIDSUBADT"));
		JSON_TOTALREVRSLBLNKSITESUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKSITESUBADT"));
		JSON_TOTALREVRSLBLNKCLMRVSLREASONSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCLMRVSLREASONSUBADT"));
		JSON_TOTALREVRSLBLNKCAUSECODESUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCAUSECODESUBADT"));
		JSON_TOTALREVRSLBLNKBYPASSWAITSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKBYPASSWAITSUBADT"));
		JSON_TOTALREVRSLBLNKREFUNDSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKREFUNDSUBADT"));
		JSON_TOTALREVRSLBLNKCLMCORRREQSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKCLMCORRREQSUBADT"));
		JSON_TOTALREVRSLBLNKOTHRINFOSUBADT = new File(PropertyReader.getInstance().readProperty("JSON_TOTALREVRSLBLNKOTHRINFOSUBADT"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when claim already in reversal state$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLFAILURESUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	} 
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when claim already in reversal state$")
	public void verify_The_Return_Msg_Failure(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLFAILURESUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when user id is blank$")
	public void verify_The_Return_Code_BlankUsrId(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKUSRIDSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when user id is blank$")
	public void verify_The_Return_Msg_Blank_UsrId(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKUSRIDSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when site is blank$")
	public void verify_The_Return_Code_BlankSite(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKSITESUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when site is blank$")
	public void verify_The_Return_Msg_Blank_Site(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKSITESUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when claim reversal reason is blank$")
	public void verify_The_Return_Code_Blank_claimReversalReason(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCLMRVSLREASONSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when claim reversal reason is blank$")
	public void verify_The_Return_Msg_Blank_claimReversalReason(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCLMRVSLREASONSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when cause code is blank$")
	public void verify_The_Return_Code_Blank_CauseCode(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCAUSECODESUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when cause code is blank$")
	public void verify_The_Return_Msg_Blank_CauseCode(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCAUSECODESUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when bypass wait is blank$")
	public void verify_The_Return_Code_Blank_ByPassWait(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKBYPASSWAITSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when bypass wait is blank$")
	public void verify_The_Return_Msg_Blank_ByPassWait(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKBYPASSWAITSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when refund is blank$")
	public void verify_The_Return_Code_Blank_Refund(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKREFUNDSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when refund is blank$")
	public void verify_The_Return_Msg_Blank_Refund(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKREFUNDSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when clm corr req is blank$")
	public void verify_The_Return_Code_Blank_ClmCorrReq(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCLMCORRREQSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when clm corr req is blank$")
	public void verify_The_Return_Msg_Blank_ClmCorrReq(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKCLMCORRREQSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Total Reversal Physician sub audit when other info is blank$")
	public void verify_The_Return_Code_Blank_OthInfo(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhySubAdtResponse(JSON_TOTALREVRSLBLNKOTHRINFOSUBADT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		System.out.println("Review code from Database:"+" "+rvwCode);
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review code are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review code are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Total Reversal Physician sub audit when other info is blank$")
	public void verify_The_Return_Msg_Blank_OthrInfo(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));

		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(TotalReversalPhysicianAPIValidation.class).totalReversalPhyResponse(JSON_TOTALREVRSLBLNKOTHRINFOSUBADT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		System.out.println("Review msg from Database:"+" "+rvwMsg);
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	

}
