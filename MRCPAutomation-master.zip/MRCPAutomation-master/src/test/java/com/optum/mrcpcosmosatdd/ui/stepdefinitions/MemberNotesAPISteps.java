package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.AutoCloseCOBEditsAPIValidations;
import com.optum.mrcpcosmosatdd.services.rest.MemberNotesAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MemberNotesAPISteps extends MRCPTestBase{

File JSON_Mbrnts_ADD,JSON_Mbrnts_groupmissing,JSON_Mbrnts_invalidmember,JSON_Mbrnts_sitemissing;

    Map<String, String> attributes = new HashMap();
    @When("^i get the request body parameter from MembernotesJson file$")
    public void i_get_the_request_body_parameter_from_MembernotesJson_file() throws Throwable {
            JSON_Mbrnts_ADD=new File(PropertyReader.getInstance().readProperty("JSON_Mbrnts_ADD"));
            JSON_Mbrnts_groupmissing=new File(PropertyReader.getInstance().readProperty("JSON_Mbrnts_groupmissing"));
            JSON_Mbrnts_invalidmember=new File(PropertyReader.getInstance().readProperty("JSON_Mbrnts_invalidmember"));
            JSON_Mbrnts_sitemissing=new File(PropertyReader.getInstance().readProperty("JSON_Mbrnts_sitemissing"));
}

    @Then("^Verify the return code as \"([^\"]*)\" and return message as \"([^\"]*)\" when we add member notes to a member\\.$")
    public void verify_the_return_code_as_and_return_message_as_when_we_add_member_notes_to_a_member(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(MemberNotesAPIValidations.class).rtnStatus(JSON_Mbrnts_ADD);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("Return Code") + " and " + "Return message from Response:" + response_ClaimsDetails.get("Return Message"));
        Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("Return Message").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");



    }

    @Then("^Verify the return code as \"([^\"]*)\" and return message as \"([^\"]*)\" when we add member notes to an invalid member\\.$")
    public void verify_the_return_code_as_and_return_message_as_when_we_add_member_notes_to_an_invalid_member(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(MemberNotesAPIValidations.class).rtnStatus(JSON_Mbrnts_invalidmember);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("Return Code") + " and " + "Return message from Response:" + response_ClaimsDetails.get("Return Message"));
        Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("Return Message").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");


    }

    @Then("^Verify the return code as \"([^\"]*)\" and return message as \"([^\"]*)\" when we add member notes to a member without site\\(site is missing\\)\\.$")
    public void verify_the_return_code_as_and_return_message_as_when_we_add_member_notes_to_a_member_without_site_site_is_missing(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(MemberNotesAPIValidations.class).rtnStatus(JSON_Mbrnts_sitemissing);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("Return Code") + " and " + "Return message from Response:" + response_ClaimsDetails.get("Return Message"));
        Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("Return Message").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");
    }

    @Then("^Verify the return code as \"([^\"]*)\" and return message as \"([^\"]*)\" when we add member notes to a member without group\\(group is missing\\)\\.$")
    public void verify_the_return_code_as_and_return_message_as_when_we_add_member_notes_to_a_member_without_group_group_is_missing(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(MemberNotesAPIValidations.class).rtnStatus(JSON_Mbrnts_groupmissing);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("Return Code") + " and " + "Return message from Response:" + response_ClaimsDetails.get("Return Message"));
        Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("Return Message").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");
    }

}




