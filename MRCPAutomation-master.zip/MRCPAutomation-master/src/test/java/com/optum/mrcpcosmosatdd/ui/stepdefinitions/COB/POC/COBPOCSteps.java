package com.optum.mrcpcosmosatdd.ui.stepdefinitions.COB.POC;

import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.pages.COB.POC.COB_POCWindow;
import com.optum.mrcpcosmosatdd.ui.stepdefinitions.MRCPTestBase;


import cucumber.api.java.en.When;

public class COBPOCSteps extends MRCPTestBase {
	
	@When("^Page title should be \"([^\"]*)\" of the screen.$")
	public void validate_ThePageTitle(String pageTitle) throws InterruptedException {
		Assert.assertEquals(getPage(COB_POCWindow.class).pageTitle(pageTitle), true);
	}
	
	@When("^Verify the UI Elements for this screen.$")
	public void validate_UI_Elements() throws InterruptedException {
		Assert.assertEquals(getPage(COB_POCWindow.class).verifyUIElements(), true);
	}
}
