package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import org.testng.Assert;

import com.optum.mrcpcosmosatdd.ui.pages.MenuValidationWindow;

import cucumber.api.java.en.Then;

public class UserAccessSteps extends MRCPTestBase {
	
	
	  @Then("^Verify all Menu Items are enabled for Superuser")	    
		  public void I_Verify_Menues_for_SuperUser() throws Throwable {	
		  Assert.assertEquals(getPage(MenuValidationWindow.class).validateWindowMenuForSuperUser(), true);
	  }
	  
	  @Then("^Verify all Menu Items are enabled for Supervisor$")
	  public void verify_all_menu_is_Enable_for_superwiser_user_except() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  Assert.assertEquals(getPage(MenuValidationWindow.class).validateWindowMenuForSupervisor(), true);
	  }
	 
	  @Then("^Verify all menu is Enable for Level0 user$")
	  public void verify_all_menu_is_Enable_for_Level0_user_except() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  Assert.assertEquals(getPage(MenuValidationWindow.class).validateWindowMenuForLevel0User(), true);
	  }
}