package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.AutomationClaimStatusAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class AutomationClaimStastusSteps extends MRCPTestBase{

	File JSON_HOSPAUTOSTSTRUE;
	File JSON_PHYAUTOSTSTRUE;
	File JSON_HOSPAUTOSTSFALSE;
	File JSON_PHYAUTOSTSFALSE;
	File JSON_AUTOSTSTYPENULL;
	
	@When("^I get the request body parameter from payload json file for Automation claim status$")
	public void get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_HOSPAUTOSTSTRUE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPAUTOSTSTRUE"));
		JSON_PHYAUTOSTSTRUE = new File(PropertyReader.getInstance().readProperty("JSON_PHYAUTOSTSTRUE"));
		JSON_HOSPAUTOSTSFALSE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPAUTOSTSFALSE"));
		JSON_PHYAUTOSTSFALSE = new File(PropertyReader.getInstance().readProperty("JSON_PHYAUTOSTSFALSE"));
		JSON_AUTOSTSTYPENULL=new File(PropertyReader.getInstance().readProperty("JSON_AUTOSTSTYPENULL"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of hospital automation claim when claim not dropped to manual queue$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_HOSPAUTOSTSTRUE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return status as \"([^\"]*)\" of hospital automation claim when claim not dropped to manual queue$")
	public void verify_The_Return_Status(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_HOSPAUTOSTSTRUE);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails.get("Reporcess Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Reporcess Status").equals(rvwCode), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician automation claim when claim not dropped to manual queue$")
	public void verify_The_Return_Code_Phy(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_PHYAUTOSTSTRUE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return status as \"([^\"]*)\" of physician automation claim when claim not dropped to manual queue$")
	public void verify_The_Return_Status_Phy(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_PHYAUTOSTSTRUE);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails.get("Reporcess Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Reporcess Status").equals(rvwCode), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of hospital automation claim when claim dropped to manual queue$")
	public void verify_The_Return_Code_HospDroppedQueue(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_HOSPAUTOSTSFALSE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return status as \"([^\"]*)\" of hospital automation claim when claim dropped to manual queue$")
	public void verify_The_Return_Status_HospDroppedQueue(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_HOSPAUTOSTSFALSE);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails.get("Reporcess Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Reporcess Status").equals(rvwCode), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of physician automation claim when claim dropped to manual queue$")
	public void verify_The_Return_Code_PhyDroppedQueue(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_PHYAUTOSTSFALSE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return status as \"([^\"]*)\" of physician automation claim when claim dropped to manual queue$")
	public void verify_The_Return_Status_PhyDroppedQueue(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_PHYAUTOSTSFALSE);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails.get("Reporcess Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Reporcess Status").equals(rvwCode), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of automation claim when claim type as null$")
	public void verify_The_Return_Code_TypeNull(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_AUTOSTSTYPENULL);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return status as \"([^\"]*)\" of automation claim when claim type as null$")
	public void verify_The_Return_Status_TypeNull(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(AutomationClaimStatusAPIValidation.class).reviewCodeAndReprocessStatus(JSON_AUTOSTSTYPENULL);
		System.out.println("Review status from Response:"+" "+ response_ClaimsDetails.get("Reporcess Status"));
		Assert.assertTrue(response_ClaimsDetails.get("Reporcess Status").equals(rvwCode), "Failed:Review status are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review status are verified from Service response and Database.");
	}
}
