package com.optum.mrcpcosmosatdd.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.security.GeneratePlainPassword;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;

/**
 * Class with DataBase Code
 * 
 * @author sgupt228
 *
 */
public class DBServices {

	public static void main(String args[]) {
		// testDB2();
		// testMySQL();
		testSybase();
	}

	/**
	 * DB2 Testing
	 * 
	 */
	public static void testDB2() {

		String query = PropertyReader.getInstance().readProperty("DB2-SELECT-QUERY");
		List<String> params = new ArrayList<String>();
		params.add("BHM");
		String columnNames = "CLM_AUDNBR||CLM_AUDSUB||CLM_HMO_ID";
		String dataTypes = "Integer||Integer||String";

		System.out.println(getDataFromDB2Database(query, params, columnNames, dataTypes));
	}

	/**
	 * Sybase Testing
	 * 
	 */
	public static void testSybase() {
		String columnNames = "cosmosnumericid||cosmosrole";
		String dataTypes = "String||String";
		String query = PropertyReader.getInstance().readProperty("TEST-SYBASE-QUERY");
		List<String> params = new ArrayList<String>();
		params.add("077425");
		/*
		 * params.add("OEB"); params.add("P");
		 */
		System.out.println(getDataFromSybaseDatabase(query, params, columnNames, dataTypes));
	}

	/**
	 * MySQL Testing
	 * 
	 */
	public static void testMySQL() {
		String columnNames = "MRM_Response_Date||MRM_Response_code||SourceSystem||MedicalRecURL||DocumentID";
		String dataTypes = "TimeStamp||String||String||String||String";
		String query = PropertyReader.getInstance().readProperty("MRM-SELECT-QUERY");
		List<String> params = new ArrayList<String>();
		params.add("87215972");
		params.add("OEB");
		params.add("P");
		System.out.println(getDataFromMYSQLDatabase(query, params, columnNames, dataTypes));
	}

	/**
	 * Get the Data from Sybase Database using the mentioned parameters
	 * 
	 * @param query
	 * @param params
	 * @param columnNames
	 * @param dataTypes
	 * @return
	 */
	public static String getDataFromSybaseDatabase(String query, List<String> params, String columnNames,
			String dataTypes) {

		/* String jdbcClassName = "com.sybase.jdbc.sqlanywhere.IDriver"; */
		String url = PropertyReader.getInstance().readProperty("SYBASE-URL");
		String username = PropertyReader.getInstance().readProperty("SYBASE-Username");
		String password;

		try {
			password = GeneratePlainPassword
					.getPlainPassword(PropertyReader.getInstance().readProperty("SYBASE-Password"));
		} catch (InvalidKeyException e1) {
			Log.error("Invalid Key Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e1) {
			Log.error("No Such Algorithm Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchPaddingException e1) {
			Log.error("No Such Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (IllegalBlockSizeException e1) {
			Log.error("Illegal Block Size Exception");
			e1.printStackTrace();
			return null;
		} catch (BadPaddingException e1) {
			Log.error("Bad Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (FileNotFoundException e1) {
			Log.error("File Not Found Exception");
			e1.printStackTrace();
			return null;
		} catch (IOException e1) {
			Log.error("IO Exception");
			e1.printStackTrace();
			return null;
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String result = "";

		try {
			conn = DriverManager.getConnection(url, username, password);
			if (conn != null) {
				// System.out.println("MySQL Database Connected");
				Log.info("Sybase Database Connected");
			} else {
				// System.out.println("MySQL connection Failed ");
				Log.error("Sybase Database not Connected");
			}

			String arrColumns[] = columnNames.split("\\|\\|");
			String arrDataTypes[] = dataTypes.split("\\|\\|");

			if (arrDataTypes.length != arrColumns.length) {
				Log.error("Columns and DataType count doesn't matched");
				// System.out.println("Columns and DataType count doesn't matched");
				return null;
			}

			pstmt = conn.prepareStatement(query);
			for (int i = 1; i <= params.size(); i++) {
				pstmt.setString(i, params.get(i - 1));
			}
			rset = pstmt.executeQuery();
			if (rset != null) {
				while (rset.next()) {
					for (int i = 0; i < arrDataTypes.length; i++) {
						if (arrDataTypes[i].equalsIgnoreCase("String")) {
							Log.info(arrColumns[i] + " :- " + rset.getString(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getString(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getString(arrColumns[i]);
							else
								result = result + rset.getString(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("Integer")) {
							Log.info(arrColumns[i] + " :- " + rset.getInt(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getInt(arrColumns[i]);
							else
								result = result + rset.getInt(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("TimeStamp")) {
							Log.info(arrColumns[i] + " :- " + rset.getTimestamp(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getTimestamp(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getTimestamp(arrColumns[i]);
							else
								result = result + rset.getTimestamp(arrColumns[i]) + "||";

						} else {
							Log.info("Data type:- " + arrDataTypes[i] + "is not defined");
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
						}
					}
					result = result + "||||";
				}
			} else {
				Log.error("No Information Found");
				// System.out.println("No Information Found");
			}
		} catch (SQLException e) {
			Log.error("MySQL Database connection Failed");
			// System.out.println("MySQL Database connection Failed");
			e.printStackTrace();
			return null;
		}

		return result;
	}

	/**
	 * Get the Data from DB2 Database using the mentioned parameters
	 * 
	 * @param query
	 * @param params
	 * @param columnNames
	 * @param dataTypes
	 * @return
	 */
	public static String getDataFromDB2Database(String query, List<String> params, String columnNames,
			String dataTypes) {

		String jdbcClassName = "com.ibm.db2.jcc.DB2Driver";
		String url = PropertyReader.getInstance().readProperty("DB2-URL");
		String username = PropertyReader.getInstance().readProperty("DB2-Username");
		String password;

		try {
			password = GeneratePlainPassword
					.getPlainPassword(PropertyReader.getInstance().readProperty("DB2-Password"));
		} catch (InvalidKeyException e1) {
			Log.error("Invalid Key Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e1) {
			Log.error("No Such Algorithm Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchPaddingException e1) {
			Log.error("No Such Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (IllegalBlockSizeException e1) {
			Log.error("Illegal Block Size Exception");
			e1.printStackTrace();
			return null;
		} catch (BadPaddingException e1) {
			Log.error("Bad Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (FileNotFoundException e1) {
			Log.error("File Not Found Exception");
			e1.printStackTrace();
			return null;
		} catch (IOException e1) {
			Log.error("IO Exception");
			e1.printStackTrace();
			return null;
		}

		try {
			Class.forName(jdbcClassName);

		} catch (ClassNotFoundException e) {
			Log.error("Please include Classpath  Where your DB2 Driver is located");
			// System.out.println("Please include Classpath Where your DB2 Driver is
			// located");
			e.printStackTrace();
			return null;
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String result = "";

		try {
			conn = DriverManager.getConnection(url, username, password);
			if (conn != null) {
				// System.out.println("DB2 Database Connected");
				Log.info("DB2 Database Connected");
			} else {
				// System.out.println("DB2 connection Failed ");
				Log.error("DB2 Database not Connected");
			}

			String arrColumns[] = columnNames.split("\\|\\|");
			String arrDataTypes[] = dataTypes.split("\\|\\|");

			if (arrDataTypes.length != arrColumns.length) {
				Log.error("Columns and DataType count doesn't matched");
				// System.out.println("Columns and DataType count doesn't matched");
				return null;
			}

			pstmt = conn.prepareStatement(query);
			for (int i = 1; i <= params.size(); i++) {
				pstmt.setString(i, params.get(i - 1));
			}
			rset = pstmt.executeQuery();
			if (rset != null) {
				while (rset.next()) {
					for (int i = 0; i < arrDataTypes.length; i++) {
						if (arrDataTypes[i].equalsIgnoreCase("String")) {
							Log.info(arrColumns[i] + " :- " + rset.getString(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getString(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getString(arrColumns[i]);
							else
								result = result + rset.getString(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("Integer")) {
							Log.info(arrColumns[i] + " :- " + rset.getInt(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getInt(arrColumns[i]);
							else
								result = result + rset.getInt(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("TimeStamp")) {
							Log.info(arrColumns[i] + " :- " + rset.getTimestamp(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getTimestamp(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getTimestamp(arrColumns[i]);
							else
								result = result + rset.getTimestamp(arrColumns[i]) + "||";

						} else {
							Log.info("Data type:- " + arrDataTypes[i] + "is not defined");
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
						}
					}
					result = result + "||||";
				}
			} else {
				Log.error("No Information Found");
				// System.out.println("No Information Found");
			}
		} catch (SQLException e) {
			Log.error("DB2 Database connection Failed");
			// System.out.println("DB2 Database connection Failed");
			e.printStackTrace();
			return null;
		}

		return result;
	}

	/**
	 * Get the Data from MySQL Database using the mentioned parameters
	 * 
	 * @param query
	 * @param params
	 * @param columnNames
	 * @param dataTypes
	 * @return
	 */
	public static String getDataFromMYSQLDatabase(String query, List<String> params, String columnNames,
			String dataTypes) {

		String jdbcClassName = "com.mysql.jdbc.Driver";
		String url = PropertyReader.getInstance().readProperty("MySQL-URL");
		String username = PropertyReader.getInstance().readProperty("MySQL-Username");
		String password;

		try {
			password = GeneratePlainPassword
					.getPlainPassword(PropertyReader.getInstance().readProperty("MySQL-Password"));
		} catch (InvalidKeyException e1) {
			Log.error("Invalid Key Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e1) {
			Log.error("No Such Algorithm Exception");
			e1.printStackTrace();
			return null;
		} catch (NoSuchPaddingException e1) {
			Log.error("No Such Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (IllegalBlockSizeException e1) {
			Log.error("Illegal Block Size Exception");
			e1.printStackTrace();
			return null;
		} catch (BadPaddingException e1) {
			Log.error("Bad Padding Exception");
			e1.printStackTrace();
			return null;
		} catch (FileNotFoundException e1) {
			Log.error("File Not Found Exception");
			e1.printStackTrace();
			return null;
		} catch (IOException e1) {
			Log.error("IO Exception");
			e1.printStackTrace();
			return null;
		}

		try {
			Class.forName(jdbcClassName);

		} catch (ClassNotFoundException e) {
			Log.error("Please include Classpath  Where your MySQL Driver is located");
			// System.out.println("Please include Classpath Where your MySQL Driver is
			// located");
			e.printStackTrace();
			return null;
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String result = "";

		try {
			conn = DriverManager.getConnection(url, username, password);
			if (conn != null) {
				// System.out.println("MySQL Database Connected");
				Log.info("MySQL Database Connected");
			} else {
				// System.out.println("MySQL connection Failed ");
				Log.error("MySQL Database not Connected");
			}

			String arrColumns[] = columnNames.split("\\|\\|");
			String arrDataTypes[] = dataTypes.split("\\|\\|");

			if (arrDataTypes.length != arrColumns.length) {
				Log.error("Columns and DataType count doesn't matched");
				// System.out.println("Columns and DataType count doesn't matched");
				return null;
			}

			pstmt = conn.prepareStatement(query);
			for (int i = 1; i <= params.size(); i++) {
				pstmt.setString(i, params.get(i - 1));
			}
			rset = pstmt.executeQuery();
			if (rset != null) {
				while (rset.next()) {
					for (int i = 0; i < arrDataTypes.length; i++) {
						if (arrDataTypes[i].equalsIgnoreCase("String")) {
							Log.info(arrColumns[i] + " :- " + rset.getString(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getString(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getString(arrColumns[i]);
							else
								result = result + rset.getString(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("Integer")) {
							Log.info(arrColumns[i] + " :- " + rset.getInt(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getInt(arrColumns[i]);
							else
								result = result + rset.getInt(arrColumns[i]) + "||";

						} else if (arrDataTypes[i].equalsIgnoreCase("TimeStamp")) {
							Log.info(arrColumns[i] + " :- " + rset.getTimestamp(arrColumns[i]));
							// System.out.println(arrColumns[i]+" :- "+ rset.getTimestamp(arrColumns[i]));
							if (i == arrDataTypes.length - 1)
								result = result + rset.getTimestamp(arrColumns[i]);
							else
								result = result + rset.getTimestamp(arrColumns[i]) + "||";

						} else {
							Log.info("Data type:- " + arrDataTypes[i] + "is not defined");
							// System.out.println(arrColumns[i]+" :- "+ rset.getInt(arrColumns[i]));
						}
					}
					result = result + "||||";
				}
			} else {
				Log.error("No Information Found");
				// System.out.println("No Information Found");
			}
		} catch (SQLException e) {
			Log.error("MySQL Database connection Failed");
			// System.out.println("MySQL Database connection Failed");
			e.printStackTrace();
			return null;
		}

		return result;
	}
}