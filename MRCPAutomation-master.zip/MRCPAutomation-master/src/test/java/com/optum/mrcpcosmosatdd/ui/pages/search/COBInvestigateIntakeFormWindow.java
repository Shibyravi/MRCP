package com.optum.mrcpcosmosatdd.ui.pages.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

public class COBInvestigateIntakeFormWindow extends BasePage {

	private By windowRootEle = By.id("investigationoPup");

	//Input disable fields locators
	private By title_Input = By.id("inv_title");
	private By platform_Input = By.id("inv_claim_plateform");
	private By memFName_Input = By.id("inv_mem_fisrt_name");
	private By memLName_Input = By.id("inv_mem_last_name");
	private By grpNbr_Input = By.id("inv_grup_num");
	private By memID_Input = By.id("inv_mem_id");
	private By div_Input = By.id("inv_site");
	private By VerificationError_Input = By.id("IntakeFormErrorMsgBar");

	// Input enabled fields locators
	private By COBReview_Select = By.id("inv_cob_review");
	private By reqType_Select = By.id("inv_req_type");
	private By auditNbr_Input = By.id("inv_audit");
	private By asOfDate_Input = By.id("inv_as_of_date");
	private By comment_Select = By.id("inv_comment");
	private By othrInsurIndicator_Input = By.id("other_insurance_ind");

	//Radio buttons
	private By Phy_Radio = By.id("audit_phy_type");
	private By hosp_Radio = By.id("audit_hosp_type");

	//Buttons
	private By button_Submit = By.id("inv_submit");
	private By button_Close = By.id("inv_closeBtn");

	public By getWindowRoot() {
		return windowRootEle;
	}

	public boolean validateButtonStandards(String buttonName) throws InterruptedException {
		waitForPageToLoad();
		try{
			if(buttonName.equals("Submit"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,button_Submit));
			}
			else if(buttonName.equals("Close"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,button_Close));
			}
			else
			{
				Log.error("Failed: Button name is not correct");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info("Passed:All buttons follow the standards");
		return true;
	}

	public boolean ValidateErrorMsgBarStandard() throws InterruptedException
	{
		try
		{
			Assert.assertTrue(validateDisabledTextFieldStandard(VerificationError_Input));

		}

		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}

	public boolean ValidateErrorMsgBar() throws InterruptedException
	{
		try
		{
			Assert.assertTrue(validateConvexTextField(VerificationError_Input));

		}

		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}

	public boolean ValidateDisabledFieldsStandard() throws InterruptedException
	{
		try
		{
			Assert.assertTrue(validateDisabledTextFieldStandard(title_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(platform_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(memFName_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(memLName_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(grpNbr_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(memID_Input));
			Assert.assertTrue(validateDisabledTextFieldStandard(div_Input));

		}

		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}

	public boolean validateConcaveFields() throws InterruptedException {
		waitForPageToLoad();

		try{
			if(!validateEnabledTextFieldStandard(COBReview_Select))
				return false;
			if(!validateEnabledTextFieldStandard(reqType_Select))
				return false;
			if(!validateEnabledTextFieldStandard(auditNbr_Input))
				return false;
			if(!validateEnabledTextFieldStandard(asOfDate_Input))
				return false;
			if(!validateEnabledTextFieldStandard(comment_Select))
				return false;
			if(!validateEnabledTextFieldStandard(othrInsurIndicator_Input))
				return false;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info("All Concave fields are validated as per UI Standards");
		return true;
	}

	public boolean verifySpellCheck() throws InterruptedException {

		waitForPageToLoad();
		try {
			if(!verifySpellCheck(auditNbr_Input))
				return false;

			if(!verifySpellCheck(asOfDate_Input))
				return false;

			if(!verifySpellCheck(othrInsurIndicator_Input))
				return false;	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info("All editable fields are having speelcheck as False as per UI Standards");
		return true;

	}

	public boolean validateTabbingOrder() throws InterruptedException{
		waitForPageToLoad();		

		if(!validateHighligtedTextField(COBReview_Select))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(reqType_Select))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(auditNbr_Input))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(Phy_Radio))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(button_Submit))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(button_Close))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(COBReview_Select))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(button_Close))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(button_Submit))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Phy_Radio))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(auditNbr_Input))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(reqType_Select))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(COBReview_Select))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(button_Close))
			return false;

		return true;
	}

	public boolean validateFieldsAlignment() throws InterruptedException {
		waitForPageToLoad(); 

		if(!validateInputFieldDataType(auditNbr_Input,"Numeric"))
			return false;

		if(!validateInputFieldDataType(asOfDate_Input,"Date"))
			return false;

		if(!validateInputFieldDataType(othrInsurIndicator_Input,"Alphanumeric"))
			return false;		

		return true;
	}

	public boolean validateAutoTabAfterFieldFilledToMax() throws InterruptedException {
		waitForPageToLoad();

		if(!validateHighligtedTextField(COBReview_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(reqType_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(auditNbr_Input))
			return false;
		fillInputFieldToMax(auditNbr_Input, "Numeric");
		if(!validateHighligtedTextField(Phy_Radio))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		fillInputFieldToMax(asOfDate_Input, "Date");

		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;
		fillInputFieldToMax(othrInsurIndicator_Input, "AlphaNumeric");
		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;

		return true;
	}

	public boolean verifyArrowKeysFunctionality() throws InterruptedException {
		waitForPageToLoad();

		if(!validateHighligtedTextField(COBReview_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(reqType_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(auditNbr_Input))
			return false;
		fillInputFieldToMax(auditNbr_Input, "Numeric");
		if(!validateHighligtedTextField(Phy_Radio))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		enterText(asOfDate_Input, "11/11/1111");
		//fillInputFieldToMax(asOfDate_Input, "Date");
		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;
		fillInputFieldToMax(othrInsurIndicator_Input, "AlphaNumeric");
		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;

		//Left Arrow Key Functionality
		KeyUtils.keyPressRightArrowMultipleTimes(getInputFieldMaxLength(othrInsurIndicator_Input));
		KeyUtils.keyPressLeftArrowMultipleTimes(getInputFieldMaxLength(othrInsurIndicator_Input)+1);
		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		KeyUtils.keyPressLeftArrowMultipleTimes(getInputFieldMaxLength(asOfDate_Input)+getInputFieldPlaceHolderLength(asOfDate_Input));

		if(!validateHighligtedTextField(Phy_Radio))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(auditNbr_Input))
			return false;
		KeyUtils.keyPressLeftArrowMultipleTimes(getInputFieldMaxLength(auditNbr_Input)+1);
		if(!validateHighligtedTextField(reqType_Select))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(auditNbr_Input))
			return false;

		//Right Arrow Key Functionality
		KeyUtils.keyPressRightArrowMultipleTimes(getInputFieldMaxLength(auditNbr_Input)+1);
		if(!validateHighligtedTextField(Phy_Radio))
			return false;

		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(asOfDate_Input))
			return false;
		KeyUtils.keyPressRightArrowMultipleTimes(2);

		if(!validateHighligtedTextField(comment_Select))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;

		KeyUtils.keyPressRightArrowMultipleTimes(2);
		if(!validateHighligtedTextField(othrInsurIndicator_Input))
			return false;

		return true;
	}

	public boolean validateStaticValues() throws InterruptedException {
		waitForPageToLoad();

		String title_Value = getAttributeValue(title_Input,"value");
		String claims_Platform = getAttributeValue(platform_Input,"value");
		Assert.assertTrue(title_Value.equals("Medicare & Retirement"), "Failed: Title value not matching");
		Assert.assertTrue(claims_Platform.equals("COSMOS"), "Failed: Claims Platform value not matching");

		return true;
	}

	public boolean validateDropdownValues(String dropDown) throws InterruptedException {

		waitForPageToLoad();
		try {
			if(dropDown.equals("COB Review"))
			{
				List<String> exp_COBReviewList = new ArrayList();
				String[] exp_COBReviewArray = {"","119","019","024","120"};
				exp_COBReviewList.addAll(Arrays.asList(exp_COBReviewArray));
				Assert.assertTrue(validateAllValuesOfDropdown(COBReview_Select, exp_COBReviewList));
			}
			else if(dropDown.equals("Request Type"))
			{
				List<String> exp_RequestTypeList = new ArrayList();
				String[] exp_ReqestTypeArray = {"","New MVA","Close MVA Open Over 1 Year","Possible MVA Benefits Exhausted","Workers Compensation","WC Apportioned Letter Received","COB Verification"};
				exp_RequestTypeList.addAll(Arrays.asList(exp_ReqestTypeArray));
				Assert.assertTrue(validateAllValuesOfDropdown(reqType_Select, exp_RequestTypeList));

			}
			else if(dropDown.equals("Comment"))
			{
				List<String> exp_CommentList = new ArrayList();
				String[] exp_CommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details.","119 Review: Date of Incident is over 1 year, please close MVA on COB Carrier Details.","119 Review: Evidence received of possible benefit exhaustion, please review.","119 Review: WC, please review and update COB Carrier Details.","119 Review: WC Apportioned letter received, please review and update COB Carrier Details.","019 Review: Claim denied 3 or more times for no EOB, please reconfirm COB Carrier Details.","019 Review: EOB shows other carrier denied for member coverage termed, please review.","019 Review: UNET/COSMOS segment compare discrepancy.","019 Review: Please review and update Other Carrier line on COB Carrier Details.","Direct Member Reimbursement: Please review and update COB Carrier Details.","024 Review: Please review and update Mdcr Carrier line on COB Carrier Details.","120 Review: Please review and update Other Carrier line on COB Carrier Details."};
				exp_CommentList.addAll(Arrays.asList(exp_CommentArray));
				Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_CommentList));
			}
			else
			{
				Assert.fail("Failed: Entered field is not a dropdown");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info(dropDown + " "+"dropdown field values are matching correctly");
		return true;

	}

	public boolean validateDropdownValuesBasedOnAppliedReview(String appliedReview) throws InterruptedException {

		waitForPageToLoad();
		try {
			if(appliedReview.equals("119"))
			{
				selectDropDownBoxValue(COBReview_Select, "119");
				List<String> exp_COBRequestTypeList = new ArrayList();
				String[] exp_COBRequestArray = {"","New MVA","Close MVA Open Over 1 Year","Possible MVA Benefits Exhausted","Workers Compensation","WC Apportioned Letter Received"};
				exp_COBRequestTypeList.addAll(Arrays.asList(exp_COBRequestArray));
				List<String> exp_COBCommentList = new ArrayList();
				String[] exp_COBCommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details.","119 Review: Date of Incident is over 1 year, please close MVA on COB Carrier Details.","119 Review: Evidence received of possible benefit exhaustion, please review.","119 Review: WC, please review and update COB Carrier Details.","119 Review: WC Apportioned letter received, please review and update COB Carrier Details.","019 Review: Claim denied 3 or more times for no EOB, please reconfirm COB Carrier Details.","019 Review: EOB shows other carrier denied for member coverage termed, please review.","019 Review: UNET/COSMOS segment compare discrepancy.","019 Review: Please review and update Other Carrier line on COB Carrier Details.","Direct Member Reimbursement: Please review and update COB Carrier Details.","024 Review: Please review and update Mdcr Carrier line on COB Carrier Details.","120 Review: Please review and update Other Carrier line on COB Carrier Details."};
				exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
				Assert.assertTrue(validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList)&&validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("119","New MVA"));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("119","Close MVA Open Over 1 Year"));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("119","Possible MVA Benefits Exhausted"));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("119","Workers Compensation"));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("119","WC Apportioned Letter Received"));
			}
			else if(appliedReview.equals("019"))
			{
				selectDropDownBoxValue(COBReview_Select, "019");
				List<String> exp_COBRequestTypeList = new ArrayList();
				String[] exp_COBRequestArray = {"","COB Verification"};
				exp_COBRequestTypeList.addAll(Arrays.asList(exp_COBRequestArray));
				List<String> exp_COBCommentList = new ArrayList();
				String[] exp_COBCommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details."};
				exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
				Assert.assertTrue(validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList)&&validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("019","COB Verification"));

			}
			else if(appliedReview.equals("024"))
			{
				selectDropDownBoxValue(COBReview_Select, "024");
				List<String> exp_COBRequestTypeList = new ArrayList();
				String[] exp_COBRequestArray = {"","COB Verification"};
				exp_COBRequestTypeList.addAll(Arrays.asList(exp_COBRequestArray));
				List<String> exp_COBCommentList = new ArrayList();
				String[] exp_COBCommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details."};
				exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
				Assert.assertTrue(validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList)&&validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("024","COB Verification"));

			}
			else if(appliedReview.equals("120"))
			{
				selectDropDownBoxValue(COBReview_Select, "120");
				List<String> exp_COBRequestTypeList = new ArrayList();
				String[] exp_COBRequestArray = {"","COB Verification"};
				exp_COBRequestTypeList.addAll(Arrays.asList(exp_COBRequestArray));
				List<String> exp_COBCommentList = new ArrayList();
				String[] exp_COBCommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details."};
				exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
				Assert.assertTrue(validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList)&&validateAllValuesOfDropdown(reqType_Select, exp_COBRequestTypeList));
				Assert.assertTrue(validateCommentsValuesBasedOnRequestType("120","COB Verification"));

			}
			else
			{
				Assert.fail("Failed: Entered field is not a dropdown");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info(appliedReview + " "+"dropdown field values are matching correctly");
		return true;
	}

	public boolean validateCommentsValuesBasedOnRequestType(String review,String reqType)
	{
		try
		{
			if(review.equals("119"))
			{
				if(reqType.equals("New MVA"))
				{
					selectDropDownBoxValue(reqType_Select, "New MVA");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","119 Review: Indication of MVA, please review and update COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
				else if(reqType.equals("Close MVA Open Over 1 Year"))
				{
					selectDropDownBoxValue(reqType_Select, " Close MVA Open Over 1 Year ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","119 Review: Date of Incident is over 1 year, please close MVA on COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
				else if(reqType.equals("Possible MVA Benefits Exhausted"))
				{
					selectDropDownBoxValue(reqType_Select, " Possible MVA Benefits Exhausted ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","119 Review: Evidence received of possible benefit exhaustion, please review."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
				else if(reqType.equals("Workers Compensation"))
				{
					selectDropDownBoxValue(reqType_Select, " Workers Compensation ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","119 Review: WC, please review and update COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
				else if(reqType.equals("WC Apportioned Letter Received"))
				{
					selectDropDownBoxValue(reqType_Select, " WC Apportioned Letter Received ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","119 Review: WC Apportioned letter received, please review and update COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
				
			}
			else if(review.equals("019"))
			{
				if(reqType.equals("COB Verification"))
				{
					selectDropDownBoxValue(reqType_Select, " COB Verification ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","019 Review: Claim denied 3 or more times for no EOB, please reconfirm COB Carrier Details.","019 Review: EOB shows other carrier denied for member coverage termed, please review.","019 Review: UNET/COSMOS segment compare discrepancy.","019 Review: Please review and update Other Carrier line on COB Carrier Details.","Direct Member Reimbursement: Please review and update COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
			}
			else if(review.equals("024"))
			{
				if(reqType.equals("COB Verification"))
				{
					selectDropDownBoxValue(reqType_Select, " COB Verification ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","024 Review: Please review and update Mdcr Carrier line on COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
			}
			else if(review.equals("120"))
			{
				if(reqType.equals("COB Verification"))
				{
					selectDropDownBoxValue(reqType_Select, " COB Verification ");
					List<String> exp_COBCommentList = new ArrayList();
					String[] exp_COBCommentArray = {"","120 Review: Please review and update Other Carrier line on COB Carrier Details."};
					exp_COBCommentList.addAll(Arrays.asList(exp_COBCommentArray));
					Assert.assertTrue(validateAllValuesOfDropdown(comment_Select, exp_COBCommentList));
				}
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}

	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue() throws InterruptedException {
		waitForPageToLoad();

		if(!validateBackspaceFunctionalityWhenDataHighlightedInBluePopUp(auditNbr_Input, "Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBluePopUp(asOfDate_Input, "Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBluePopUp(othrInsurIndicator_Input, "AlphaNumeric"))
			return false;

		return true;
	}

	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue() throws InterruptedException {
		waitForPageToLoad();


		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBluePopUp(auditNbr_Input, "Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBluePopUp(asOfDate_Input, "Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBluePopUp(othrInsurIndicator_Input, "AlphaNumeric"))
			return false;

		return true;
	}


}



