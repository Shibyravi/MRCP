package com.optum.mrcpcosmosatdd.ui.pages.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

public class COBCarrierDetailsWindow extends BasePage {

	private By windowRootEle = By.id("COBCarrierDetailsWindow");

	//Input fields elements
	private By auditNo_HospAdjusmtnet = By.id("hospAdjAuditNumberId");
	private By input_Member = By.id("cobRecarrierMemberNumber");
	private By input_Site = By.id("cobRecarrierSite");
	private By input_AuditNbr = By.id("cobRecarrierAudit");
	private By input_AsOfDt = By.id("cobRecarrierAsOfDate");
	private By input_ToDt = By.id("cobRecarriertoDate");
	private By input_CobOtherCarrier = By.id("cob_other_Carrier");
	private By underlined_Headers = By.xpath(".//th");
	private By underlined_Headers_Span = By.xpath(".//cob-element//tr//th//span");
	private By Error_MsgBar = By.id("CobDetailErrorMsgBar"); 

	//Buttons
	private By buttons_Inquire = By.id("cobDetailsInquire");
	private By buttons_Add = By.id("cobDetailsAdd");
	private By buttons_Change = By.id("cobDetailsChange");
	private By buttons_Close = By.id("cobDetailsClose");
	private By buttons_Investigate = By.id("cobDetailsInvestigate");

	private By underlined_Labels = By.xpath(".//*[@id='COBCarrierDetailsWindow']//span");

	//Radio button

	private By radio_ActiveEdits = By.xpath(".//label[text()='Active Edits']//following-sibling::input[@type='radio']");
	private By radio_ActiveEdit = By.id("cobCarriersRadioPhy");
	private By radio_EditHistory = By.id("cobCarriersRadioHosp");

	//Dropdown fields
	private By dropdown_LOB = By.id("cob_lob_select");
	private By dropdown_ReqType = By.id("cob_req_select");
	private By dropdown_Comments = By.id("cob_comment_select");

	// Other Insurance Section
	private By primacy_Dropdown = By.id("primacy_0");
	private By CovType_Dropdown = By.id("covType_0");
	private By CarrierType_Dropdown = By.id("carrierType_0");
	private By CarrierNumber_Text = By.id("number_0");
	private By CarrierName_Text = By.id("carrierName_0");
	private By Eff_DT_Text = By.id("effDt_0");
	private By Exp_Dt_Text = By.id("expDt_0");
	private By PolicyGrp_Nbr = By.id("policyNumber_0");
	private By CommuRsn_Dropdown = By.id("expRsn_0");
	private By OthrUHCPlanInfo = By.id("otherPlanInfo_0");

	//Recovery Section
	private By incidentDt_Dropdown = By.id("recoveryIncDt_0");
	private By CarrierType_Dropdown_Recovery = By.id("recoveryCarrierType_0");
	private By CarrierNumber_Text_Recovery = By.id("recoveryCarrierNbr_0");
	private By CarrierName_TextRecovery = By.id("recoveryCarrierName_0");
	private By Eff_DT_TextRecovery = By.id("recoveryEffDt_0");
	private By Exp_Dt_TextRecovery = By.id("recoveryExpDt_0");
	private By PolicyGrp_NbrRecovery = By.id("policyGrp_0");
	private By CommuRsn_DropdownRecovery = By.id("recoveryRsn_0");
	private By ApportPect_Recovery = By.id("recoveryApportionment_0");
	private By Diagnosis_Desc_Recovery = By.id("recoveryDiagDesc_0");
	private By BL_Recovery = By.id("blackLung_0");
	private By I_Recovery = By.id("recoveryICDANum_0");
	private By ICDA1_Recovery = By.id("recoveryICDA1_0");
	private By ICDA2_Recovery = By.id("recoveryICDA2_0");
	private By ICDA3_Recovery = By.id("recoveryICDA3_0");
	private By ICDA4_Recovery = By.id("recoveryICDA4_0");
	private By ICDA5_Recovery = By.id("recoveryICDA5_0");
	private By ICDA6_Recovery = By.id("recoveryICDA6_0");
	private By ICDA7_Recovery = By.id("recoveryICDA7_0");
	private By ICDA8_Recovery = By.id("recoveryICDA8_0");
	private By ICDA9_Recovery = By.id("recoveryICDA9_0");
	private By ICDA10_Recovery = By.id("recoveryICDA10_0");



	public By getWindowRoot() {
		return windowRootEle;
	}

	public boolean validateUnderlinedLabelsOnPage(String expUnderlinedLabels) throws InterruptedException
	{
		waitForPageToLoad();

		try
		{
			//store the expected values in a list
			String[] exp_UnderlinedLabels = expUnderlinedLabels.split("\\|\\|");
			//Converting array to List
			List<String> exp_UndrlinedLabelsList = new ArrayList<String>();
			exp_UndrlinedLabelsList.addAll(Arrays.asList(exp_UnderlinedLabels));
			Log.info("Expected underlined labels:"+ " "+ exp_UndrlinedLabelsList);

			List<WebElement> act_label_WebElement = new ArrayList<WebElement>();
			act_label_WebElement.addAll(driver.findElements(underlined_Labels));
			System.out.println("actual label size"+ " "+act_label_WebElement.size());
			if(underlinedLabelsValidation(act_label_WebElement,exp_UndrlinedLabelsList))
			{
				Log.info("Passed:Underlined labels are matching");
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}

	public boolean validateConcaveFields() throws InterruptedException {
		waitForPageToLoad();

		try{
			if(!validateEnabledTextFieldStandard(input_Member))
				return false;
			if(!validateEnabledTextFieldStandard(input_Site))
				return false;
			if(!validateEnabledTextFieldStandard(input_AsOfDt))
				return false;
			if(!validateEnabledTextFieldStandard(primacy_Dropdown))
				return false;
			if(!validateEnabledTextFieldStandard(CovType_Dropdown))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierType_Dropdown))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierNumber_Text))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierName_Text))
				return false;
			if(!validateEnabledTextFieldStandard(Eff_DT_Text))
				return false;
			if(!validateEnabledTextFieldStandard(Exp_Dt_Text))
				return false;
			if(!validateEnabledTextFieldStandard(PolicyGrp_Nbr))
				return false;
			if(!validateEnabledTextFieldStandard(CommuRsn_Dropdown))
				return false;
			if(!validateEnabledTextFieldStandard(OthrUHCPlanInfo))
				return false;

			if(!validateEnabledTextFieldStandard(incidentDt_Dropdown))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierType_Dropdown_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierNumber_Text_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(CarrierName_TextRecovery))
				return false;
			if(!validateEnabledTextFieldStandard(Eff_DT_TextRecovery))
				return false;
			if(!validateEnabledTextFieldStandard(Exp_Dt_TextRecovery))
				return false;
			if(!validateEnabledTextFieldStandard(PolicyGrp_NbrRecovery))
				return false;
			if(!validateEnabledTextFieldStandard(CommuRsn_DropdownRecovery))
				return false;
			if(!validateEnabledTextFieldStandard(ApportPect_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(Diagnosis_Desc_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(I_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA1_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA2_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA3_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA4_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA5_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA6_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA7_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA8_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA9_Recovery))
				return false;
			if(!validateEnabledTextFieldStandard(ICDA10_Recovery))
				return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info("All Concave fields are validated as per UI Standards");
		return true;
	}

	public boolean validateButtonStandards(String buttonName) throws InterruptedException {
		waitForPageToLoad();
		try{
			if(buttonName.equals("Inquire"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,buttons_Inquire));
			}
			else if(buttonName.equals("Add"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,buttons_Add));
			}
			else if(buttonName.equals("Change"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,buttons_Change));
			}
			else if(buttonName.equals("Close"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,buttons_Close));
			}
			else if(buttonName.equals("Investigate"))
			{
				Assert.assertTrue(validateButtonStandards(buttonName,buttons_Investigate));
			}
			else
			{
				Log.error("Failed: Button name is not correct");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info("Passed:All buttons follow the standards");
		return true;
	}

	public boolean validateRadioButtonIsSelected(String radioButton) throws InterruptedException {
		waitForPageToLoad();

		try{
			WebElement radioEle = driver.findElement(By.xpath(".//span[text()='"+radioButton+"']//following-sibling::input[@type='radio'][1]"));
			Assert.assertTrue(isElementSelected(radioEle));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}

	public void WaitforElementToBeVisible() throws InterruptedException
	{
		visibilityOfElementLocated(input_Member);
	}

	public void WaitforElementToBeVisibleAuditNo() throws InterruptedException
	{
		visibilityOfElementLocated(auditNo_HospAdjusmtnet);
	}

	public boolean validateFieldsAlignment() throws InterruptedException {
		waitForPageToLoad(); 

		if(!validateDashFieldDataType(input_Member,"2"))
			return false;

		if(!validateInputFieldDataType(input_Site,"Alphabets"))
			return false;		

		if(!validateInputFieldDataType(input_AsOfDt,"Date"))
			return false;

		if(!validateInputFieldDataType(CarrierNumber_Text,"Numeric"))
			return false;

		if(!validateInputFieldDataType(CarrierName_Text,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(Eff_DT_Text,"Date"))
			return false;

		if(!validateInputFieldDataType(Exp_Dt_Text,"Date"))
			return false;

		if(!validateInputFieldDataType(PolicyGrp_Nbr,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(OthrUHCPlanInfo,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(incidentDt_Dropdown,"Date"))
			return false;

		if(!validateInputFieldDataType(CarrierNumber_Text_Recovery,"Numeric"))
			return false;

		if(!validateInputFieldDataType(CarrierName_TextRecovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(Eff_DT_TextRecovery,"Date"))
			return false;

		if(!validateInputFieldDataType(Exp_Dt_TextRecovery,"Date"))
			return false;

		if(!validateInputFieldDataType(PolicyGrp_NbrRecovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ApportPect_Recovery,"Decimal"))
			return false;

		if(!validateInputFieldDataType(Diagnosis_Desc_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(I_Recovery,"Numeric"))
			return false;

		if(!validateInputFieldDataType(ICDA1_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA2_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA3_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA4_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA5_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA6_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA7_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA8_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA9_Recovery,"Alphanumeric"))
			return false;

		if(!validateInputFieldDataType(ICDA10_Recovery,"Alphanumeric"))
			return false;

		return true;
	}

	public boolean validateBackspaceFunctionalityWhenDataHighlightedInBlue() throws InterruptedException {

		waitForPageToLoad();

		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(input_Member, "Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(input_Site,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(input_AsOfDt,"Date"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(CarrierNumber_Text,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(CarrierName_Text,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(Eff_DT_Text,"Date"))
			return false;
		//Enter the Eff date
		fillInputFieldToMax(Eff_DT_Text,"Date");
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(Exp_Dt_Text,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(PolicyGrp_Nbr,"Alphanumeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(OthrUHCPlanInfo,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(incidentDt_Dropdown,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(CarrierNumber_Text_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(CarrierName_TextRecovery,"Alphabets"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(Eff_DT_TextRecovery,"Date"))
			return false;
		//Enter the Eff date
		fillInputFieldToMax(Eff_DT_TextRecovery,"Date");
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(Exp_Dt_TextRecovery,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(PolicyGrp_NbrRecovery,"Alphanumeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ApportPect_Recovery,"Decimal"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(Diagnosis_Desc_Recovery,"Alphabets"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(I_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA1_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA2_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA3_Recovery,"Numeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA4_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA5_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA6_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA7_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA8_Recovery,"Numeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA9_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataHighlightedInBlue(ICDA10_Recovery,"Numeric"))
			return false;

		return true;
	}

	public boolean validateBackspaceFunctionalityWhenDataNotHighlightedInBlue() throws InterruptedException {
		waitForPageToLoad();

		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(input_Member, "Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(input_Site,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(input_AsOfDt,"Date"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(CarrierNumber_Text,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(CarrierName_Text,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(Eff_DT_Text,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(Exp_Dt_Text,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(PolicyGrp_Nbr,"Alphanumeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(OthrUHCPlanInfo,"Alphabets"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(incidentDt_Dropdown,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(CarrierNumber_Text_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(CarrierName_TextRecovery,"Alphabets"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(Eff_DT_TextRecovery,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(Exp_Dt_TextRecovery,"Date"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(PolicyGrp_NbrRecovery,"Alphanumeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ApportPect_Recovery,"Decimal"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(Diagnosis_Desc_Recovery,"Alphabets"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(I_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA1_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA2_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA3_Recovery,"Numeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA4_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA5_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA6_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA7_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA8_Recovery,"Numeric"))	
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA9_Recovery,"Numeric"))
			return false;
		if(!validateBackspaceFunctionalityWhenDataNotHighlightedInBlue(ICDA10_Recovery,"Numeric"))
			return false;


		return true;
	}

	public boolean validateColHeaders(String expColHeaders) throws InterruptedException
	{
		waitForPageToLoad();
		try
		{
			if(validateColumnHeadersOnPage(underlined_Headers,expColHeaders)){
				Log.info("Passed: Detail level column headers are matching");
			}
			else
			{
				Log.error("Failed: Detail level column headers are NOT matching");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}

	public boolean validateunderlinedColHeaders(String expColHeaders) throws InterruptedException
	{
		waitForPageToLoad();
		try
		{
			if(validateTable_HeaderUnderlinedAndNotBolded_ByLocator(".//cob-element//tr//th",expColHeaders)){
				Log.info("Passed:Detail level column headers are underlined, not bolded and as per CPA UI Standards");
			}
			else
			{
				Log.error("Failed:Detail level column headers are NOT as per CPA UI Standards");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		return true;
	}




	public boolean ValidateErrorMsgBar() throws InterruptedException
	{
		try
		{
			Assert.assertTrue(validateConvexTextField(Error_MsgBar));

		}

		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}


	public boolean ValidateErrorMsgBarStandard() throws InterruptedException
	{
		try
		{
			Assert.assertTrue(validateDisabledTextFieldStandard(Error_MsgBar));

		} 

		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}

		return true;
	}

	public boolean verifySpellCheck() throws InterruptedException {

		waitForPageToLoad();

		if(!verifySpellCheck(input_Member))
			return false;

		if(!verifySpellCheck(input_Site))
			return false;		

		if(!verifySpellCheck(input_AsOfDt))
			return false;

		if(!verifySpellCheck(CarrierNumber_Text))
			return false;

		if(!verifySpellCheck(CarrierName_Text))
			return false;

		if(!verifySpellCheck(Eff_DT_Text))
			return false;

		if(!verifySpellCheck(Exp_Dt_Text))
			return false;		

		if(!verifySpellCheck(PolicyGrp_Nbr))
			return false;

		if(!verifySpellCheck(OthrUHCPlanInfo))
			return false;

		if(!verifySpellCheck(incidentDt_Dropdown))
			return false;

		if(!verifySpellCheck(CarrierNumber_Text_Recovery))
			return false;

		if(!verifySpellCheck(CarrierName_TextRecovery))
			return false;

		if(!verifySpellCheck(Eff_DT_TextRecovery))
			return false;		

		if(!verifySpellCheck(Exp_Dt_TextRecovery))
			return false;

		if(!verifySpellCheck(PolicyGrp_NbrRecovery))
			return false;

		if(!verifySpellCheck(ApportPect_Recovery))
			return false;

		if(!verifySpellCheck(BL_Recovery))
			return false;

		if(!verifySpellCheck(Diagnosis_Desc_Recovery))
			return false;

		if(!verifySpellCheck(I_Recovery))
			return false;		

		if(!verifySpellCheck(ICDA1_Recovery))
			return false;

		if(!verifySpellCheck(ICDA2_Recovery))
			return false;

		if(!verifySpellCheck(ICDA3_Recovery))
			return false;

		if(!verifySpellCheck(ICDA4_Recovery))
			return false;

		if(!verifySpellCheck(ICDA5_Recovery))
			return false;

		if(!verifySpellCheck(ICDA6_Recovery))
			return false;

		if(!verifySpellCheck(ICDA7_Recovery))
			return false;

		if(!verifySpellCheck(ICDA8_Recovery))
			return false;

		if(!verifySpellCheck(ICDA9_Recovery))
			return false;

		if(!verifySpellCheck(ICDA10_Recovery))
			return false;

		return true;

	}

	public boolean validateTabbingOrder() throws InterruptedException{
		waitForPageToLoad();		

		if(!validateHighligtedTextField(input_Member))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(input_Site))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(input_AsOfDt))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(radio_ActiveEdit))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(primacy_Dropdown))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CovType_Dropdown))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CarrierType_Dropdown))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CarrierNumber_Text))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CarrierName_Text))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(Eff_DT_Text))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(Exp_Dt_Text))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(PolicyGrp_Nbr))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CommuRsn_Dropdown))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(OthrUHCPlanInfo))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(incidentDt_Dropdown))
			return false;

		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(CarrierType_Dropdown_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CarrierNumber_Text_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CarrierName_TextRecovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(Eff_DT_TextRecovery))
			return false;

		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(Exp_Dt_TextRecovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(PolicyGrp_NbrRecovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(CommuRsn_DropdownRecovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ApportPect_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(BL_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(Diagnosis_Desc_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(I_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA1_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA2_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA3_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA4_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA5_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA6_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA7_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA8_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA9_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(ICDA10_Recovery))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(buttons_Inquire))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(buttons_Investigate))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(buttons_Add))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(buttons_Change))
			return false;
		KeyUtils.keyPressTab();

		if(!validateHighligtedTextField(buttons_Close))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(buttons_Change))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(buttons_Add))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(buttons_Investigate))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(buttons_Inquire))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA10_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA9_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA8_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA7_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA6_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA5_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA4_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA3_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA2_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ICDA1_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(I_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Diagnosis_Desc_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(BL_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(ApportPect_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CommuRsn_DropdownRecovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(PolicyGrp_NbrRecovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Exp_Dt_TextRecovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Eff_DT_TextRecovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierName_TextRecovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierNumber_Text_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierType_Dropdown_Recovery))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(incidentDt_Dropdown))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(OthrUHCPlanInfo))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CommuRsn_Dropdown))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(PolicyGrp_Nbr))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Exp_Dt_Text))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(Eff_DT_Text))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierName_Text))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierNumber_Text))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CarrierType_Dropdown))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(CovType_Dropdown))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(primacy_Dropdown))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(radio_ActiveEdit))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(input_AsOfDt))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(input_Site))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		if(!validateHighligtedTextField(input_Member))
			return false;
		KeyUtils.keyPressShiftPlusTab();

		return true;
	}
	
	public boolean validateDropdownValues(String dropDown) throws InterruptedException {

		waitForPageToLoad();
		try {
			if(dropDown.equals("Primacy"))
			{
				List<String> exp_PrimacyList = new ArrayList();
				String[] exp_PrimacyArray = {"","Primary","Secondary","Tertiary"};
				exp_PrimacyList.addAll(Arrays.asList(exp_PrimacyArray));
				Assert.assertTrue(validateAllValuesOfDropdown(primacy_Dropdown, exp_PrimacyList));
			}
			else if(dropDown.equals("Cov Type"))
			{
				List<String> exp_CovTypeList = new ArrayList();
				String[] exp_CovTypeArray = {"","ALL","MED","HOSP"};
				exp_CovTypeList.addAll(Arrays.asList(exp_CovTypeArray));
				Assert.assertTrue(validateAllValuesOfDropdown(CovType_Dropdown, exp_CovTypeList));
				
			}
			else if(dropDown.equals("Carrier Type"))
			{
				List<String> exp_CarrierTypeList = new ArrayList();
				String[] exp_CarrierTypeArray = {"","OI","MC"};
				exp_CarrierTypeList.addAll(Arrays.asList(exp_CarrierTypeArray));
				Assert.assertTrue(validateAllValuesOfDropdown(CarrierType_Dropdown, exp_CarrierTypeList));
			}
			else if(dropDown.equals("Communication RSN"))
			{
				List<String> exp_CommnRsnList = new ArrayList();
				String[] exp_CommnRSNArray = {"","Last Payer","Retiree","COBRA","Actively Working","ESRD","LOA/STD","LTD","Surviving Spouse","OI Terminated","No Overlap in Coverage","No VA Benefits","Inactive VA Benefits","Reconfirmed","Unable to Verify"};
				exp_CommnRsnList.addAll(Arrays.asList(exp_CommnRSNArray));
				Assert.assertTrue(validateAllValuesOfDropdown(CommuRsn_Dropdown, exp_CommnRsnList));
			}
			else if(dropDown.equals("CarrierType Rec"))
			{
				List<String> exp_CarrierTypeRecList = new ArrayList();
				String[] exp_CarrierTypeRecArray = {"","MV","WC","3P"};
				exp_CarrierTypeRecList.addAll(Arrays.asList(exp_CarrierTypeRecArray));
				Assert.assertTrue(validateAllValuesOfDropdown(CarrierType_Dropdown_Recovery, exp_CarrierTypeRecList));
			}
			else if(dropDown.equals("Communication Rsn Rec"))
			{
				List<String> exp_CommnRsnRecRecList = new ArrayList();
				String[] exp_CommnRsnRecArray = {"","PIP or Med Pay Available","Benefits Exhausted","No PIP or Med Pay","No Accident","Edit Entered in Error","Reconfirmed","Unable to Verify"};
				exp_CommnRsnRecRecList.addAll(Arrays.asList(exp_CommnRsnRecArray));
				Assert.assertTrue(validateAllValuesOfDropdown(CommuRsn_DropdownRecovery, exp_CommnRsnRecRecList));
			}
			else
			{
				Assert.fail("Failed: Entered field is not a dropdown");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed:Element not found");
			return false;
		}
		Log.info(dropDown + " "+"dropdown field values are matching correctly");
		return true;

	}
	
	public boolean validateAutoTabAfterFieldFilledToMax() throws InterruptedException {
		waitForPageToLoad();

		if(!validateHighligtedTextField(input_Member))
			return false;
		fillInputFieldToMax(input_Member, "Numeric");
		if(!validateHighligtedTextField(input_Site))
			return false;
		fillInputFieldToMax(input_Site, "Alphabets");
		if(!validateHighligtedTextField(input_AsOfDt))
			return false;
		fillInputFieldToMax(input_AsOfDt, "Date");
		if(!validateHighligtedTextField(radio_ActiveEdit))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(primacy_Dropdown))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(CovType_Dropdown))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(CarrierType_Dropdown))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(CarrierNumber_Text))
			return false;
		fillInputFieldToMax(CarrierNumber_Text, "Numeric");
		if(!validateHighligtedTextField(CarrierName_Text))
			return false;
		fillInputFieldToMax(CarrierName_Text, "AlphaNumeric");
		if(!validateHighligtedTextField(Eff_DT_Text))
			return false;
		fillInputFieldToMax(Eff_DT_Text,"Date");
		if(!validateHighligtedTextField(Exp_Dt_Text))
			return false;
		fillInputFieldToMax(Exp_Dt_Text,"Date");
		if(!validateHighligtedTextField(PolicyGrp_Nbr))
			return false;
		fillInputFieldToMax(PolicyGrp_Nbr, "AlphaNumeric");
		if(!validateHighligtedTextField(CommuRsn_Dropdown))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(OthrUHCPlanInfo))
			return false;
		fillInputFieldToMax(OthrUHCPlanInfo, "AlphaNumeric");
		if(!validateHighligtedTextField(incidentDt_Dropdown))
			return false;
		fillInputFieldToMax(incidentDt_Dropdown, "Date");
		if(!validateHighligtedTextField(CarrierType_Dropdown_Recovery))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(CarrierNumber_Text_Recovery))
			return false;
		fillInputFieldToMax(CarrierNumber_Text_Recovery, "Numeric");
		if(!validateHighligtedTextField(CarrierName_TextRecovery))
			return false;
		fillInputFieldToMax(CarrierName_TextRecovery, "AlphaNumeric");
		if(!validateHighligtedTextField(Eff_DT_TextRecovery))
			return false;
		fillInputFieldToMax(Eff_DT_TextRecovery, "Date");
		if(!validateHighligtedTextField(Exp_Dt_TextRecovery))
			return false;
		fillInputFieldToMax(Exp_Dt_TextRecovery, "Date");
		if(!validateHighligtedTextField(PolicyGrp_NbrRecovery))
			return false;
		fillInputFieldToMax(PolicyGrp_NbrRecovery, "AlphaNumeric");
		if(!validateHighligtedTextField(CommuRsn_DropdownRecovery))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(ApportPect_Recovery))
			return false;
		fillInputFieldToMax(ApportPect_Recovery, "Decimal");
		if(!validateHighligtedTextField(BL_Recovery))
			return false;
		KeyUtils.keyPressTab();
		if(!validateHighligtedTextField(Diagnosis_Desc_Recovery))
			return false;
		fillInputFieldToMax(Diagnosis_Desc_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(I_Recovery))
			return false;
		fillInputFieldToMax(I_Recovery, "Numeric");
		if(!validateHighligtedTextField(ICDA1_Recovery))
			return false;
		fillInputFieldToMax(ICDA1_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA2_Recovery))
			return false;
		fillInputFieldToMax(ICDA2_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA3_Recovery))
			return false;
		fillInputFieldToMax(ICDA3_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA4_Recovery))
			return false;
		fillInputFieldToMax(ICDA4_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA5_Recovery))
			return false;
		fillInputFieldToMax(ICDA5_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA6_Recovery))
			return false;
		fillInputFieldToMax(ICDA6_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA7_Recovery))
			return false;
		fillInputFieldToMax(ICDA7_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA8_Recovery))
			return false;
		fillInputFieldToMax(ICDA8_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA9_Recovery))
			return false;
		fillInputFieldToMax(ICDA9_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA10_Recovery))
			return false;
		fillInputFieldToMax(ICDA10_Recovery, "AlphaNumeric");
		if(!validateHighligtedTextField(ICDA10_Recovery))
			return false;
		return true;
	}


}