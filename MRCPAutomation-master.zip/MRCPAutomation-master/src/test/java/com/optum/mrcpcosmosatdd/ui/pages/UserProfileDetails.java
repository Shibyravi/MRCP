package com.optum.mrcpcosmosatdd.ui.pages;

public class UserProfileDetails {

	private static String phyProcGroup;
	private static String hospProcGroup;
	private static String phySite;
	private static String hospSite;
	private static String supervisor;
	private static String processor;
	private static int securityLevel;

	public String getPhyProcGroup() {
		return this.phyProcGroup;
	}
	
	public void setPhyProcGroup(String phyProcGroup) {
		this.phyProcGroup=phyProcGroup;
	}
	
	public String getHospProcGroup() {
		return this.hospProcGroup;
	}
	
	public void setHospProcGroup(String hospProcGroup) {
		this.hospProcGroup=phyProcGroup;
	}
	
	public String getPhySite() {
		return this.phySite;
	}
	
	public void setPhySite(String phySite) {
		this.phySite=phySite;
	}
	
	public String getHospSite() {
		return this.hospSite;
	}
	
	public void setHospSite(String hospSite) {
		this.hospSite=hospSite;
	}
	
	public String getSupervisor() {
		return this.supervisor;
	}
	
	public void setSupervisor(String supervisor) {
		this.supervisor=supervisor;
	}
	
	public String getProcessor() {
		return this.processor;
	}
	
	public void setProcessor(String processor) {
		this.processor=processor;
	}
	
	public int getSecurityLevel() {
		return this.securityLevel;
	}
	
	public void setSecurityLevel(int securityLevel) {
		this.securityLevel=securityLevel;
	}
	
}