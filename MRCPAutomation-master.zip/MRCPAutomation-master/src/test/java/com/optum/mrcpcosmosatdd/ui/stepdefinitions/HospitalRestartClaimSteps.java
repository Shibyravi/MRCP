package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.HospitalRestartClaimAPIValidation;
import com.optum.mrcpcosmosatdd.services.rest.PhysicianRestartClaimAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class HospitalRestartClaimSteps extends MRCPTestBase{
	
	File JSON_HOSPRESTRTRVW;
	File JSON_HOSPCLRRVW;
	File JSON_HOSPRESTRTRVWRNGAUDT;
	File JSON_HOSPRESTRTRVWRNGADTFRMT;
	File JSON_HOSPRESTRTRVWRNGSITE;
	File JSON_HOSPRESTRTRVWRNGUSERID;
	

	@When("^I get the request body parameter from payload json file for Hospital Restart claim$")
	public void get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_HOSPRESTRTRVW = new File(PropertyReader.getInstance().readProperty("JSON_HOSPRESTRTRVW"));
		JSON_HOSPRESTRTRVWRNGAUDT = new File(PropertyReader.getInstance().readProperty("JSON_HOSPRESTRTRVWRNGAUDT"));
		JSON_HOSPRESTRTRVWRNGADTFRMT = new File(PropertyReader.getInstance().readProperty("JSON_HOSPRESTRTRVWRNGADTFRMT"));
		JSON_HOSPRESTRTRVWRNGSITE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPRESTRTRVWRNGSITE"));
		JSON_HOSPRESTRTRVWRNGUSERID = new File(PropertyReader.getInstance().readProperty("JSON_HOSPRESTRTRVWRNGUSERID"));
		JSON_HOSPCLRRVW = new File(PropertyReader.getInstance().readProperty("JSON_HOSPCLRRVW"));
	}

	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when claim Successfully restarted$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVW);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when claim Successfully restarted$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVW);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when audit number incorrect$")
	public void verify_The_Return_CodeWhen_Audt_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when audit number incorrect$")
	public void verify_The_Return_MsgWen_Audt_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when audit number format incorrect$")
	public void verify_The_Return_CodeWhen_Audt_FormatIncorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGADTFRMT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when audit number format incorrect$")
	public void verify_The_Return_MsgWen_Audt_FormatIncorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGADTFRMT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when site is incorrect$")
	public void verify_The_Return_CodeWhen_Site_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when site is incorrect$")
	public void verify_The_Return_MsgWen_Site_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when userid is incorrect$")
	public void verify_The_Return_CodeWhen_UserId_Incorrect(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when userid is incorrect$")
	public void verify_The_Return_MsgWen_UserId_Incorrect(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalRestartClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPRESTRTRVWRNGUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Review Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Review Msg").equals(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
}



