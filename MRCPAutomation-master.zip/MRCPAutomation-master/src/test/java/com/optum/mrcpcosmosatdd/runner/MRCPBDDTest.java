package com.optum.mrcpcosmosatdd.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

import java.io.IOException;
import java.io.File;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;

/**
 *   
 * Main Runner Class
 *
 *****Please don't change the below code
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/Cucumber-reports/MRCP_Automation_Report.html","pretty", "html:target/cucumber"}
		,glue = "com.optum.mrcpcosmosatdd.ui.stepdefinitions" //Don't Change this
				,features = "classpath:features/services/Rest Service/AutomationClaimStatus.feature",
				//,features = "classpath:features/navigation/COBCarrierNavigation.feature"
				//,features = "classpath:features/Error_Validation/COBServiceErrorValidation.feature"
				monochrome=true
				//dryRun=true
				//,tags = "@RunThis" //Don't Change This

		)                                                                    
                                                                       
public class MRCPBDDTest extends AbstractTestNGCucumberTests {

	public class TestRunner {
		@AfterClass
		public void writeExtentReport() throws IOException {
			Reporter.loadXMLConfig(new File("src\\test\\resources\\extent-config.xml"));
			Reporter.setSystemInfo("OS", "Windows 8" + "64 bit");
			Reporter.setSystemInfo("Machine", 	"G3");
			Reporter.setSystemInfo("Browser", PropertyReader.getInstance().readProperty("Browser"));
			Reporter.setSystemInfo("Resolution", 	"1280*1024");
			Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
			Reporter.setSystemInfo("Selenium Version", "3.14");
			Reporter.setSystemInfo("Java Version", "1.8.0_51");
			Reporter.assignAuthor(System.getProperty("user.name"));
			Reporter.setTestRunnerOutput("MRCP Automation Execution Report");

			Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
		}
	}
}