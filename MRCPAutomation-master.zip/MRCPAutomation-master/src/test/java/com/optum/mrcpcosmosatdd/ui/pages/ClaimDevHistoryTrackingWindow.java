package com.optum.mrcpcosmosatdd.ui.pages;

import org.openqa.selenium.By;

public class ClaimDevHistoryTrackingWindow extends BasePage {

    private By windowRootEle = By.id("claimDevHistoryWindow");

    private By claimDevHistoryAuditNbrEle = By.id("claimDevHistoryAuditNbr");
    private By claimDevHistorySiteEle = By.id("claimDevHistorySite");
    private By claimTypeDevHistoryEle = By.name("claimTypeDevHistory");

    private By claimDevHistoryWindowvarInquireButtonEle = By.id("claimDevHistoryWindowvarInquireButton");

    public By getWindowRoot() {
        return windowRootEle;
    }

    /**
     * @param auditNbr
     * @param site
     * @param claimType
     */
    public void inquire(String auditNbr, String site, String claimType) {

        winPopulateTextBox(claimDevHistoryAuditNbrEle, auditNbr);
        winPopulateTextBox(claimDevHistorySiteEle, site);
        if ("P".equals(claimType)) {
            rootEle().findElements(claimTypeDevHistoryEle).get(0).click();
        } else {
            rootEle().findElements(claimTypeDevHistoryEle).get(1).click();
        }

        //click
        rootEle().findElement(claimDevHistoryWindowvarInquireButtonEle).click();
    }
}