package com.optum.mrcpcosmosatdd.ui.utilities;

import com.optum.mrcpcosmosatdd.ui.pages.BasePage;

public class WindowUtils extends BasePage{

}