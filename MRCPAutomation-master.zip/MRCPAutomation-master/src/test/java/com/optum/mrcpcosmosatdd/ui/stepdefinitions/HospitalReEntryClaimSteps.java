package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.services.rest.HospitalReEntryClaimAPIValidation;
import com.optum.mrcpcosmosatdd.services.rest.ReEnterPhysicianClaimAPIValidation;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;

import cucumber.api.java.en.When;

public class HospitalReEntryClaimSteps extends MRCPTestBase{
	
	File JSON_HOSPREENTERCLM;
	File JSON_HOSPREENTERUNSUCCESSCLM;
	File JSON_HOSPREENTYBLNKAUDT;
	File JSON_HOSPREENTYBLNKSITE;
	File JSON_HOSPREENTYINVLDSITE;
	File JSON_HOSPREENTRINVLDUSERID;
	

	@When("^I get the request body parameter from payload json file for Hospital Re-Enter claim$")
	public void I_get_the_body_Params_From_Json_Payload()throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		JSON_HOSPREENTERCLM = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTERCLM"));
		JSON_HOSPREENTERUNSUCCESSCLM = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTERUNSUCCESSCLM"));
		JSON_HOSPREENTYBLNKAUDT = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTYBLNKAUDT"));
		JSON_HOSPREENTYBLNKSITE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTYBLNKSITE"));
		JSON_HOSPREENTYINVLDSITE = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTYINVLDSITE"));
		JSON_HOSPREENTRINVLDUSERID = new File(PropertyReader.getInstance().readProperty("JSON_HOSPREENTRINVLDUSERID"));
		
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when claim Successfully reEnterd$")
	public void verify_The_Return_Code(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTERCLM);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when claim Successfully reEnterd$")
	public void verify_The_Return_Msg(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTERCLM);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when claim UnSuccessfully reEnterd$")
	public void verify_The_Return_CodeUnsuccessful(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTERUNSUCCESSCLM);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when claim UnSuccessfully reEnterd$")
	public void verify_The_Return_MsgUnsuccessful(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTERUNSUCCESSCLM);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when site is invalid$")
	public void verify_The_Return_Code_InvalidSite(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYINVLDSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when site is invalid$")
	public void verify_The_Return_Msg_InvalidSite(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYINVLDSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when site is blank$")
	public void verify_The_Return_Code_BlankSite(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYBLNKSITE);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when site is blank$")
	public void verify_The_Return_Msg_BlankSite(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYBLNKSITE);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when user id is invalid$")
	public void verify_The_Return_Code_Invld_UserId(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTRINVLDUSERID);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when user id is invalid$")
	public void verify_The_Return_Msg_Invld_UserId(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTRINVLDUSERID);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}
	
	@When("^Verify the Return code as \"([^\"]*)\" of Hospital claim when audit is blank$")
	public void verify_The_Return_Code_Blank_Audit(String rvwCode)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwCode.length() >0 && rvwCode.substring(0, 1).equalsIgnoreCase("*"))
			rvwCode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwCode, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYBLNKAUDT);
		System.out.println("Review code from Response:"+" "+ response_ClaimsDetails.get("Return Code"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Code").equals(rvwCode), "Failed:Review codes are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review codes are verified from Service response and Database.");
	}
	
	@When("^Verify the Return msg as \"([^\"]*)\" of Hospital claim when audit is blank$")
	public void verify_The_Return_Msg_Blank_Audt(String rvwMsg)throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
		//Response from sheet
		if (rvwMsg.length() >0 && rvwMsg.substring(0, 1).equalsIgnoreCase("*"))
			rvwMsg = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rvwMsg, PropertyReader.getInstance().readProperty("Environment"));
		
		//Response from Service
		Map<String,String> response_ClaimsDetails = getPage(HospitalReEntryClaimAPIValidation.class).reviewCodeAndMsg(JSON_HOSPREENTYBLNKAUDT);
		System.out.println("Review msg from Response:"+" "+ response_ClaimsDetails.get("Return Msg"));
		Assert.assertTrue(response_ClaimsDetails.get("Return Msg").contains(rvwMsg), "Failed:Review msg are not verified from response and Data base through data sheet.");
		Log.info("Verified:Review msg are verified from Service response and Database.");
	}

}
