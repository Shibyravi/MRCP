package com.optum.mrcpcosmosatdd.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.mrcpcosmosatdd.reporting.Log;

public class MenuValidationWindow extends BasePage {
	
	//private By windowRootEle = By.id("physicianClaimReviewWindow");

	private By label_OptionMenu = By.xpath(".//a[@id='optionLink']");
	private By label_PhysicianMenu = By.xpath(".//a[@id='physLink']");
	private By label_HospitalMenu = By.xpath(".//a[@id='hospLink']");
	private By label_SearchMenu = By.xpath(".//a[@id='searchLink']");
	private By label_ProcessorMenu = By.xpath(".//a[@id='procLink']");
	private By label_AdminMenu = By.xpath(".//a[@id='adminLink']");
	private By label_SuperUserMenu = By.xpath(".//a[@id='superUserLink']");
	private By label_FieldServiceMenu = By.xpath(".//a[@id='fieldLink']");
	private By label_ClaimPauseMenu = By.xpath(".//a[@id='Pause']");
	private By label_ClaimDevelopmentMenu = By.xpath(".//a[@id='claimsDevelopmentLink']");
	private By label_RuleseMenu = By.xpath(".//a[@id='rulesLink']");	
	private By label_ViewMenu = By.xpath(".//a[@id='windowLink']");
	private By label_HelpMenu = By.xpath(".//a[@id='helpLink']");
	private By label_HospitalATGSubMenu = By.xpath(".//a[@id='ATG_ATG_hospital']");
	private By label_PhysicianATGSubMenu = By.xpath(".//a[@id='ATG_ATG_physician']");

	
	public boolean validateWindowMenuForSuperUser() throws InterruptedException{
		boolean flag=true;
		
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_OptionMenu));
		
		String optionMenu= driver.findElement(label_OptionMenu).getAttribute("class");		
		if(optionMenu.endsWith("linkClass")){			
			Log.info("option menu is Enable");
			driver.findElement(label_OptionMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("option menu is not Enable");
			flag=false;			
		}
		
		Thread.sleep(5000);
		
		WebElement ele =driver.findElement(label_OptionMenu);
		
		   Actions builder = new Actions(driver);
           Action mouseOverHome = builder.moveToElement(ele).build();
            
           String bgColor = ele.getCssValue("background-color");
           System.out.println("Before hover: " + bgColor);        
           mouseOverHome.perform();        
           bgColor = ele.getCssValue("background-color");
           System.out.println("After hover: " + bgColor);
		
		
		String fontSize = ele.getCssValue("font-size");
		System.out.println("Font Size -> "+fontSize);
		
		String fontColor = ele.getCssValue("color");
		System.out.println("Font Color -> "+fontColor);
		  
		  
		String fontFamily = ele.getCssValue("font-family");
		System.out.println("Font Family -> "+fontFamily);
		
		String fonttxtAlign = ele.getCssValue("text-align");
		System.out.println("Font Text Alignment -> "+fonttxtAlign);
		
		Point point = ele.getLocation();
		System.out.println("Position -> "+point.toString());
		
		Dimension dimention = ele.getSize();
		System.out.println("Dimntion  -> "+dimention.toString());
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_PhysicianMenu));
		String phyMenu= driver.findElement(label_PhysicianMenu).getAttribute("class");
		
		if(phyMenu.endsWith("linkClass")){
			Log.info("Physician menu is Enable");
			driver.findElement(label_PhysicianMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Physician menu is not Enable");
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HospitalMenu));
		String hosMenu= driver.findElement(label_HospitalMenu).getAttribute("class");
		
		if(hosMenu.endsWith("linkClass")){
			Log.info("Hospital menu is Enable");	
			driver.findElement(label_HospitalMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Hospital menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SearchMenu));
		String searchMenu= driver.findElement(label_SearchMenu).getAttribute("class");
		
		if(searchMenu.endsWith("linkClass")){
			Log.info("Search menu is Enable");	
			driver.findElement(label_SearchMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Search menu is not Enable");
			flag=false;
			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ProcessorMenu));
		String processorMenu= driver.findElement(label_ProcessorMenu).getAttribute("class");
		
		if(processorMenu.endsWith("linkClass")){
			Log.info("Processor menu is Enable");	
			driver.findElement(label_ProcessorMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Processor menu is not Enable");	
			flag=false;			
		}
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_AdminMenu));
		String adminMenu= driver.findElement(label_AdminMenu).getAttribute("class");
		
		if(adminMenu.endsWith("linkClass")){
			Log.info("Admin menu is Enable");
			driver.findElement(label_AdminMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Admin menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SuperUserMenu));
		String superUserMenu= driver.findElement(label_SuperUserMenu).getAttribute("class");
		
		if(superUserMenu.endsWith("linkClass")){
			Log.info("SuperUser menu is Enable");	
			driver.findElement(label_SuperUserMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("SuperUser menu is not Enable");	
			flag=false;			
		}
		
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_FieldServiceMenu));
		String fieldServiceMenu= driver.findElement(label_FieldServiceMenu).getAttribute("class");
		
		if(fieldServiceMenu.endsWith("linkClass")){
			
			
			Log.info("Field Service menu is Enable");	
			driver.findElement(label_FieldServiceMenu).click();
			Thread.sleep(2000);			
			
			driver.findElement(label_HospitalATGSubMenu).click();
			Log.info("Hospital ATG Sub menu is Enable");	
			Thread.sleep(2000);
			
			driver.findElement(label_PhysicianATGSubMenu).click();
			Log.info("Physician ATG Sub menu is Enable");	
			Thread.sleep(2000);			
			
			
		}
		else
		{
			Log.info("Field Service menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimPauseMenu));
		String claimPauseMenu= driver.findElement(label_ClaimPauseMenu).getAttribute("class");
		
		if(claimPauseMenu.endsWith("linkClass")){
			Log.info("Claim Pause menu is Enable");	
			driver.findElement(label_ClaimPauseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Pause menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimDevelopmentMenu));
		String claimDevMenu= driver.findElement(label_ClaimDevelopmentMenu).getAttribute("class");		
		claimDevMenu=claimDevMenu.trim();		
		Log.info("claimDevMenu = "+claimDevMenu+":");
		if(claimDevMenu.endsWith("linkClass")){
			Log.info("Claim Development menu is Enable");		
			driver.findElement(label_ClaimDevelopmentMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Development menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_RuleseMenu));
		String rulesMenu= driver.findElement(label_RuleseMenu).getAttribute("class");
		
		if(rulesMenu.endsWith("linkClass")){
			Log.info("Rules menu is Enable");	
			driver.findElement(label_RuleseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Rules  menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ViewMenu));
		String viewMenu= driver.findElement(label_ViewMenu).getAttribute("class");
		
		if(viewMenu.endsWith("linkClass")){
			Log.info("View menu is Enable");	
			driver.findElement(label_ViewMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("View menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HelpMenu));
		String helpMenu= driver.findElement(label_HelpMenu).getAttribute("class");
		
		if(helpMenu.endsWith("linkClass")){
			Log.info("Help menu is Enable");	
			driver.findElement(label_HelpMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Help  menu is not Enable");	
			flag=false;			
		}
		
		
		
		if(flag)
		{
			Log.info("It's a Super User");
		}
		else
		{
			Log.info("It's not a Super User");
		}
		
		return flag;
	}
	
	
	
	
	
	
	public boolean validateWindowMenuForSupervisor() throws InterruptedException{
		boolean flag=true;
		
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_OptionMenu));
		String optionMenu= driver.findElement(label_OptionMenu).getAttribute("class");		
		if(optionMenu.endsWith("linkClass")){
			Log.info("option menu is Enable");
			driver.findElement(label_OptionMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("option menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_PhysicianMenu));
		String phyMenu= driver.findElement(label_PhysicianMenu).getAttribute("class");
		
		if(phyMenu.endsWith("linkClass")){
			Log.info("Physician menu is Enable");	
			driver.findElement(label_PhysicianMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Physician menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HospitalMenu));
		String hosMenu= driver.findElement(label_HospitalMenu).getAttribute("class");
		
		if(hosMenu.endsWith("linkClass")){
			Log.info("Hospital menu is Enable");	
			driver.findElement(label_HospitalMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Hospital menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SearchMenu));
		String searchMenu= driver.findElement(label_SearchMenu).getAttribute("class");
		
		if(searchMenu.endsWith("linkClass")){
			Log.info("Search menu is Enable");	
			driver.findElement(label_SearchMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Search menu is not Enable");
			flag=false;
			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ProcessorMenu));
		String processorMenu= driver.findElement(label_ProcessorMenu).getAttribute("class");
		
		if(processorMenu.endsWith("linkClass")){
			Log.info("Processor menu is Enable");	
			driver.findElement(label_ProcessorMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Processor menu is not Enable");	
			flag=false;			
		}
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_AdminMenu));
		String adminMenu= driver.findElement(label_AdminMenu).getAttribute("class");
		
		if(!adminMenu.endsWith("linkClass"))
		{
			Log.info("Admin menu is disable");			
		}
		else
		{
			Log.info("Admin menu is not disable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SuperUserMenu));
		String superUserMenu= driver.findElement(label_SuperUserMenu).getAttribute("class");
		
		if(!superUserMenu.endsWith("linkClass")){
			Log.info("SuperUser menu is disable");				
		}
		else
		{
			Log.info("SuperUser menu is not disable");	
			flag=false;			
		}
		
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_FieldServiceMenu));
		String fieldServiceMenu= driver.findElement(label_FieldServiceMenu).getAttribute("class");
		
		if(!fieldServiceMenu.endsWith("linkClass"))
		{			
			Log.info("Field Service menu is disable");			
			
		}
		else
		{
			Log.info("Field Service menu is not disable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimPauseMenu));
		String claimPauseMenu= driver.findElement(label_ClaimPauseMenu).getAttribute("class");
		
		if(claimPauseMenu.endsWith("linkClass")){
			Log.info("Claim Pause menu is Enable");	
			driver.findElement(label_ClaimPauseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Pause menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimDevelopmentMenu));
		String claimDevMenu= driver.findElement(label_ClaimDevelopmentMenu).getAttribute("class");		
		claimDevMenu=claimDevMenu.trim();		
		if(claimDevMenu.endsWith("linkClass")){
			Log.info("Claim Development menu is Enable");		
			driver.findElement(label_ClaimDevelopmentMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Development menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_RuleseMenu));
		String rulesMenu= driver.findElement(label_RuleseMenu).getAttribute("class");
		
		if(rulesMenu.endsWith("linkClass")){
			Log.info("Rules menu is Enable");	
			driver.findElement(label_RuleseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Rules  menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ViewMenu));
		String viewMenu= driver.findElement(label_ViewMenu).getAttribute("class");
		
		if(viewMenu.endsWith("linkClass")){
			Log.info("View menu is Enable");	
			driver.findElement(label_ViewMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("View menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HelpMenu));
		String helpMenu= driver.findElement(label_HelpMenu).getAttribute("class");
		
		if(helpMenu.endsWith("linkClass")){
			Log.info("Help menu is Enable");	
			driver.findElement(label_HelpMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Help  menu is not Enable");	
			flag=false;			
		}
		
		
		
		if(flag)
		{
			Log.info("It's a Superwiser User");
		}
		else
		{
			Log.info("It's not a Superwiser User");
		}
		
		return flag;
	}
	
	
	
	
	public boolean validateWindowMenuForLevel0User() throws InterruptedException{
		boolean flag=true;
		
		MIDDRIVERWAIT.until(ExpectedConditions.visibilityOfElementLocated(label_OptionMenu));
		String optionMenu= driver.findElement(label_OptionMenu).getAttribute("class");		
		if(optionMenu.endsWith("linkClass")){
			Log.info("option menu is Enable");
			driver.findElement(label_OptionMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("option menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_PhysicianMenu));
		String phyMenu= driver.findElement(label_PhysicianMenu).getAttribute("class");
		
		if(phyMenu.endsWith("linkClass")){
			Log.info("Physician menu is Enable");	
			driver.findElement(label_PhysicianMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Physician menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HospitalMenu));
		String hosMenu= driver.findElement(label_HospitalMenu).getAttribute("class");
		
		if(hosMenu.endsWith("linkClass")){
			Log.info("Hospital menu is Enable");	
			driver.findElement(label_HospitalMenu).click();;
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Hospital menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SearchMenu));
		String searchMenu= driver.findElement(label_SearchMenu).getAttribute("class");
		
		if(searchMenu.endsWith("linkClass")){
			Log.info("Search menu is Enable");	
			driver.findElement(label_SearchMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Search menu is not Enable");
			flag=false;
			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ProcessorMenu));
		String processorMenu= driver.findElement(label_ProcessorMenu).getAttribute("class");
		
		if(processorMenu.endsWith("linkClass")){
			Log.info("Processor menu is Enable");	
			driver.findElement(label_ProcessorMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Processor menu is not Enable");	
			flag=false;			
		}
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_AdminMenu));
		String adminMenu= driver.findElement(label_AdminMenu).getAttribute("class");
		
		if(!adminMenu.endsWith("linkClass"))
		{
			Log.info("Admin menu is disable");			
		}
		else
		{
			Log.info("Admin menu is not disable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_SuperUserMenu));
		String superUserMenu= driver.findElement(label_SuperUserMenu).getAttribute("class");
		
		if(!superUserMenu.endsWith("linkClass")){
			Log.info("SuperUser menu is disable");				
		}
		else
		{
			Log.info("SuperUser menu is not disable");	
			flag=false;			
		}
		
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_FieldServiceMenu));
		String fieldServiceMenu= driver.findElement(label_FieldServiceMenu).getAttribute("class");
		
		if(!fieldServiceMenu.endsWith("linkClass"))
		{			
			Log.info("Field Service menu is disable");			
			
		}
		else
		{
			Log.info("Field Service menu is not disable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimPauseMenu));
		String claimPauseMenu= driver.findElement(label_ClaimPauseMenu).getAttribute("class");
		
		if(claimPauseMenu.endsWith("linkClass")){
			Log.info("Claim Pause menu is Enable");	
			driver.findElement(label_ClaimPauseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Pause menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ClaimDevelopmentMenu));
		String claimDevMenu= driver.findElement(label_ClaimDevelopmentMenu).getAttribute("class");		
		claimDevMenu=claimDevMenu.trim();		
		if(claimDevMenu.endsWith("linkClass")){
			Log.info("Claim Development menu is Enable");		
			driver.findElement(label_ClaimDevelopmentMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Claim Development menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_RuleseMenu));
		String rulesMenu= driver.findElement(label_RuleseMenu).getAttribute("class");
		
		if(rulesMenu.endsWith("linkClass")){
			Log.info("Rules menu is Enable");	
			driver.findElement(label_RuleseMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Rules  menu is not Enable");	
			flag=false;			
		}
		
		
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_ViewMenu));
		String viewMenu= driver.findElement(label_ViewMenu).getAttribute("class");
		
		if(viewMenu.endsWith("linkClass")){
			Log.info("View menu is Enable");	
			driver.findElement(label_ViewMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("View menu is not Enable");	
			flag=false;			
		}
		
		//Constants.webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(label_HelpMenu));
		String helpMenu= driver.findElement(label_HelpMenu).getAttribute("class");
		
		if(helpMenu.endsWith("linkClass")){
			Log.info("Help menu is Enable");	
			driver.findElement(label_HelpMenu).click();
			Thread.sleep(2000);
		}
		else
		{
			Log.info("Help  menu is not Enable");	
			flag=false;			
		}
		
		
		
		if(flag)
		{
			Log.info("It's a Level0 User");
		}
		else
		{
			Log.info("It's not a Level0 User");
		}
		
		return flag;
	}

}
