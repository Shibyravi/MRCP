package com.optum.mrcpcosmosatdd.pages.errorValidations;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.ui.pages.BasePage;
import com.optum.mrcpcosmosatdd.ui.utilities.KeyUtils;

public class COBErrorValidationsWindow extends BasePage{
	
	private By windowRootEle = By.id("COBCarrierDetailsWindow");

	private By input_Member = By.id("cobRecarrierMemberNumber");
	private By input_Site = By.id("cobRecarrierSite");
	private By input_AsOfDt = By.id("cobRecarrierAsOfDate");
	private By Error_MsgBar = By.id("CobDetailErrorMsgBar");
	private By buttons_Inquire = By.id("cobDetailsInquire");
	private By buttons_Add = By.id("cobDetailsAdd");
	private By buttons_Change = By.id("cobDetailsChange");
	private By buttons_Close = By.id("cobDetailsClose");
	private By buttons_Investigate = By.id("cobDetailsInvestigate");
	private By exp_Date = By.id("expDt_0");
	private By primacy_1 = By.id("primacy_1");
	private By covType_1 = By.id("covType_1");
	private By carrierType_1 = By.id("carrierType_1");
	private By carrierNbr_1 = By.id("number_1");
	private By effDate_1 = By.id("effDt_1");
	private By exp_Date_1 = By.id("expDt_1");
	private By primacy_0 = By.id("primacy_0");
	private By covType_0 = By.id("covType_0");
	private By carrierType_0 = By.id("carrierType_0");
	private By carrierNbr_0 = By.id("number_0");
	private By effDate_0 = By.id("effDt_0");
	private By exp_Date_0 = By.id("expDt_0");
	private By incidentDt_0 = By.id("recoveryIncDt_0");
	private By carrierTypeRec_0 = By.id("recoveryCarrierType_0");
	private By carrierNbrRec_0 = By.id("recoveryCarrierNbr_0");
	private By effDateRec_0 = By.id("recoveryEffDt_0");
	private By expDateRec_0 = By.id("recoveryExpDt_0");
	private By diagDescRec_0 = By.id("recoveryDiagDesc_0");
	private By incidentDt_1 = By.id("recoveryIncDt_1");
	private By carrierTypeRec_1 = By.id("recoveryCarrierType_1");
	private By carrierNbrRec_1 = By.id("recoveryCarrierNbr_1");
	private By effDateRec_1 = By.id("recoveryEffDt_1");
	private By expDateRec_1 = By.id("recoveryExpDt_1");
	private By diagDescRec_1 = By.id("recoveryDiagDesc_1");
	private By primacy_2 = By.id("primacy_2");
	private By covType_2 = By.id("covType_2");
	private By carrierType_2 = By.id("carrierType_2");
	private By carrierNbr_2 = By.id("number_2");
	private By effDate_2 = By.id("effDt_2");
	private By exp_Date_2 = By.id("expDt_2");
	private By carrierName_1 = By.id("carrierName_1");
	private By carrierNamerec_0 = By.id("recoveryCarrierName_0");
	
	public By getWindowRoot() {
		return windowRootEle;
	}
	
	public String performInquire(String memberNBR, String memSite, String asOfDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			//Enter the Member number 
			enterText(input_Member, memberNBR); 
			//Enter the site
			enterText(input_Site, memSite);
			//Enter the From Date
			enterText(input_AsOfDt, asOfDate);
			
			//Click on Inquire Button
			mouseClick(buttons_Inquire);
			Thread.sleep(15000);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String enterExpDate(String expDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Exp Date
			enterText(exp_Date, expDate);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String enterEffDate(String effDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Eff Date
			enterText(effDate_0, effDate);
			KeyUtils.keyPressTab();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String enterEffDateRecovery(String effDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Eff Date
			enterText(effDateRec_0, effDate);
			KeyUtils.keyPressTab();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String enterExpDateRecovery(String expDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Exp Date
			enterText(expDateRec_0, expDate);
			KeyUtils.keyPressTab();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String entersExpDate(String expDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Exp Date
			enterText(exp_Date, expDate);
			KeyUtils.keyPressTab();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	public String enterIncidentDate(String incidentDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			
			//Enter the Exp Date
			enterText(incidentDt_0, incidentDate);
			KeyUtils.keyPressTab();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return driver.findElement(Error_MsgBar).getAttribute("value");
	}
	
	
	public boolean validateErrorMsg(String expErrorMsg , String actErroMsg) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			Assert.assertTrue(expErrorMsg.equals(actErroMsg), "Failed: Actual and Expected error msgs are not same");
			Log.info("Verified:Error message verified");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean validateErrorMsgAftAdd(String expErrorMsg) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			System.out.println("Actual error msg:"+ " "+ getAttributeValue(Error_MsgBar, "value"));
			Assert.assertTrue(expErrorMsg.equals(getAttributeValue(Error_MsgBar, "value")), "Failed: Actual and Expected error msgs are not same");
			Log.info("Verified:Error message verified");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean selectValues(String primacy, String covType, String carrierType, String carrierNumber, String effDate) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			selectDropDownBoxValue(primacy_2, primacy);
			selectDropDownBoxValue(covType_2, covType);
			selectDropDownBoxValue(carrierType_2, carrierType);
			enterText(carrierNbr_2, carrierNumber);
			enterText(effDate_2, effDate);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean enterCarrierNameOI(String carrierName) throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			enterText(carrierName_1, carrierName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean enterCarrierNameRec(String carrierNameRec) throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			enterText(carrierNamerec_0, carrierNameRec);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean selectValuesfromRecovery(String incidentDt, String carrierType, String carrierNumber, String effDate, String diagDesc) throws InterruptedException
	{
		waitForPageToLoad();
		Thread.sleep(15000);
		try {
			enterText(incidentDt_1, incidentDt);
			selectDropDownBoxValue(carrierTypeRec_1, carrierType);
			enterText(carrierNbrRec_1, carrierNumber);
			enterText(effDateRec_1, effDate);
			enterText(diagDescRec_1, diagDesc);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
	public boolean enterValidExpDate(String expDate) throws InterruptedException
	{
		
		try {
			enterText(exp_Date_2, expDate);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}

		return true;
	}
	
}
