package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
import com.optum.mrcpcosmosatdd.reporting.Log;
import com.optum.mrcpcosmosatdd.service.rest.windowpages.COBCarrierDetailsRestAPIWindow;
import com.optum.mrcpcosmosatdd.services.rest.AutoCloseCOBEditsAPIValidations;
import com.optum.mrcpcosmosatdd.services.rest.COBCarrierDetailsRestAPIValidations;
import com.optum.mrcpcosmosatdd.services.rest.PauseReleaseAPIValidations;
import com.optum.mrcpcosmosatdd.ui.helpers.Constants;
import com.optum.mrcpcosmosatdd.ui.helpers.PropertyReader;
import com.optum.mrcpcosmosatdd.ui.utilities.ExcelUtilities;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AutoCloseCobEditsAPISteps extends MRCPTestBase {

    File Json_ACC_InvalidDependent, Json_ACC_InvalidEffdate, Json_ACC_InvalidMemGrp, Json_ACC_InvalidParms, Json_ACC_invalidsiteid,
            Json_ACC_InvalidSubscriber, Json_ACCpayload;

    Map<String, String> attributes = new HashMap();

    @When("^I get the request body parameter from ACCjson file$")
    public void i_get_the_request_body_parameter_from_ACCjson_file() throws FileNotFoundException, NullPointerException {

        //Json_ACC_InvalidDependent=new File(PropertyReader.getInstance().readProperty("Json_ACC_InvalidDependent"));
        Json_ACC_InvalidEffdate=new File(PropertyReader.getInstance().readProperty("Json_ACC_InvalidEffdate"));
        Json_ACC_InvalidMemGrp=new File(PropertyReader.getInstance().readProperty("Json_ACC_InvalidMemGrp"));
        Json_ACC_InvalidParms=new File(PropertyReader.getInstance().readProperty("Json_ACC_InvalidParms"));
         Json_ACC_invalidsiteid= new File(PropertyReader.getInstance().readProperty("Json_ACC_invalidsiteid"));
        //Json_ACC_InvalidSubscriber=new File(PropertyReader.getInstance().readProperty("Json_ACC_InvalidSubscriber"));
        Json_ACCpayload = new File(PropertyReader.getInstance().readProperty("Json_ACCpayload"));
    }

    @Then("^Verify the ACCReturn code as \"([^\"]*)\" and return message \"([^\"]*)\" when a member has carrier type as MVA in recovery$")
    public void verify_the_ACCReturn_code_as_and_return_message_when_a_member_has_carrier_type_as_MVA_in_recovery(String rtncode, String rtnmessage) throws InvalidFormatException, IOException, InterruptedException, JSONException, IllegalArgumentException, JWTCreationException, ParseException {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(AutoCloseCOBEditsAPIValidations.class).rtnStatus(Json_ACCpayload);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("returnCode") + " and " + "Return message from Response:" + response_ClaimsDetails.get("returnMessage"));
        Assert.assertTrue(response_ClaimsDetails.get("returnCode").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("returnMessage").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");

    }
    @Then("^Verify the ACCReturn code as \"([^\"]*)\" and return message \"([^\"]*)\" when we give invalid site id$")
    public void verify_the_ACCReturn_code_as_and_return_message_when_we_give_invalid_site_id(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(AutoCloseCOBEditsAPIValidations.class).rtnStatus(Json_ACC_invalidsiteid);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("returnCode") + " and " + "Return message from Response:" + response_ClaimsDetails.get("returnMessage"));
        Assert.assertTrue(response_ClaimsDetails.get("returnCode").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("returnMessage").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");


    }

    @Then("^Verify the \"([^\"]*)\" Communication Reason values in recovery section of COBEdits from service response , COB details screen and from DB$")
    public void verify_the_Communication_Reason_values_in_recovery_section_of_COBEdits_from_service_response_COB_details_screen_and_from_DB(String CommunicationRsn ) throws Throwable {
        if (CommunicationRsn.length() > 0 && CommunicationRsn.substring(0, 1).equalsIgnoreCase("*"))
           CommunicationRsn = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME,CommunicationRsn, PropertyReader.getInstance().readProperty("Environment"));
        System.out.println("Communication Reason Recovery Details Expected Response from DB through DataSheet" + " " + CommunicationRsn);

        Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
        System.out.println("Communication Reason recovery Carrier details from UI"+" "+ recovery_Details_FromUI.get("Communication Rsn Rec").get(0));
     String  CommrsnfromUI= recovery_Details_FromUI.get("Communication Rsn Rec").get(0);
      Assert.assertTrue(CommrsnfromUI.equals(CommunicationRsn), "Failed:Communication Reason details are not verified from UI and DB");
      Log.info("Communication Reason carrier details are verified from UI ,Service response and Database.");

    }

    @Then("^Verify the \"([^\"]*)\"  and \"([^\"]*)\" are equal\\.$")
    public void verify_the_and_are_equal(String recoveryeffdate, String recoveryexpdate) throws Throwable {

        //Effective Date Recovery from UI
        Map<String, List<String>> recovery_Details_FromUI =  getPage(COBCarrierDetailsRestAPIWindow.class).getRecoveryDetailsUI();
         recoveryeffdate= recovery_Details_FromUI.get("Eff Date Rec").get(0);

        recoveryexpdate= recovery_Details_FromUI.get("Eff Date Rec").get(0);
        System.out.println(recoveryeffdate +"and"+recoveryexpdate );


        Assert.assertTrue(recoveryeffdate.equals(recoveryexpdate), "Failed:Effective Date recovery details are not verified from UI and Response");

        Log.info("recovery Effective Date and recovery expiry dates  from UI equal");

    }

    @When("^I inquire Member number as \"([^\"]*)\" and Site as \"([^\"]*)\" and as of date  as \"([^\"]*)\" and  EditHistory as \"([^\"]*)\" on COB Carrier Details page API$")
    public void i_inquire_Member_number_as_and_Site_as_and_as_of_date_as_and_EditHistory_as_on_COB_Carrier_Details_page_API(String memNbr, String memSite, String asOfDt, String Edithistory) throws Throwable {

        if (memNbr.length() > 0 && memNbr.substring(0, 1).equalsIgnoreCase("*"))
            memNbr = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memNbr, PropertyReader.getInstance().readProperty("Environment"));
        if (memSite.length() > 0 && memSite.substring(0, 1).equalsIgnoreCase("*"))
            memSite = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, memSite, PropertyReader.getInstance().readProperty("Environment"));
        if (Edithistory.length() > 0 && Edithistory.substring(0, 1).equalsIgnoreCase("*"))
            Edithistory = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, Edithistory, PropertyReader.getInstance().readProperty("Environment"));

        if (asOfDt.length() > 0 && asOfDt.substring(0, 1).equalsIgnoreCase("*"))
            asOfDt = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, asOfDt, PropertyReader.getInstance().readProperty("Environment"));


        attributes.put("memberNumber", memNbr);
        attributes.put("site", memSite);
        attributes.put("Edithistory", Edithistory);
        attributes.put("asOfDate", asOfDt);


        Assert.assertEquals(getPage(COBCarrierDetailsRestAPIWindow.class).performInquirehistory(memNbr, memSite, asOfDt, Edithistory), true);


    }


    @Then("^Verify the ACCReturn code as \"([^\"]*)\" and return message \"([^\"]*)\" when we give invalid member group$")
    public void verify_the_ACCReturn_code_as_and_return_message_when_we_give_invalid_member_group(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(AutoCloseCOBEditsAPIValidations.class).rtnStatus(Json_ACC_InvalidMemGrp);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("returnCode") + " and " + "Return message from Response:" + response_ClaimsDetails.get("returnMessage"));
        Assert.assertTrue(response_ClaimsDetails.get("returnCode").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("returnMessage").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");


    }

    @Then("^Verify the ACCReturn code as \"([^\"]*)\" and return message \"([^\"]*)\" when we give invalid effdate$")
    public void verify_the_ACCReturn_code_as_and_return_message_when_we_give_invalid_effdate(String rtncode, String rtnmessage) throws Throwable {
        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(AutoCloseCOBEditsAPIValidations.class).rtnStatus(Json_ACC_InvalidEffdate);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("returnCode") + " and " + "Return message from Response:" + response_ClaimsDetails.get("returnMessage"));
        Assert.assertTrue(response_ClaimsDetails.get("returnCode").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("returnMessage").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");


    }

    @Then("^Verify the ACCReturn code as \"([^\"]*)\" and return message \"([^\"]*)\" when we give invalid Parameters$")
    public void verify_the_ACCReturn_code_as_and_return_message_when_we_give_invalid_Parameters(String rtncode, String rtnmessage) throws Throwable {

        if (rtncode.length() > 0 && rtncode.substring(0, 1).equalsIgnoreCase("*"))
            rtncode = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtncode, PropertyReader.getInstance().readProperty("Environment"));

        if (rtnmessage.length() > 0 && rtnmessage.substring(0, 1).equalsIgnoreCase("*"))
            rtnmessage = ExcelUtilities.ReadExcelData(PropertyReader.getInstance().readProperty("TESTDATA_PATH"), Constants.FEATURENAME, rtnmessage, PropertyReader.getInstance().readProperty("Environment"));

        Map<String, String> response_ClaimsDetails = getPage(AutoCloseCOBEditsAPIValidations.class).rtnStatus(Json_ACC_InvalidParms);
        System.out.println("Return code from Response:" + " " + response_ClaimsDetails.get("returnCode") + " and " + "Return message from Response:" + response_ClaimsDetails.get("returnMessage"));
        Assert.assertTrue(response_ClaimsDetails.get("returnCode").equals(rtncode), "Failed:Return codes are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return codes are verified from Service response and Database.");
        Assert.assertTrue(response_ClaimsDetails.get("returnMessage").equals(rtnmessage), "Failed: return messages are not verified from response and Data base through data sheet.");
        Log.info("Verified:Return messages are verified from Service response and Database.");




    }
}

