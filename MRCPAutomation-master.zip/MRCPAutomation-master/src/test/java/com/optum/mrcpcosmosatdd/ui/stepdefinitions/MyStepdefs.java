package com.optum.mrcpcosmosatdd.ui.stepdefinitions;

public class MyStepdefs {

//    WebDriver driver;
//
//    @Given("^I am on the cpa home page$")
//    public void iAmOnTheCpaHomePage() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        System.setProperty("webdriver.chrome.driver","drivers/chromedriver_win32/chromedriver.exe");
//        ChromeOptions o = new ChromeOptions();
//
//        o.setExperimentalOption("useAutomationExtension", false);
//        o.addArguments("disable-extensions");
//        o.addArguments("--start-maximized");
//        driver = new ChromeDriver(o);
//        String baseUrl = "http://localhost:8888/CosmosBigBang/home2";
//
//        driver.get(baseUrl);
//
//    }
//
//    @When("^I login with valid credentials$")
//    public void iLoginWithValidCredentials() throws Throwable {
//        driver.findElement(By.name("userName")).sendKeys("tvijaya2");
//        driver.findElement(By.name("passMask")).sendKeys("Jul@2018");
//        driver.findElement(By.id("varLoginBtn")).click();
//
//        Thread.sleep(500);
//        driver.findElement(By.id("claimsDevelopmentLink")).click();
//
//    }
//
//    @Then("^I should be logged in$")
//    public void iShouldBeLoggedIn() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        Assert.assertTrue("1".equals("1"));
//
//    }
//
//    public void toClickOnMenu(String menuid, String windowname) throws Throwable{
//        driver.findElement(By.id(menuid)).click();
//        Thread.sleep(500);
//        driver.findElement(By.id(windowname)).click();
//    }
//
//
//    @When("^I login with invalid credentails as \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void iLoginWithInvalidCredentailsAsAnd(String arg0, String arg1) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }
//
//    @Then("^I should see the \"([^\"]*)\" error message$")
//    public void iShouldSeeTheErrorMessage(String arg0) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }
}
